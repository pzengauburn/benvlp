######################################################################
# some utility functions 
######################################################################

######################################################################
# get sample 
######################################################################

get_sample = function(samples, xdim, pos = 0)
{
    array(samples[pos + (1:prod(xdim)), ], dim = c(xdim, ncol(samples)));  
}

get_all_samples = function(samples, name_dim)
{
    out = vector("list", length(name_dim));
    names(out) = names(name_dim); 

    pos = 0; 
    for(i in 1:length(name_dim))
    {
        out[[i]] = get_sample(samples, name_dim[[i]], pos); 
        pos = pos + prod(name_dim[[i]]); 

        if(names(out)[i] %in% c("rho", "nu"))
            out[[i]] = drop(out[[i]]); 
    }

    out; 
}

######################################################################
# get posterior means 
######################################################################

get_pmean = function(pmean, xdim, pos = 0)
{
    array(pmean[pos + (1:prod(xdim))], dim = xdim); 
}

get_all_pmeans = function(pmean, name_dim)
{
    out = vector("list", length(name_dim));
    names(out) = names(name_dim); 
    
    pos = 0; 
    for(i in 1:length(name_dim))
    {
        out[[i]] = get_pmean(pmean, name_dim[[i]], pos);  
        pos = pos + prod(name_dim[[i]]); 
        
        if(names(out)[i] %in% c("rho", "nu"))
            out[[i]] = drop(out[[i]]); 
    }

    out; 
}

######################################################################
# get k-th sample 
######################################################################

get_k_sample = function(samples, k, Umat = NULL)
{
    out = vector("list", length(samples));
    names(out) = names(samples); 

    for(i in 1:length(samples))
    {
        nd = length(dim(samples[[i]]));
        out[[i]] = switch(as.character(nd),  
            "0" = samples[[i]][k],
            "2" = samples[[i]][, k],
            "3" = samples[[i]][, , k],
            "4" = samples[[i]][, , , k],
            "5" = samples[[i]][, , , , k],
            "6" = samples[[i]][, , , , , k],
            "7" = samples[[i]][, , , , , , k],
            "8" = samples[[i]][, , , , , , , k],
            "9" = samples[[i]][, , , , , , , , k],
            stop("not supported in get_k_sample().\n")
        ); 

        if(nd >= 3) dim(out[[i]]) = dim(samples[[i]])[1:(nd-1)];
    }

    if(!("Gamma" %in% names(out))) 
    if("Amat" %in% names(out)) 
        out$Gamma = A2Gamma(out$Amat, Umat);

    if(!("Gamma0" %in% names(out))) 
    if("Amat" %in% names(out)) 
        out$Gamma0 = A2Gamma0(out$Amat, Umat);

    if(! ("beta" %in% names(out)))
    if(all(c("Gamma", "eta") %in% names(out))) 
        out$beta = out$Gamma %*% out$eta; 

    if(!("Sigma" %in% names(out))) 
    if("Sigma_inv" %in% names(out)) 
        out$Sigma = solve(out$Sigma_inv);

    if(!("Omega" %in% names(out))) 
    if("Omega_inv" %in% names(out)) 
        out$Omega = solve(out$Omega_inv);

    if(!("Omega0" %in% names(out))) 
    if("Omega0_inv" %in% names(out)) 
        out$Omega0 = solve(out$Omega0_inv);

    if(! ("Sigma" %in% names(out)))
    if(all(c("Gamma", "Gamma0", "Omega", "Omega0") %in% names(out))) 
        out$Sigma = Gamma2Sigma(out$Gamma, out$Gamma0, out$Omega, out$Omega0);

    if(!("Sigma_inv" %in% names(out))) 
    if(all(c("Gamma", "Gamma0", "Omega_inv", "Omega0_inv") %in% names(out))) 
        out$Sigma_inv = Gamma2Sigma(out$Gamma, out$Gamma0, out$Omega_inv, out$Omega0_inv);

    out; 
}


add_beta_Sigma = function(samples, Umat = NULL)
{
    N = ncol(samples$alpha); 
    r = nrow(samples$alpha);
    u = dim(samples$Omega_inv)[1]; 
    p = dim(samples$eta)[2]; 

    ans = samples;

    beta_seq = array(0, dim = c(r, p, N));
    Sigma_seq = array(0, dim = c(r, r, N));

    Omega_seq = array(0, dim = c(u, u, N));
    Omega0_seq = array(0, dim = c(r-u, r-u, N));

    for(i in 1:N)
    {
        Amat = matrix(samples$Amat[, , i], ncol = u); 
        iGamma  = A2Gamma(Amat, Umat);
        iGamma0 = A2Gamma0(Amat, Umat); 
        beta_seq[, , i] = iGamma %*% samples$eta[, , i];

        Omega_seq[, , i] = solve(samples$Omega_inv[, , i]);
        Omega0_seq[, , i] = solve(samples$Omega0_inv[, , i]);
        Sigma_seq[, , i] = Gamma2Sigma(iGamma, iGamma0, Omega_seq[, , i], Omega0_seq[, , i]); 
    }

    ans$beta = beta_seq; 
    ans$Sigma = Sigma_seq; 
    ans$Omega = Omega_seq; 
    ans$Omega0 = Omega0_seq; 
    ans;
}

######################################################################
# log density of matrix-variate t-distribution 
# MT(nu, Mmat, Smat1, Smat2)
######################################################################

log_dT_mat = function(Y, nu, Mmat, Smat1, Smat2)
{
    a = nrow(Y); b = ncol(Y); 
    .C(.benvlp_log_dt_mat_API, 
            as.integer(a), as.integer(b), as.double(Y), as.double(nu), 
            as.double(Mmat), as.double(Smat1), as.double(Smat2),
            ans = double(1))$ans; 
}

######################################################################
# log density of matrix-variate normal distribution 
# Mnorm(nu, Mmat, Smat1, Smat2)
######################################################################

log_dnorm_mat = function(Y, Mmat, Smat1, Smat2)
{
    a = nrow(Y); b = ncol(Y); 
    .C(.benvlp_log_dnorm_mat_API, 
            as.integer(a), as.integer(b), as.double(Y),  
            as.double(Mmat), as.double(Smat1), as.double(Smat2),
            ans = double(1))$ans; 
}

######################################################################
# THE END 
######################################################################
