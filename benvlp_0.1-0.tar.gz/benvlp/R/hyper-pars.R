######################################################################
# set hyper-parameters 
######################################################################

set_hyper_pars_mlm = function(hyper_pars, r, p) 
{
    if(is.null(hyper_pars$xi)) hyper_pars$xi = matrix(0, nrow = r, ncol = p); 
    if(is.null(hyper_pars$Hmat)) hyper_pars$Hmat = diag(rep(0.001, p)); 

    if(is.null(hyper_pars$df)) hyper_pars$df = r + 1; 
    if(is.null(hyper_pars$Psi)) hyper_pars$Psi = diag(rep(0.001, r)); 

    # hyper-parameter for nu 
    if(is.null(hyper_pars$nu_shape))
        hyper_pars$nu_shape = 1.4;
    if(is.null(hyper_pars$nu_rate))
        hyper_pars$nu_rate = 0.04; 

    hyper_pars; 
}


set_hyper_pars_envlp = function(hyper_pars, r, p, u) 
{
    # prior for eta: xi and Hmat 
    if(is.null(hyper_pars$eta_mean)) 
        hyper_pars$eta_mean = matrix(0, nrow = r, ncol = p); 
    if(is.null(hyper_pars$eta_cov_inv)) 
        hyper_pars$eta_cov_inv = diag(rep(0.001, p)); 

    # prior for Omega: df and Psi 
    if(is.null(hyper_pars$Omega_df)) 
        hyper_pars$Omega_df = u + 1; 
    if(is.null(hyper_pars$Omega_scale)) 
        hyper_pars$Omega_scale = diag(rep(0.001, u), nrow = u, ncol = u); 

    # prior for Omega0: df and Psi 
    if(is.null(hyper_pars$Omega0_df)) 
        hyper_pars$Omega0_df = r - u + 1; 
    if(is.null(hyper_pars$Omega0_scale)) 
        hyper_pars$Omega0_scale = diag(rep(0.001, r - u), nrow = r - u, ncol = r - u); 

    # prior for Pmat 
    if(is.null(hyper_pars$P_Mmat))
        hyper_pars$P_Mmat = diag(rep(0.001, r), nrow = r, ncol = r); 

    # hyper-parameter for nu 
    if(is.null(hyper_pars$nu_shape))
        hyper_pars$nu_shape = 1.4;
    if(is.null(hyper_pars$nu_rate))
        hyper_pars$nu_rate = 0.04; 

    hyper_pars; 
}

######################################################################
# THE END 
######################################################################
