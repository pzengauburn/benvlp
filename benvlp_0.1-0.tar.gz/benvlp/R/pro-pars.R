######################################################################
# set tuning parameters in proposal distributions 
######################################################################

set_pro_pars_envlp = function(pro_pars) 
{
    if(is.null(pro_pars$Pmat_sigma2)) 
        pro_pars$Pmat_sigma2 = 1e-5; 

    if(is.null(pro_pars$nu_delta)) 
        pro_pars$nu_delta = 2; 

    if(is.null(pro_pars$rho_delta)) 
        pro_pars$rho_delta = 0.02; 

    pro_pars; 
}

######################################################################
# THE END 
######################################################################
