######################################################################
# Bayesian inference for multivariate linear regression 
# with repeated measures and t-distribution random error 
# 2025-10-27
######################################################################

######################################################################
# parameters to be estimated 
#     alpha - r-by-1 vector 
#     beta  - r-by-p matrix 
#     Sigma - r-by-r positive definite matrix 
#     rho   - scalar 
# 
# prior distributions 
#     alpha - noninformative 
#     beta  - matrix-variate normal distribution (xi, Sigma, H-inv) 
#     Sigma - inverse-Wishart(k, Psi) 
#     rho   - noninformative 
# 
# posterior distribution 
#     alpha - normal 
#     beta  - matrix-variate normal distribution 
#     Sigma - inv-Wishart 
#     rho   - nonstandard 
######################################################################

rlmm = function(
    y,                     # n-by-r matrix  
    x,                     # n-by-p matrix 
    subject,               # n-by-1 vector 
    cor_type = c("iid", "cs", "ar1"),  # type of correlation structure
    normal = FALSE,        # assume normal distribution instead of t-distribution 
    burn_in = 500,         # number of samples thrown away 
    size = 2000,           # number of samples generated after burn-in 
    thinning = 5,          # keep one out of every k samples  
    info = 500,            # display information for every k samples 
    ini = list(),          # initial values 
    hyper_pars = list(),   # parameters in prior distributions 
    pro_pars = list())     # parameters in proposal distributions 
{
    ##################################################################
    # compute some quantities    
    ##################################################################

    stopifnot(nrow(y) == nrow(x), length(subject) == nrow(y)); 

    index_order = order(subject); 
    subject = subject[index_order]; 
    x = x[index_order, ];
    y = y[index_order, ];

    sumJ = nrow(y);                   # number of observations 
    r = ncol(y);                      # number of responses 
    p = ncol(x);                      # number of predictors  
    subject_ID = unique(subject);     # distinct ID 
    n_subject = length(subject_ID);   # number of subject 

    ##################################################################
    # set default values for hyper_pars if necessary  
    ##################################################################

    hyper_pars_names = c("xi", "Hmat", "df", "Psi", "nu_shape", "nu_rate");
    if(! all(hyper_pars_names %in% names(hyper_pars)))
        hyper_pars = set_hyper_pars_mlm(hyper_pars, r, p)[hyper_pars_names]; 

    ##################################################################
    # set default values for pro_pars if necessary  
    ##################################################################

    pro_pars_names = c("rho_delta", "nu_delta"); 
    if(! all(pro_pars_names %in% names(pro_pars)))
        pro_pars = set_pro_pars_envlp(pro_pars)[pro_pars_names]; 

    ##################################################################
    # set default values for ini, and set the initial sample 
    ##################################################################

    ini_names = c("alpha", "beta", "Sigma", "rho", "tau", "nu");
    if(! all(c("alpha", "beta", "Sigma", "rho") %in% names(ini)))
        ini = set_ini(y, x, subject)[ini_names];

    ##################################################################
    # sample from posterior distributions  
    ##################################################################

    ini_vec = c(ini$rho, ini$nu, ini$tau, ini$alpha, ini$beta, solve(ini$Sigma));
    hyper_pars_vec = c(hyper_pars$xi, hyper_pars$Hmat, 
                       hyper_pars$df, hyper_pars$Psi,
                       hyper_pars$nu_shape, hyper_pars$nu_rate); 
    pro_pars_vec = c(pro_pars$rho_delta, pro_pars$nu_delta);

    Jvec = numeric(n_subject); 
    for (i in 1:n_subject) Jvec[i] = sum(subject == subject_ID[i]); 

    cor_type = match.arg(cor_type); 
    ctype = switch(cor_type, "iid" = 0, "cs" = 1, "ar1" = 2); 

    N = floor(size / thinning);
    ans = .C(.benvlp_BrmlmRM_API, as.integer(c(sumJ, r, p, n_subject)), 
                as.double(c(t(y), t(x))),
                as.integer(c(ctype, Jvec)),                 
                as.integer(c(burn_in, size, thinning, info, normal)),
                as.integer(length(ini_vec)), 
                as.double(ini_vec),
                as.integer(length(hyper_pars_vec)), 
                as.double(hyper_pars_vec), 
                as.integer(length(pro_pars_vec)), 
                as.double(pro_pars_vec), 
                as.integer(N), 
                samples = double(N * length(ini_vec)), 
                as.integer(length(ini_vec)), 
                pmean = double(length(ini_vec)), 
                count = integer(4)); 

    ##################################################################
    # samples:   
    #     rho, nu, tau, alpha, beta, Sigma_inv 
    # pmean: 
    #     rho, nu, tau, alpha, beta, Sigma
    #     1 + 1 + n_subject + r + r*p + r*r  
    ##################################################################

    samples = get_all_samples(
                matrix(ans$samples, ncol = N),
                list(rho = 1,
                     nu = 1, 
                     tau = n_subject, 
                     alpha = r, 
                     beta = c(r, p), 
                     Sigma_inv = c(r, r)));

    posterior_mean = get_all_pmeans(ans$pmean, 
                list(rho = 1,
                     nu = 1,
                     tau = n_subject, 
                     alpha = r, 
                     beta = c(r, p), 
                     Sigma = c(r, r)));

    iSample = get_k_sample(samples, N); 

    npars = (normal == FALSE) + 1 + r + r * p + r * (r + 1)/2;

    out = list(y = y, x = x, subject = subject,
        normal = normal, cor_type = cor_type,
        ini = ini,                    # initial value
        hyper_pars = hyper_pars,      # parameters in prior distributions
        pro_pars = pro_pars,          # parameters in proposal distributions
        posterior_mean = posterior_mean, 
        npars = npars,                # number of parameters  
        count = ans$count[2],         # number of saved samples 
        rho_accept = ans$count[3] / size, 
        nu_accept = ans$count[4] / size, 
        iSample = iSample,            # the last sample generated 
        samples = samples);           # saved samples 

    class(out) = "rlmm";
    out; 
}


pred_loglik_mat.rlmm = function(
    fit, 
    y = NULL,              # n-by-r matrix  
    x = NULL,              # n-by-p matrix 
    subject = NULL)        # n-by-1 vector 
{
    ##################################################################
    # compute some quantities    
    ##################################################################

    if(is.null(y)) y = fit$y; 
    if(is.null(x)) x = fit$x;
    if(is.null(subject)) subject = fit$subject; 

    stopifnot(nrow(y) == nrow(x), length(subject) == nrow(y)); 

    index_order = order(subject); 
    subject = subject[index_order]; 
    x = x[index_order, ];
    y = y[index_order, ];

    sumJ = nrow(y);                   # number of observations 
    r = ncol(y);                      # number of responses 
    p = ncol(x);                      # number of predictors  
    subject_ID = unique(subject);     # distinct ID 
    n_subject = length(subject_ID);   # number of subject 

    ##################################################################
    # sample from posterior distributions  
    ##################################################################

    Jvec = numeric(n_subject); 
    for (i in 1:n_subject) Jvec[i] = sum(subject == subject_ID[i]); 

    ctype = switch(fit$cor_type, "iid" = 0, "cs" = 1, "ar1" = 2); 

    N = fit$count;
    length_pars = 1 + 1 + n_subject + r + r*p + r*r; 
    # rho, nu, tau, alpha, beta, Sigma_inv 

    allsamples = rbind(
        fit$samples$rho,
        fit$samples$nu,
        matrix(1.0, nrow = n_subject, ncol = N),    # tau 
        fit$samples$alpha,
        matrix(fit$samples$beta, nrow = r*p, ncol = N),
        matrix(fit$samples$Sigma_inv, nrow = r*r, ncol = N)); 

    ans = .C(.benvlp_BrmlmRM_loglik, 
                as.integer(c(sumJ, r, p, n_subject)), 
                as.double(c(t(y), t(x))),
                as.integer(c(ctype, Jvec)),                 
                as.integer(fit$normal),
                as.integer(N), 
                as.double(allsamples),
                logf = double(N * n_subject)); 

    matrix(ans$logf, nrow = N, ncol = n_subject);    
}

######################################################################
# THE END 
######################################################################
