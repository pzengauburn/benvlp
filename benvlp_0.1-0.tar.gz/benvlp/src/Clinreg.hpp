/**********************************************************************
 * Class for linear regression  
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28
 * updated: 2025-03-13  
 * updated: 2025-10-22
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CLINREG__HPP__ 
#define __ZP__CLINREG__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "Creg.hpp"

class Clinreg : public Creg {
    protected: 
        bool has_intercept;       /* true = with intercept, false = no intercept */
        Cmat *alpha;              /* intercept - r-by-1 matrix */
        Cmat *beta;               /* slope - r-by-p matrix */
        Cmat *res;                /* residual - r-by-n matrix */

    public: 
        Clinreg(); 
        Clinreg(Cmat *x_pt, Cmat *y_pt, bool intercept); 
        ~Clinreg(); 

        /**************************************************************
         * get or set class members     
         **************************************************************/

        void set_alpha(Cmat *a);
        void set_beta(Cmat *b); 
        
        void write2stream(std::ostream &stream);  

        /**************************************************************
         * fit linear models    
         **************************************************************/

        /* compute least squares estimate by Cholesky factorization */
        void fit_lse_chol(); 

        /* compute residual: r = y - alpha 1^T - b * x */
        void compute_residual(); 
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
