/**********************************************************************
 * Bayesian inference for multivariate linear regression  
 * with repeated measures and envelope structure
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-22 
 **********************************************************************/

#include <R.h>
#include "CBmlmRM_envlp.hpp"

extern "C" {
void BmlmRM_envlp_API(
    const int *dims,               /* (n, r, p, msub, u), length = 5 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* (burn_in, size, thinning, info), length = 4 */
    int *length_ini,               /* length of ini = 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *ini,                   /* (rho, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u)*(r-u) + r * r */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mmat) */
    int *length_tuning,            /* length of tuning parameters, = 2 */
    double *tuning,                /* rho_delta, Mmat_sigma2 */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (rho, alpha, eta, Amat, Omega, Omega0) */
    int *count)                    /* length = 4, count number of sample generated, number of saved samples, rho_count, A_count */  
{
    const int n = dims[0];         /* number of observations */
    const int r = dims[1];         /* number of respones */
    const int p = dims[2];         /* number of predictors */
    const int msub = dims[3];      /* number of subjects */
    const int u = dims[4];         /* dim of envelope */

    int pars_length = 1 + r + u * p + (r-u) * u + u * u + (r-u) * (r-u);

    const int burn_in = control[0];
    const int size = control[1];
    const int thinning = control[2];
    const int info = control[3];

    /******************************************************************
     * define the problem to be solved  
     ******************************************************************/

    int type_int = int_data[0];  
    Corr_Type ctype; 
    if(type_int == 0) ctype = Corr_Type::iid;
    else if(type_int == 1) ctype = Corr_Type::cs;
    else if (type_int == 2) ctype = Corr_Type::ar1; 
    else error("unsupported corelation type.\n"); 

    Cmat ymat(r, n, data); 
    Cmat xmat(p, n, data + r * n); 
    
    Cmat Umatrix(r, r, data + r * n + p * n); 
    Cmat *Umat_pt = nullptr;  
    if(! Umatrix.is_identity())  Umat_pt = &Umatrix; 

    Cimat Jmat(msub, 1, int_data + 1); 
    CBmlmRM_envlp prob(&xmat, &ymat, u, &Jmat, ctype, burn_in, size, thinning, info, pars_length, Umat_pt);

    /******************************************************************
     * set the hyper-parameters for prior distributions 
     ******************************************************************/

    prob.set_hyperpars(*length_hyper, hyperpars); 

    /******************************************************************
     * set the hyper-parameters for proposal distributions 
     ******************************************************************/

    prob.set_tuning(*length_tuning, tuning); 

    /******************************************************************
     * set the initial sample 
     ******************************************************************/

    prob.set_ini_pars(*length_ini, ini); 
    
    /******************************************************************
     * set the output space 
     ******************************************************************/
    
    prob.set_output_space(*max_samples, pars_length, saved_samples); 

    /******************************************************************
     * start sampling from posterior
     ******************************************************************/

    // std::ofstream file("BmlmRM_envlp_problem.txt", std::ios::app);
    // prob.write2stream(file);
    // file.close(); 

    prob.mcmc_run(); 

    /******************************************************************
     * output counts 
     ******************************************************************/

    prob.compute_posterior_mean(pars_length, pmean);

    prob.get_all_count(4, count);
}
}

/**********************************************************************
 * THE END
 **********************************************************************/
