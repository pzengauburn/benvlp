/**********************************************************************
 * Class for Bayesian inference - t-distribution, v ~ Gamma(a, b)
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-27 
 **********************************************************************/

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include "CBtGamma.hpp"

/**********************************************************************
 * variables defined in GBtGamma: (6)
 *     Cmat *tau;                   latent variable 
 *     double nu;                   degrees of freedom 
 *     double hyper_nu_shape;       scalar - hyperparameter in Gamma distribution 
 *     double hyper_nu_rate;        scalar - hyperparameter in Gamma distribution 
 *     double pro_nu_delta;         tuning parameter in proposal distribution 
 *     int nu_count;                count the number of accepted nu 
 **********************************************************************/

CBtGamma::CBtGamma()
{
    this->tau = nullptr;
    this->nu = 0.0; 
    this->hyper_nu_shape = 0.0; 
    this->hyper_nu_rate = 0.0; 
    this->pro_nu_delta = 0.0; 
    this->nu_count = 0; 
}

CBtGamma::CBtGamma(int length_tau)
{
    this->tau = new Cmat(length_tau, 1, nullptr); 
    this->nu = 0; 
    this->hyper_nu_shape = 0.0; 
    this->hyper_nu_rate = 0.0; 
    this->pro_nu_delta = 0.0; 
    this->nu_count = 0; 
}

CBtGamma::~CBtGamma()
{
    delete this->tau; 
}

/**********************************************************************
 * sample tau 
 *
    for(i in 1:prob$nsubject)
    {
        iSample$tau[i] = rgamma(1, 
                shape = (iSample$nu + prob$r) / 2, 
                rate = (iSample$nu + iSample$Delta[i]) / 2);
    }
 **********************************************************************/
        
void CBtGamma::sample_tau(Cmat &delta, int r)
{
    for(int i = 0; i < this->tau->get_vec_length(); i++)
    {
        this->tau->set_entry_vec(i, 
                rgamma(0.5 * (this->nu + (double)r), 
                       2.0 / (this->nu + delta.get_entry_vec(i))));  
    }
}

/**********************************************************************
 * sample tau 
 *
    for(i in 1:prob$nsubject)
    {
        iSample$tau[i] = rgamma(1, 
                shape = (iSample$nu + prob$Jvec[i] * prob$r) / 2, 
                rate = (iSample$nu + iSample$Delta[i]) / 2);
    }
 **********************************************************************/
        
void CBtGamma::sample_tauRM(Cimat &Jvec, Cmat &deltaRM, int r)
{
    for(int i = 0; i < this->tau->get_vec_length(); i++)
    {
        this->tau->set_entry_vec(i, 
                rgamma(0.5 * (this->nu + Jvec.get_entry_vec(i) * (double)r), 
                       2.0 / (this->nu + deltaRM.get_entry_vec(i))));  
    }
}

/**********************************************************************
 * sample nu 
 *
    nu.new = runif(1, iSample$nu - pro.pars$nu.delta, iSample$nu + pro.pars$nu.delta); 
    if(nu.new < 0) nu.new = -nu.new; 

    nu.loglik.old = tenvlp2.compute.nu.loglik(prob$nsubject, iSample$nu, iSample$tau); 
    nu.loglik.new = tenvlp2.compute.nu.loglik(prob$nsubject, nu.new, iSample$tau); 

    nu.logratio = nu.loglik.new - nu.loglik.old; 
    if(log(runif(1)) < nu.logratio)
    {
        iSample$nu = nu.new; 
        iSample$nu.count = iSample$nu.count + 1; 
    }
 **********************************************************************/

void CBtGamma::sample_nu()
{
    double nu_new = runif(this->nu - this->pro_nu_delta, 
                          this->nu + this->pro_nu_delta); 
    if(nu_new < 0.0) nu_new = -nu_new; 

    double loglik_old = this->compute_loglik_nu(this->nu); 
    double loglik_new = this->compute_loglik_nu(nu_new); 

    if(log(unif_rand()) < (loglik_new - loglik_old))
    {
        /* acccept proposed nu */
        (this->nu_count) ++; 
        this->nu = nu_new; 
    }
}

double CBtGamma::compute_loglik_nu(double inu) 
{
    double sum_logtau = this->tau->sumlog(); 
    double sum_tau = this->tau->sum(); 
    double m = (double)(this->tau->get_vec_length()); 
    
    return( (0.5 * m * inu)* log(0.5 * inu) 
            - m * lgamma(0.5 * inu)
            + (0.5 * inu - 1.0) * sum_logtau 
            - 0.5 * inu * sum_tau
            + (this->hyper_nu_shape - 1.0) * log(inu)
            - this->hyper_nu_rate * inu ); 
}

/**********************************************************************
 * THE END
 **********************************************************************/
