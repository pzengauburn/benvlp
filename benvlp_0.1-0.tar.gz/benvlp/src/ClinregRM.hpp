/**********************************************************************
 * Class for linear regression with repeated measures  
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-30
 * updated: 2025-03-13
 * updated: 2025-10-22 
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CLINREGRM__HPP__ 
#define __ZP__CLINREGRM__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "Clinreg.hpp"
#include "Ccormat.hpp"
#include "Cimat.hpp"
#include "distribution.hpp"

class ClinregRM : public Clinreg {
    protected: 
        int m_sub;                   /* number of subjects */
        int Jmax;                    /* max(Jvec) */
        Cimat *Jvec;                 /* number of observations for each subject, length = m_sub */
        Corr_Type ctype;             /* correlation structure */
        double rho;                  /* parameter in correlation */

        Cmat *Sigma_inv;             /* r-by-r matrix */
        Cmat *deltaRM;               /* msub-by-1 matrix */

        double pro_rho_delta;        /* scalar - tuning parameter */
        int rho_count;               /* count the number of accepted rho */ 
        
    public: 
        ClinregRM(); 
        ClinregRM(Cmat *x_pt, Cmat *y_pt, bool intercept, Cimat *Jvec_pt, Corr_Type cp); 
        ~ClinregRM(); 

        /**************************************************************
         * get or set class members     
         **************************************************************/

        void write2stream(std::ostream &stream);   

        /**************************************************************
         * more member functions     
         **************************************************************/

        void compute_deltaRM(); 

        void sample_alpha(); 
        void sample_rho(); 

        double compute_loglik_rho(double sum_tau_delta); 

        void sample_alpha_t(Cmat &tau); 
        void sample_rho_t(Cmat &tau);
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
