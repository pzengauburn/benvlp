/**********************************************************************
 * random distributions, density, random number generating  
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28
 * updated: 2025-05-22 (logd_invWishart_inv, logd1_invWishart_inv, logd2_invWishart_inv)
 * updated: 2025-10-17 (log_dinvgauss, rinvgauss)
 * updated: 2025-10-25 (log_dMnorm0, log_dMT0)
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__DISTRIBUTION__HPP__ 
#define __ZP__DISTRIBUTION__HPP__ 

#include <R.h> 
#include <Rmath.h>
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include "Cmat.hpp"

/**********************************************************************
 * log density - normal distribution 
 * log_dnorm() for univariate normal distribution  
 * log_dnorm_vec() for multivariate normal distribution 
 * log_dnorm_mat() for matrix-variate normal distribution 
 *
 * functions with _chol: the input is the Cholesky factorization of Sigma
 * log_dnorm_vec_chol() for multivariate normal distribution 
 * log_dnorm_mat_chol() for matrix-variate normal distribution 
 **********************************************************************/

/* p = dimension, logdet = log(det(Sigma)), delta = (x - mu)' * solve(Sigma) * (x - mu) */
double log_dnorm0(double p, double logdet, double delta);

double log_dnorm(double x, double mu, double sd);
double log_dnorm_vec(Cmat &x, Cmat &mu, Cmat &Sigma); 
double log_dnorm_mat(Cmat &x, Cmat &mu, Cmat &Sigma1, Cmat &Sigma2); 

double log_dnorm_vec_chol(Cmat &x, Cmat &mu, Cmat &Schol); 
double log_dnorm_mat_chol(Cmat &x, Cmat &mu, Cmat &Schol1, Cmat &Schol2); 

/**********************************************************************
 * log density of matrix-variate normal distribution Mnorm(M, S1, S2) 
 *     Y  -- a-by-b matrix 
 *     M  -- a-by-b matrix 
 *     S1 -- a-by-a matrix 
 *     S2 -- b-by-b matrix 
 *
 * delta = tr(S1^{-1} * (Y - M) * S2^{-1} * (Y - M)^T)
 * logdetS1 = log(det(S1)) 
 * logdetS2 = log(det(S2)) 
 **********************************************************************/

double log_dMnorm0(double a, double b, double delta, double logdetS1, double logdetS2);

/**********************************************************************
 * log density - t distribution 
 * log_dt() for univariate t distribution  
 * log_dt_vec() for multivariate t distribution 
 * log_dt_mat() for matrix-variate t distribution 
 *
 * functions with _chol: the input is the Cholesky factorization of Sigma
 * log_dt_vec_chol() for multivariate t distribution 
 * log_dt_mat_chol() for matrix-variate t distribution 
 **********************************************************************/

/* p = dimension, logdet = log(det(Sigma)), delta = (x - mu)' * solve(Sigma) * (x - mu) */
double log_dt0(double p, double df, double logdet, double delta);

double log_dt(double x, double df, double mu, double sd);
double log_dt_vec(Cmat &x, double df, Cmat &mu, Cmat &Sigma); 
double log_dt_mat(Cmat &x, double df, Cmat &mu, Cmat &Sigma1, Cmat &Sigma2); 

double log_dt_vec_chol(Cmat &x, double df, Cmat &mu, Cmat &Schol); 
double log_dt_mat_chol(Cmat &x, double df, Cmat &mu, Cmat &Schol1, Cmat &Schol2); 

/**********************************************************************
 * log density of matrix-variate t-distribution MT(nu, M, S1, S2) 
 *     Y  -- a-by-b matrix 
 *     M  -- a-by-b matrix 
 *     S1 -- a-by-a matrix 
 *     S2 -- b-by-b matrix 
 *
 * delta = tr(S1^{-1} * (Y - M) * S2^{-1} * (Y - M)^T)
 * logdetS1 = log(det(S1)) 
 * logdetS2 = log(det(S2)) 
 **********************************************************************/

double log_dMT0(double a, double b, double nu, double delta, double logdetS1, double logdetS2);

/**********************************************************************
 * random number generation - normal distribution 
 * rnorm_std() for standard normal distribution  
 * rnorm_vec() for multivariate normal distribution 
 * rnorm_mat() for matrix-variate normal distribution 
 *
 * functions with _chol: the input is the Cholesky factorization of Sigma
 * rnorm_vec_chol() for multivariate normal distribution 
 * rnorm_mat_chol() for matrix-variate normal distribution 
 *
 * functions with _inv: the input is the inverse of Sigma
 * rnorm_vec_inv() for multivariate normal distribution 
 * rnorm_mat_inv() for matrix-variate normal distribution 
 *
 * functions with _inv_chol: the input is the Cholesky factorization of the inverse of Sigma
 * rnorm_vec_inv() for multivariate normal distribution 
 * rnorm_mat_inv() for matrix-variate normal distribution 
 **********************************************************************/

void rnorm_std(Cmat &x);
void rnorm_vec(Cmat &x, Cmat &mu, Cmat &Sigma);
void rnorm_mat(Cmat &x, Cmat &mu, Cmat &Sigma1, Cmat &Sigma2);

void rnorm_vec_chol(Cmat &x, Cmat &mu, Cmat &Schol);
void rnorm_mat_chol(Cmat &x, Cmat &mu, Cmat &S1chol, Cmat &S2chol);

void rnorm_vec_inv(Cmat &x, Cmat &mu, Cmat &Sinv);
void rnorm_mat_inv(Cmat &x, Cmat &mu, Cmat &Sinv1, Cmat &Sinv2);

void rnorm_vec_inv_chol(Cmat &x, Cmat &mu, Cmat &Sinv_chol);
void rnorm_mat_inv_chol(Cmat &x, Cmat &mu, Cmat &Sinv1chol, Cmat &Sinv2chol);

/**********************************************************************
 * random number generation - Wishart distribution 
 * rwishart_std() for the standard Wishart distribution 
 * rwishart_std_chol() for the Cholesky facrtorization of a matrix with standard Wishart  
 * 
 * rwishart() for Wishart distribution 
 * rwishart_inv() for Wishart distribution, the input is the inverse of Wishart 
 *
 * functions with _chol: the input is the Cholesky factorization of Sigma
 * rwishart_chol() for Wishart distribution 
 * rwishart_inv_chol() for Wishart distribution, the input is the inverse of Wishart 
 **********************************************************************/

void rwishart_std(Cmat &x, double df);
void rwishart_std_chol(Cmat &x, double df);

void rwishart(Cmat &x, double df, Cmat &Sigma);
void rwishart_inv(Cmat &x, double df, Cmat &Sinv);

void rwishart_chol(Cmat &x, double df, Cmat &Schol);
void rwishart_inv_chol(Cmat &x, double df, Cmat &Sinv_chol);

/**********************************************************************
 * compute log density for inverse Wishart (df, Psi)
 * logd1_invWishart_inv(): -0.5 * trace(x_inv * Psi) - 0.5 * (df + p + 1) * logdet(X)
 * logd2_invWishart_inv(): logd1 + 0.5 * df * logdet(Psi)
 * log_invWishart_inv(): log2 - 0.5 * n * p * log(2) - logGamma(df/2)
 **********************************************************************/

double logd1_invWishart_inv(Cmat &x_inv, double df, Cmat &Psi);
double logd2_invWishart_inv(Cmat &x_inv, double df, Cmat &Psi);
double logd_invWishart_inv(Cmat &x_inv, double df, Cmat &Psi);

/**********************************************************************
 * inverse Gaussian distribution - log density, random number 
 **********************************************************************/

double log_dinvgauss(double x, double mu, double lambda); 
double rinvgauss(double mu, double lambda);

/**********************************************************************
 * random number generation - Gamma distribution 
 **********************************************************************/

/* double rgamma(shape, scale); */

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
