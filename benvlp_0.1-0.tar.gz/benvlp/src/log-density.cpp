/**********************************************************************
 * compute log-density 
 * updated: 2025-10-26
 **********************************************************************/

#include <R.h>
#include <iostream>

#include "distribution.hpp"

extern "C" {
/**********************************************************************
 * log-density -- normal distribution      
 **********************************************************************/

void log_dnorm_API(const double *x, const double *mu, const double *sd, double *ans)
{
    (*ans) = log_dnorm(*x, *mu, *sd); 
}

void log_dnorm_vec_API(const int *p, double *x, double *mu, double *Sigma, double *ans) 
{
    Cmat xvec(*p, 1, x);
    Cmat mvec(*p, 1, mu); 
    Cmat Smat(*p, *p, Sigma);  

    (*ans) = log_dnorm_vec(xvec, mvec, Smat);
}

void log_dnorm_mat_API(const int *m, const int *n, double *x, double *mu, 
    double *Sigma1, double *Sigma2, double *ans)
{
    Cmat xmat(*m, *n, x); 
    Cmat mmat(*m, *n, mu); 
    Cmat Smat1(*m, *m, Sigma1);  
    Cmat Smat2(*n, *n, Sigma2);  

    (*ans) = log_dnorm_mat(xmat, mmat, Smat1, Smat2);
}  

/**********************************************************************
 * log-density -- t distribution  
 **********************************************************************/

void log_dt_API(const double *x, const double *nu, const double *mu, const double *sd, double *ans)
{
    (*ans) = log_dt(*x, *nu, *mu, *sd); 
}

void log_dt_vec_API(const int *p, double *x, double *nu, double *mu, double *Sigma, double *ans) 
{
    Cmat xvec(*p, 1, x);
    Cmat mvec(*p, 1, mu); 
    Cmat Smat(*p, *p, Sigma);  

    (*ans) = log_dt_vec(xvec, *nu, mvec, Smat);
}

void log_dt_mat_API(const int *m, const int *n, double *x, double *nu, double *mu, 
    double *Sigma1, double *Sigma2, double *ans)
{
    Cmat xmat(*m, *n, x); 
    Cmat mmat(*m, *n, mu); 
    Cmat Smat1(*m, *m, Sigma1);  
    Cmat Smat2(*n, *n, Sigma2);  

    (*ans) = log_dt_mat(xmat, *nu, mmat, Smat1, Smat2);
}  

/**********************************************************************
 * THE END
 **********************************************************************/
}
