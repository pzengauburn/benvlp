/**********************************************************************
 * Class for integer matrices and vectors 
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-29 
 **********************************************************************/

#include <R.h> 
#include "Cimat.hpp" 

/**********************************************************************
 * constructor 
 *
 * list of variables: 
 *       int nrow;               number of rows 
 *       int ncol;               number of columns 
 *       int ld;                 leading dimension 
 *       int length;             length = ld * ncol - (ld - nrow) 
 *       int *value;             values 
 *       bool is_allocated;      true = allocated, false = assigned 
 *
 *       int inc;                increment when it is a vector 
 *       int vec_length;         length as a vector 
 **********************************************************************/

Cimat::Cimat() 
{
    this->nrow = 0; 
    this->ncol = 0; 
    this->ld = 0; 
    this->length = 0; 
    this->value = nullptr;
    this->is_allocated = false;  

    this->inc = 0; 
    this->vec_length = 0; 
}

Cimat::Cimat(int n_row, int n_col) 
{
    this->nrow = n_row; 
    this->ncol = n_col; 
    this->ld = n_row; 
    this->set_derived(); 

    this->value = new int[this->length](); 
    this->is_allocated = true;  
}

Cimat::Cimat(int n_row, int n_col, int *pt_values) 
{
    this->nrow = n_row; 
    this->ncol = n_col; 
    this->ld = n_row; 
    this->set_derived(); 

    this->value = pt_values;
    this->is_allocated = false;  
}

Cimat::Cimat(int n_row, int n_col, int n_ld) 
{
    this->nrow = n_row; 
    this->ncol = n_col; 
    this->ld = n_ld; 
    this->set_derived(); 

    this->value = new int[this->length]();
    this->is_allocated = true;  
}

Cimat::Cimat(int n_row, int n_col, int *pt_values, int n_ld) 
{
    this->nrow = n_row; 
    this->ncol = n_col; 
    this->ld = n_ld; 
    this->set_derived(); 

    this->value = pt_values;
    this->is_allocated = false;  
}

/* set derived variables in the constructor */

void Cimat::set_derived()
{
    if((this->ld) < (this->nrow))
    {
        std::cerr << "ld = " << this->ld << ", nrow = " << this->nrow << std::endl;
        error("Cimat::set_derive(): ld < nrow is not allowed.\n"); 
    }

    this->length = (this->ld) * (this->ncol) - (this->ld - this->nrow); 

    if(this->is_vector()) 
    {
        this->inc = (this->ncol == 1) ? (1) : (this->ld);
        this->vec_length = (this->ncol == 1) ? (this->nrow) : (this->ncol); 
    }
    else 
    {
        this->inc = 0; 
        this->vec_length = 0; 
    }
} 

/**********************************************************************
 * destructor 
 **********************************************************************/

Cimat::~Cimat() 
{
    if(this->is_allocated) delete[] this->value;  
} 

/**********************************************************************
 * get or set values 
 **********************************************************************/

int Cimat::get_nrow()
{
    return(this->nrow); 
}

int Cimat::get_ncol() 
{
    return(this->ncol); 
}

int Cimat::get_ld() 
{
    return(this->ld); 
}

int Cimat::get_length()
{
    return(this->length); 
}

int Cimat::get_inc()
{
    if(!(this->is_vector()))
        warning("Cimat::get_inc(): try to get inc for a matrix.\n"); 

    return(this->inc); 
}

int Cimat::get_vec_length()
{
    if(!(this->is_vector()))
        warning("Cimat::get_vec_length(): try to get vec_length for a matrix.\n"); 

    return(this->vec_length); 
}

int Cimat::get_entry(int row, int col)
{
    return(this->value[row + col * (this->ld)]); 
}

int Cimat::get_entry_vec(int i)
{
    return(this->value[i * (this->inc)]); 
}

int *Cimat::get_value_pt() 
{
    return(this->value); 
}

void Cimat::set_entry(int row, int col, int a)
{
    this->value[row + col * (this->ld)] = a; 
}

void Cimat::set_entry_vec(int i, int a)
{
    this->value[i * (this->inc)] = a; 
} 

void Cimat::set_value_pt(int *pt_values)
{
    /* release the memory if it is allocated */
    if(this->is_allocated) delete[] this->value;

    this->is_allocated = false; 
    this->value = pt_values; 
}

/**********************************************************************
 * write matrix to file  
 **********************************************************************/

void Cimat::write2stream(std::ostream &stream)
{    
    stream << "----------========== matrix ==========----------\n"; 
    stream << "nrow = " << this->nrow 
           << ", ncol = " << this->ncol 
           << ", ld = " << this->ld << std::endl;
    stream << "----------========== values ==========----------\n"; 

    /* write matrix to the text file */
    for(int i = 0; i < this->nrow; i++)
    {
        for(int j = 0; j < this->ncol; j++)
        {
            stream<< this->value[i + j * (this->ld)] << "   "; 
        }
        stream << std::endl; 
    }

    stream << "----------========== end of values ==========----------\n\n" << std::endl;
}

/* write to a new file */

void Cimat::write2file(const char *filename)
{
    std::ofstream file(filename);
    if(!file.is_open())
        error("Cimat::write2file(): Failed to open the file to write.\n"); 

    this->write2stream(file); 
    file.close(); 
}

/* append to an existing file */

void Cimat::write2file_app(const char *filename)
{
    std::ofstream file(filename, std::ios::app);
    if(!file.is_open())
        error("Cimat::write2file_app(): Failed to open the file to write.\n"); 

    this->write2stream(file); 
    file.close(); 
}

/**********************************************************************
 * matrix operations 
 **********************************************************************/

/* values are saved in a contiguous memory block */

void Cimat::copy(const int *pt_values)
{
    if(this->nrow == this->ld)
    {
        this->copy_mem(pt_values); 
    }
    else 
    {
        int count = 0; 
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
        {
            this->value[i + j * (this->ld)] = pt_values[count]; 
            count++; 
        }
    }
}

/* directly copy a contiguous memory block without checking */

void Cimat::copy_mem(const int *pt_values)
{
    memcpy(this->value, pt_values, (this->length) * sizeof(int)); 
}

/* copy values from an existing matrix */

void Cimat::copy(Cimat &A)
{
    if((this->nrow != A.nrow) || (this->ncol != A.ncol))
        error("Cimat::copy(): incompatible dimensions.\n"); 

    if((this->ld == this->nrow) && (A.ld == A.nrow))
        this->copy_mem(A.get_value_pt());
    else if(A.ld == A.nrow)
        this->copy(A.get_value_pt()); 
    else 
    {
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
            this->value[i + j * (this->ld)] = A.get_entry(i, j); 
    } 
}                  

/* write matrix to a contiguous memory block of length size */
void Cimat::write(int *pt_values, int size)
{
    if(size < (this->nrow) * (this->ncol))
        error("Cimat::write(): the size of the memory block is too small.\n"); 

    if(this->nrow == this->ld)
    {
        this->write_mem(pt_values, size); 
    }
    else 
    {
        int count = 0; 
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
        {
            pt_values[count] = this->value[i + j * (this->ld)]; 
            count++; 
        }
    }
}      

/* directly write matrix to a contiguous memory block of length size without checking*/

void Cimat::write_mem(int *pt_values, int size) 
{
    if(size < this->length)
        error("Cimat::write_mem(): the size of the memory block is too small.\n"); 

    memcpy(pt_values, this->value, (this->length) * sizeof(int));
}

/* set all values as zero */ 

void Cimat::set_zero()
{
    if((this->nrow) == (this->ld))
    {
        memset(this->value, 0, (this->length) * sizeof(int)); 
    }
    else 
    {
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
        {
            this->value[i + j * (this->ld)] = 0; 
        }
    }
} 

/* set all values to be a constant */

void Cimat::set_const(int a)
{
    for(int i = 0; i < this->nrow; i++)
    for(int j = 0; j < this->ncol; j++)
        this->value[i + j * (this->ld)] = a; 
}   

/* check whether it is a scalar */

bool Cimat::is_scalar()
{
    return((this->nrow == 1) && (this->ncol == 1)); 
} 

/* check whether it is a vector */

bool Cimat::is_vector()
{
    return((this->nrow == 1) || (this->ncol == 1)); 
} 

/* check whether it is a square matrix */

bool Cimat::is_square()
{
    return(this->nrow == this->ncol); 
} 

/**********************************************************************
 * more matrix operations
 **********************************************************************/

/* find the maximum of the matrix */

int Cimat::max()      
{
    int ans = this->value[0];
    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        if(ans < this->value[i + j * (this->ld)]) 
            ans = this->value[i + j * (this->ld)]; 

    return(ans); 
}

/* find the minimum of the matrix */
        
int Cimat::min()      
{
    int ans = this->value[0];
    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        if(ans > this->value[i + j * (this->ld)]) 
            ans = this->value[i + j * (this->ld)]; 

    return(ans); 
}

/**********************************************************************
 * THE END
 **********************************************************************/
