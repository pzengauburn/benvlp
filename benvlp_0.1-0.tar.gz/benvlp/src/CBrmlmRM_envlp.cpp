/**********************************************************************
 * Class for Bayesian inference for multivariate linear regression  
 * with repeated measures and envelope structure, t-distribution  
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-24  
 **********************************************************************/

#include <R.h> 
#include "CBrmlmRM_envlp.hpp" 
#undef beta 

/**********************************************************************
 * variables defined in Creg: (5)
 *     Cmat *x;                     predictor - p-by-n matrix 
 *     Cmat *y;                     response - r-by-n matrix 
 *     int n_obs;                   number of observations 
 *     int p_var;                   number of predictors 
 *     int r_resp;                  number of responses 
 *
 * variables defined in Clinreg: (4)  
 *     bool has_intercept;          true = with intercept, false = no intercept 
 *     Cmat *alpha;                 intercept - r-by-1 matrix 
 *     Cmat *beta;                  slope - r-by-p matrix 
 *     Cmat *res;                   residual - r-by-n matrix 
 * 
 * variables defined in ClinregRM: (9)
 *     int m_sub;                   number of subjects 
 *     int Jmax;                    max(Jvec) 
 *     Cimat *Jvec;                 number of observations for each subject, length = m_sub 
 *     Corr_Type ctype;             correlation structure 
 *     double rho;                  parameter in correlation 
 *     Cmat *Sigma_inv;             r-by-r matrix 
 *     Cmat *deltaRM;               msub-by-1 matrix 
 *     double pro_rho_delta;        scalar - tuning parameter 
 *     int rho_count;               count the number of accepted rho 
 *
 * variables defined in Cmcmc: (13)
 *     int burn_in_mcmc;            number of samples to be discarded 
 *     int size_mcmc;               number of samples after burn-in period 
 *     int thinning_mcmc;           save every k-th samples 
 *     int info_mcmc;               display information every k samples 
 *     int count_mcmc;              total number of samples generated 
 *     int count_output_mcmc;       number of samples saved 
 *     int length_pars;             length of parameters, including latent variables 
 *     double *pars;                vector of parameters, length = length_pars 
 *     int max_saved_draws;         maximum number of saved samples 
 *     int length_saved_pars;       length of parameters to be saved 
 *     double *samples;             space to save samples = max_saved_draws * length_saved_pars 
 *     int length_hyperpars;        number of hyperparameters in prior distribution 
 *     int length_tuning;           number of tuning parameters in proposal distribution
 *
 * variables defined in Cenvlp: (8)
 *     int u_dim;                   dimension u 
 *     Cmat *A;                     (r-u)-by-u matrix 
 *     Cmat *U;                     r-by-r matrix 
 *     Cmat *Gamma;                 r-by-u matrix 
 *     Cmat *Gamma0;                r-by-(r-u) matrix 
 *     Cmat *hyper_Amat_Mmat;       r-by-r matrix  --  hyperparameter in prior  
 *     double pro_Amat_sigma2;      scalar -- hyperparameter in proposal distribution 
 *     int A_count;                 count the number of accepted Amat 
 *
 * variables defined in GBtGamma: (6)
 *     Cmat *tau;                   latent variable 
 *     double nu;                   degrees of freedom 
 *     double hyper_nu_shape;       scalar - hyperparameter in Gamma distribution 
 *     double hyper_nu_rate;        scalar - hyperparameter in Gamma distribution 
 *     double pro_nu_delta;         tuning parameter in proposal distribution 
 *     int nu_count;                count the number of accepted nu 
 *
 * variables defined in CBrmlmRM_envlp: (11)
 *     Cmat *eta;                   u-by-p matrix 
 *     Cmat *Omega_inv;             u-by-u matrix 
 *     Cmat *Omega0_inv;            (r-u)-by-(r-u) matrix 
 *     bool assume_normal;          1 = normal, 0 = t-distribution 
 *     Cmat *hyper_eta_mean;        r-by-p matrix  --  hyper-parameter in prior  
 *     Cmat *hyper_eta_col_inv;     p-by-p matrix  --  hyper-parameter in prior
 *     double hyper_Omega_df;       scalar  --  hyperparameter in prior 
 *     Cmat *hyper_Omega_scale;     u-by-u matrix  --  hyperparameter in prior  
 *     double hyper_Omega0_df;      scalar  --  hyperparameter in prior  
 *     Cmat *hyper_Omega0_scale;    (r-u)-by-(r-u) matrix  --  hyperparameter in prior  
 *     Cmat *hyper_eta_mean_inv;    r-by-p matrix = eta_mean %*% eta_col_inv 
 **********************************************************************/

CBrmlmRM_envlp::CBrmlmRM_envlp()
{
    this->eta = nullptr;
    this->Omega_inv = nullptr;
    this->Omega0_inv = nullptr;
    this->assume_normal = true; 
    this->hyper_eta_mean = nullptr;
    this->hyper_eta_col_inv = nullptr;
    this->hyper_Omega_df = 0.0; 
    this->hyper_Omega_scale = nullptr; 
    this->hyper_Omega0_df = 0.0; 
    this->hyper_Omega0_scale = nullptr; 
    this->hyper_eta_mean_inv = nullptr; 
}

CBrmlmRM_envlp::CBrmlmRM_envlp(Cmat *x_pt, Cmat *y_pt, int u, Cimat *Jvec_pt, Corr_Type cp,
                bool normal, int burn_in, int size, int thinning, int info, int length,  
                Cmat *Umat)
    : ClinregRMt(x_pt, y_pt, true, Jvec_pt, cp),
      Cmcmc(burn_in, size, thinning, info, length), 
      Cenvlp(y_pt->get_nrow(), u, Umat) 
{
    /* parameters = (rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    /* length = 1 + 1 + msub + r + u*p + (r-u)*u + u*u + (r-u)*(r-u)*/

    this->length_pars =   1                                                                      /* rho (1) */
                        + 1                                                                      /* nu (1) */
                        + (this->m_sub)                                                          /* tau (m_sub) */
                        + (this->r_resp)                                                         /* alpha (r-by-1) */
                        + (this->u_dim) * (this->p_var)                                          /* eta (u-by-p) */                                    
                        + ((this->r_resp) - (this->u_dim)) * (this->u_dim)                       /* Amat ((r-u)-by-u) */
                        + (this->u_dim) * (this->u_dim)                                          /* Omega_inv (u-by-u) */
                        + ((this->r_resp) - (this->u_dim)) * ((this->r_resp) - (this->u_dim));   /* Omega0_inv ((r-u)-by-(r-u)) */

    if(length < (this->length_pars)) 
    {
        std::cout << "length = " << length << std::endl;
        std::cout << "length_pars = " << this->length_pars << std::endl; 
        error("CBrmlmRM_envlp::CBrmlmRM_envlp(): incorrect number of parameters.\n"); 
    }

    this->eta = new Cmat(this->u_dim, this->p_var, nullptr); 
    this->Omega_inv = new Cmat(this->u_dim, this->u_dim, nullptr);
    this->Omega0_inv = new Cmat((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim), nullptr);

    this->assume_normal = normal; 

    /* link the parameters to the space allocated in Cmcmc */    
    int offset = 2;                                       /* the first two are rho, nu */          
    this->tau->set_value_pt(this->pars + offset); 
    offset += (this->m_sub); 
    this->alpha->set_value_pt(this->pars + offset);
    offset += (this->r_resp); 
    this->eta->set_value_pt(this->pars + offset);
    offset += (this->u_dim) * (this->p_var); 
    this->A->set_value_pt(this->pars + offset); 
    offset += ((this->r_resp) - (this->u_dim)) * (this->u_dim); 
    this->Omega_inv->set_value_pt(this->pars + offset); 
    offset += (this->u_dim) * (this->u_dim); 
    this->Omega0_inv->set_value_pt(this->pars + offset); 

    /* cache calculation results */
    delete this->beta;  /* release the current memory */
    this->beta = new Cmat(this->r_resp, this->p_var); 
    delete this->Sigma_inv; 
    this->Sigma_inv = new Cmat(this->r_resp, this->r_resp);

    this->hyper_eta_mean = new Cmat(this->r_resp, this->p_var);
    this->hyper_eta_col_inv = new Cmat(this->p_var, this->p_var); 
    this->hyper_Omega_scale = new Cmat(this->u_dim, this->u_dim);     
    this->hyper_Omega0_scale = new Cmat((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim));   

    this->hyper_eta_mean_inv = new Cmat(this->r_resp, this->p_var); 

    this->hyper_Omega_df = 0.0; 
    this->hyper_Omega0_df = 0.0; 

    /* length of all hyperparameters combined */ 
    this->length_hyperpars = ((this->hyper_eta_mean->get_length())         /* beta_mean (r-by-p) */
                            + (this->hyper_eta_col_inv->get_length())      /* best_col_inv (p-by-p) */
                            + 1                                            /* Omega_df (1) */
                            + (this->hyper_Omega_scale->get_length())      /* Omega_scale (u-by-u) */
                            + 1                                            /* Omega0_df (1) */
                            + (this->hyper_Omega0_scale->get_length())     /* Omega0_scale ((r-u)-by-(r-u)) */
                            + (this->hyper_Amat_Mmat->get_length())        /* Mat (r-by-r) */
                            + 1                                            /* nu_shape */
                            + 1);                                          /* nu_rate */
    

    /* length of all hyper-parameters in proposal distributions combined */ 
    this->length_tuning = 3;                                               /* rho_delta, Pmat.sigma2, nu_delta */    
}

/**********************************************************************
 * destructor 
 **********************************************************************/

CBrmlmRM_envlp::~CBrmlmRM_envlp() 
{
    delete this->eta; 
    delete this->Omega_inv; 
    delete this->Omega0_inv; 

    delete this->hyper_eta_mean;
    delete this->hyper_eta_col_inv;
    delete this->hyper_eta_mean_inv;

    delete this->hyper_Omega_scale; 
    delete this->hyper_Omega0_scale; 
} 

/**********************************************************************
 * set initial parameters  
 * (rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv)
 **********************************************************************/

void CBrmlmRM_envlp::set_ini_pars(int length, double *pt) 
{
    if(((this->length_pars) != length))
        error("CBrmlmRM_envlp::set_ini_pars(): incorrect dimension.\n"); 

    int offset = 0; 
    this->rho = pt[offset]; 
    offset ++; 

    this->nu = pt[offset];
    offset ++; 

    this->tau->copy(pt + offset); 
    offset += this->tau->get_length(); 

    this->alpha->copy(pt + offset); 
    offset += this->alpha->get_length(); 

    this->eta->copy(pt + offset); 
    offset += this->eta->get_length(); 

    this->A->copy(pt + offset);
    offset += this->A->get_length(); 

    this->Omega_inv->copy(pt + offset); 
    offset += this->Omega_inv->get_length(); 

    this->Omega0_inv->copy(pt + offset);
}

/**********************************************************************
 * set hyper-parameters  
 * (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mmat, nu_shape, nu_rate)
 **********************************************************************/

void CBrmlmRM_envlp::set_hyperpars(int length, double *pt) 
{
    if((this->length_hyperpars) != length) 
    {
        std::cout << "length_hyperpars = " << this->length_hyperpars << std::endl;
        std::cout << "length = " << length << std::endl;
        error("CBrmlmRM_envlp::set_hyperpars(): incorrect dimension.\n");
    }
    
    int offset = 0; 

    this->hyper_eta_mean->copy(pt + offset);
    offset += this->hyper_eta_mean->get_length(); 

    this->hyper_eta_col_inv->copy(pt + offset); 
    offset += this->hyper_eta_col_inv->get_length(); 

    this->hyper_eta_mean_inv->gemm("N", "N", 1.0, *(this->hyper_eta_mean), *(this->hyper_eta_col_inv), 0.0); 
   
    this->hyper_Omega_df = pt[offset]; 
    offset ++; 

    this->hyper_Omega_scale->copy(pt + offset); 
    offset += this->hyper_Omega_scale->get_length(); 

    this->hyper_Omega0_df = pt[offset]; 
    offset ++;

    this->hyper_Omega0_scale->copy(pt + offset); 
    offset += this->hyper_Omega0_scale->get_length(); 

    this->hyper_Amat_Mmat->copy(pt + offset); 
    offset += this->hyper_Amat_Mmat->get_length(); 

    this->hyper_nu_shape = pt[offset];
    offset ++;

    this->hyper_nu_rate = pt[offset];
}

/**********************************************************************
 * set tuning parameters  
 **********************************************************************/

void CBrmlmRM_envlp::set_tuning(int length, double *pt)
{
    if(length != 3)
        error("CBrmlmRM_envlp::set_propars(): incorrect dimension.\n");

    this->pro_rho_delta = pt[0];
    this->pro_Amat_sigma2 = pt[1];
    this->pro_nu_delta = pt[2]; 
} 

/**********************************************************************
 * write information to a stream 
 **********************************************************************/

void CBrmlmRM_envlp::write2stream(std::ostream &stream)
{
    Creg::write2stream(stream); 

    stream << "\nnumber of subject = " << this->m_sub << std::endl;

    stream << "\ncorrelation type = ";  
    if(this->ctype == Corr_Type::iid) stream << "IID\n";
    else if(this->ctype == Corr_Type::cs) stream << "CS\n";
    else if (this->ctype == Corr_Type::ar1) stream << "AR1\n";
    else stream << "unsupported corelation type.\n"; 
    
    stream << "\nrho = " << this->rho << std::endl;
    stream << "\nJvec = (" << this->Jvec->get_entry_vec(0) << ", ..., " 
           << this->Jvec->get_entry_vec(this->m_sub - 1) << ")\n";

    stream << "\nerror distribution = ";   
    if(this->assume_normal) stream << "1 = normal distribution\n";
    else stream << "0 = t-distribution\n";     

    stream << "\nnu = " << this->nu << std::endl;
    stream << "\ntau = (" << this->tau->get_entry_vec(0) << ", ..., " 
           << this->tau->get_entry_vec(this->m_sub - 1) << ")\n";

    stream << "\nalpha =\n";
    this->alpha->write2stream(stream, false);

    stream << "\neta =\n"; 
    this->eta->write2stream(stream, false); 

    stream << "\nA =\n"; 
    this->A->write2stream(stream, false); 

    stream << "\nOmega_inv =\n"; 
    this->Omega_inv->write2stream(stream, false); 

    stream << "\nOmega0_inv =\n"; 
    this->Omega0_inv->write2stream(stream, false); 

    Cmcmc::write2stream(stream); 

    stream << "\nhyper_eta_mean =\n";
    this->hyper_eta_mean->write2stream(stream, false);

    stream << "\nhyper_eta_col_inv =\n";
    this->hyper_eta_col_inv->write2stream(stream, false);

    stream << "\nhyper_Omega_df = " << this->hyper_Omega_df << std::endl;

    stream << "\nhyper_Omega_scale =\n";
    this->hyper_Omega_scale->write2stream(stream, false);

    stream << "\nhyper_Omega0_df = " << this->hyper_Omega0_df << std::endl;

    stream << "\nhyper_Omega0_scale =\n";
    this->hyper_Omega0_scale->write2stream(stream, false);

    stream << "\nhyper_Amat_Mmat =\n";
    this->hyper_Amat_Mmat->write2stream(stream, false);

    stream << "\nhyper_nu_shape = " << this->hyper_nu_shape << std::endl;
    stream << "\nhyper_nu_rate = " << this->hyper_nu_rate << std::endl;

    stream << "\npro_rho_delta = " << this->pro_rho_delta << std::endl;
    stream << "\npro_Amat_sigma2 = " << this->pro_Amat_sigma2 << std::endl;    
    stream << "\npro_nu_delta = " << this->pro_nu_delta << std::endl;
}  

/**********************************************************************
 * sample from posterior distributions 
 **********************************************************************/

/**********************************************************************
 * sample eta 
 * 
    cov.eta = hyper.pars$eta.cov.inv; 
    mu.eta = hyper.pars$eta.mean %*% hyper.pars$eta.cov.inv; 
    res.beta = sweep(prob$y, 2, drop(iSample$alpha), "-"); 
    for(i in 1:prob$nsubject)
    {
        R.inv = cor.inv(prob$Jvec[i], iSample$rho, prob$cor.type); 
        Xi = prob$x[prob$subject == i, , drop = FALSE];
        cov.eta = cov.eta + iSample$tau[i] * (t(Xi) %*% R.inv %*% Xi); 
        mu.eta = mu.eta + iSample$tau[i] * (t(res.beta[prob$subject == i, , drop = FALSE]) %*% R.inv %*% Xi);
    }

    cov.eta.inv = solve(cov.eta); 
    iSample$eta = matrix(MASS::mvrnorm(1, 
                    mu = matrix(t(iSample$Gamma) %*% mu.eta %*% cov.eta.inv, ncol = 1),
                    Sigma = kronecker(cov.eta.inv, solve(iSample$Omega.inv))),
                    nrow = prob$u, ncol = prob$p);
        
    # update beta, res, Delta 
    iSample$beta = iSample$Gamma %*% iSample$eta; 
    iSample$res = tenvlp2.compute.res(prob, iSample); 
    iSample$Delta = tenvlp2.compute.Delta(prob, iSample); 
 **********************************************************************/

void CBrmlmRM_envlp::sample_eta()
{
    /* res = y - alpha * 1^T */
    this->res->copy(*(this->y)); 
    this->res->axpy_col(-1.0, *(this->alpha)); 

    /* cov.eta = hyper.pars$eta.cov.inv */
    Cmat cov_eta(this->p_var, this->p_var); 
    cov_eta.copy(*(this->hyper_eta_col_inv));

    /* mu.eta = hyper.pars$eta.mean %*% hyper.pars$eta.cov.inv */
    Cmat mu_eta(this->r_resp, this->p_var); 
    mu_eta.copy(*(this->hyper_eta_mean_inv));

    for(int i = 0, pos_res = 0, pos_x = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        /* Rinvxi = Rinv %*% x[index, ]; */
        Cmat xi(this->p_var, Ji, this->x->get_value_pt() + pos_x); 
        Cmat Rinvxi(Ji, this->p_var); 
        Rinvxi.gemm("N", "T", 1.0, Rinv, xi, 0.0); 

        /* cov.eta = cov.eta + iSample$tau[i] * (t(Xi) %*% R.inv %*% Xi) */
        cov_eta.gemm("N", "N", this->tau->get_entry_vec(i), xi, Rinvxi, 1.0);
                 
        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos_res); 
        /* mu.eta = mu.eta + iSample$tau[i] * (t(res.beta[prob$subject == i, , drop = FALSE]) %*% R.inv %*% Xi) */
        mu_eta.gemm("N", "N", this->tau->get_entry_vec(i), res_i, Rinvxi, 1.0);  

        /* update position for res_i */
        pos_x += Ji * (this->p_var); 
        pos_res += Ji * (this->r_resp); 
    }
    
    cov_eta.chol();
    mu_eta.solve_chol_right(cov_eta, 1.0);

    /* mu_beta = t(iSample$Gamma) %*% xi.new */
    Cmat mu_beta(this->u_dim, this->p_var);
    mu_beta.gemm("T", "N", 1.0, *(this->Gamma), mu_eta, 0.0); 

    this->Omega_inv->chol(); 
    rnorm_mat_inv_chol(*(this->eta), mu_beta, *(this->Omega_inv), cov_eta);
}

/**********************************************************************
 * sample Omega_inv and Omega0_inv 
 *
    yRy = matrix(0, nrow = prob$r, ncol = prob$r); 
    for(i in 1:prob$nsubject)
    {
        R.inv = cor.inv(prob$Jvec[i], iSample$rho, prob$cor.type); 
        yRy = yRy + iSample$tau[i] * 
                    (t(iSample$res[prob$subject == i, , drop = FALSE]) %*% 
                        R.inv %*% 
                        iSample$res[prob$subject == i, , drop = FALSE]); 
    }
    mat.Omega = t(iSample$Gamma) %*% yRy %*% iSample$Gamma; 
    mat.Omega = mat.Omega + hyper.pars$Omega.scale; 
    vec = iSample$eta - t(iSample$Gamma) %*% hyper.pars$eta.mean; 
    mat.Omega = mat.Omega + vec %*% hyper.pars$eta.cov.inv %*% t(vec); 

    iSample$Omega.inv = drop(rWishart(1, 
            df = hyper.pars$Omega.df + prob$p + prob$sumJ, 
            Sigma = solve(mat.Omega)));

    mat.Omega0 = t(iSample$Gamma0) %*% yRy %*% iSample$Gamma0; 
    mat.Omega0 = mat.Omega0 + hyper.pars$Omega0.scale; 

    iSample$Omega0.inv = drop(rWishart(1, 
            df = hyper.pars$Omega0.df + prob$sumJ, 
            Sigma = solve(mat.Omega0))); 

    # update Delta  
    iSample$Sigma.e.inv = Gamma2Sigma(iSample$Gamma, iSample$Gamma0, iSample$Omega.inv, iSample$Omega0.inv); 
    iSample$res = envlp.compute.res(prob, iSample); 
    iSample$Delta = envlp.compute.Delta(prob, iSample); 
 **********************************************************************/

void CBrmlmRM_envlp::sample_Omegas()
{
    Cmat res2(this->r_resp, this->r_resp);
    res2.set_zero();

    for(int i = 0, pos = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        /* Psi.new = Psi.new + iSample$tau[i] * t(res[index, ]) %*% Rinv %*% res[index, ]; */
        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos); 
        res2.ABAt(this->tau->get_entry_vec(i), res_i, Rinv, 1.0); 

        /* update position for res_i */
        pos += Ji * (this->r_resp); 
    }

    /* bxi = iSample$eta - t(iSample$Gamma) %*% hyper.pars$xi */
    Cmat bxi(this->u_dim, this->p_var); 
    bxi.copy(*(this->eta));
    bxi.gemm("T", "N", -1.0, *(this->Gamma), *(this->hyper_eta_mean), 1.0);  

    /* Psi.new = hyper.pars$Psi + bHb + t(iSample$Gamma) %*% res2 %*% iSample$Gamma; */
    Cmat Psi_new(this->u_dim, this->u_dim);
    Psi_new.copy(*(this->hyper_Omega_scale));
    Psi_new.ABAt(1.0, bxi, *(this->hyper_eta_col_inv), 1.0); 
    Psi_new.AtBA(1.0, *(this->Gamma), res2, 1.0); 

    double df = this->hyper_Omega_df + (double)(this->n_obs) + (double)(this->p_var);
    rwishart_inv(*(this->Omega_inv), df, Psi_new);  

    /* Psi0.new = hyper.pars$Psi0 + t(iSample$Gamma0) %*% res2 %*% iSample$Gamma0; */
    Cmat Psi0_new((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim));
    Psi0_new.copy(*(this->hyper_Omega0_scale));
    Psi0_new.AtBA(1.0, *(this->Gamma0), res2, 1.0); 

    double df0 = this->hyper_Omega_df + (double)(this->n_obs);
    rwishart_inv(*(this->Omega0_inv), df0, Psi0_new);  
}

/**********************************************************************
 * sample Amat 
 *
    A.loglik.old = tenvlp2.compute.A.loglik(iSample, hyper.pars); 

    A.new = tenvlp2.propose.Amat(prob, iSample, pro.pars); 
    iSample.new = tenvlp2.update.Amat(prob, iSample, A.new);
    A.loglik.new = tenvlp2.compute.A.loglik(iSample.new, hyper.pars); 

    A.prop.old = tenvlp2.compute.A.proposal(iSample$Gamma, iSample.new, pro.pars);
    A.prop.new = tenvlp2.compute.A.proposal(iSampe.new$Gamma, iSample, pro.pars);

    A.logratio = A.loglik.new - A.loglik.old + A.prop.old - A.prop.new; 
    if(log(runif(1)) < A.logratio)
    {
        iSample = iSample.new; 
        iSample$A.count = iSample$A.count + 1; 
    }
 **********************************************************************/

void CBrmlmRM_envlp::sample_Amat()
{
    /* compute loglik based on the current values */
    double old_loglik = this->compute_loglik_Amat(); 

    /* save current values */
    Cmat current_Amat((this->r_resp) - (this->u_dim), (this->u_dim)); 
    Cmat current_Gamma(this->r_resp, this->u_dim); 
    Cmat current_Gamma0(this->r_resp, (this->r_resp) - (this->u_dim));
    Cmat current_Sigma_inv(this->r_resp, this->r_resp); 
    Cmat current_beta(this->r_resp, this->p_var); 
    Cmat current_res(this->r_resp, this->n_obs); 
    Cmat current_deltaRM(this->m_sub, 1); 

    current_Amat.copy(*(this->A)); 
    current_Gamma.copy(*(this->Gamma)); 
    current_Gamma0.copy(*(this->Gamma0)); 
    current_Sigma_inv.copy(*(this->Sigma_inv));
    current_beta.copy(*(this->beta)); 
    current_res.copy(*(this->res)); 
    current_deltaRM.copy(*(this->deltaRM)); 

    /* propose a new Amat */
    this->propose_Amat();

    /* update affected parameters */
    this->compute_Gammas(); 
    this->Sigma_restore(*(this->Sigma_inv), *(this->Omega_inv), *(this->Omega0_inv)); 
    this->beta_restore(*(this->beta), *(this->eta)); 
    this->compute_residual(); 
    this->compute_deltaRM(); 

    /* compute loglik based on the proposed values */
    double new_loglik = this->compute_loglik_Amat(); 

    if(log(unif_rand()) < (new_loglik - old_loglik))
    {
        /* accept the proposed Amat */
        (this->A_count)++; 
    }
    else 
    {
        /* keep the current values */
        this->A->copy(current_Amat); 
        this->Gamma->copy(current_Gamma);
        this->Gamma0->copy(current_Gamma0); 
        this->Sigma_inv->copy(current_Sigma_inv);
        this->beta->copy(current_beta); 
        this->res->copy(current_res); 
        this->deltaRM->copy(current_deltaRM); 
    }
}

/**********************************************************************
 * compute loglikelihood when sampling Amat 
 *
    vec1 = iSample$eta - t(iSample$Gamma) %*% hyper.pars$eta.mean; 
    vec2 = iSample$Amat - hyper.pars$A.mean;
    (-0.5 * sum(iSample$tau * iSample$Delta)
     -0.5 * sum((iSample$Omega.inv %*% vec1 %*% hyper.pars$eta.cov.inv) * vec1) 
     + sum(diag(t(iSample$Gamma) %*% hyper.pars$P.Mmat %*% iSample$Gamma))); 
 **********************************************************************/

double CBrmlmRM_envlp::compute_loglik_Amat()
{
    double loglik = this->deltaRM->dot(*(this->tau)); 

    /* bxi = iSample$eta - t(iSample$Gamma) %*% hyper.pars$eta.mean; */
    Cmat bxi(this->u_dim, this->p_var); 
    bxi.copy(*(this->eta));
    bxi.gemm("T", "N", -1.0, *(this->Gamma), *(this->hyper_eta_mean), 1.0);  

    /* eHe = vec %*% hyper.pars$eta.cov.inv %*% t(vec); */
    Cmat eHe(this->u_dim, this->u_dim);
    eHe.ABAt(1.0, bxi, *(this->hyper_eta_col_inv), 0.0); 

    loglik += eHe.dot(*(this->Omega_inv)); 
    loglik *= (-0.5); 

    /* eHe = t(iSample$Gamma) %*% hyper.pars$P.Mmat %*% iSample$Gamma) */
    eHe.AtBA(1.0, *(this->Gamma), *(this->hyper_Amat_Mmat), 0.0); 
    loglik += eHe.trace(); 

    return(loglik); 
} 

/**********************************************************************
 * compute log-likelihood 
 **********************************************************************/

double CBrmlmRM_envlp::compute_loglik()
{
    double logdetS = - (this->Omega_inv->logdet_chol()) - (this->Omega0_inv->logdet_chol());

    double loglik = 0.0;
    for(int i = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        Ccormat cor(Ji, this->ctype, this->rho); 
        double logdetR = cor.logdet(); 

        if(this->assume_normal)
        {
            /* true = normal */
            loglik += log_dMnorm0(this->r_resp, Ji, 
                            this->deltaRM->get_entry_vec(i), logdetS, logdetR); 
        }
        else 
        {
            /* false = t-distribution */
            loglik += log_dMT0(this->r_resp, Ji, this->nu, 
                            this->deltaRM->get_entry_vec(i), logdetS, logdetR); 
        }
    }

    return(loglik); 
}

/**********************************************************************
 * compute posterior means  
 * (rho, nu, tau, alpha, eta, Amat, Omega, Omega0)
 **********************************************************************/

void CBrmlmRM_envlp::compute_posterior_mean(int length, double *pt)
{
    if((this->length_saved_pars) != length)
        error("CBrmlmRM_envlp::compute_posterior_mean(): wrong size of pt.\n"); 
 
    const int length_abrA = 1 + 1 + this->tau->get_length() + this->alpha->get_length() + this->eta->get_length() + this->A->get_length();
    Cmat alpha_beta_r_A(length_abrA, 1, pt);
    Cmat alpha_beta_r_A_samples(length_abrA, this->count_output_mcmc, this->samples, this->length_saved_pars); 
    alpha_beta_r_A.rowMeans(alpha_beta_r_A_samples);
     
    Cmat Omega_mean(this->u_dim, this->u_dim, pt + length_abrA); 
    Omega_mean.set_zero(); 

    const int length_abrAOmega = length_abrA + this->Omega_inv->get_length(); 
    Cmat Omega0_mean((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim), pt + length_abrAOmega); 
    Omega0_mean.set_zero(); 
    
    double sc = 1.0 / (double)(this->count_output_mcmc); 
    Cmat iOmega(this->u_dim, this->u_dim);
    Cmat iOmega0((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim));
    
    for(int i = 0; i < (this->count_output_mcmc); i++)
    {
        iOmega.copy((this->samples) + i * (this->length_saved_pars) + length_abrA); 
        iOmega.inv(); 
        Omega_mean.axpy(sc, iOmega); 

        iOmega0.copy((this->samples) + i * (this->length_saved_pars) + length_abrAOmega); 
        iOmega0.inv(); 
        Omega0_mean.axpy(sc, iOmega0); 
    }
}
 
/**********************************************************************
 * Markov Chain Monte Carlo 
 **********************************************************************/

void CBrmlmRM_envlp::mcmc_initialize()
{
    this->compute_Gammas(); 
    this->Sigma_restore(*(this->Sigma_inv), *(this->Omega_inv), *(this->Omega0_inv)); 
    this->beta_restore(*(this->beta), *(this->eta)); 

    if(this->assume_normal)
    {
        this->tau->set_const(1.0); 
        this->nu = 1000; 
    }

    if(this->ctype == Corr_Type::iid)
    {
        this->rho = 0.0; 
    }

    this->count_mcmc = 0;
    this->count_output_mcmc = 0; 
    this->rho_count = 0; 
    this->A_count = 0; 
    this->nu_count = 0; 
} 

void CBrmlmRM_envlp::mcmc_one_pass()
{
    /* reset values after burn-in period */
    if((this->count_mcmc) == (this->burn_in_mcmc))
    {
        this->A_count = 0; 
        this->rho_count = 0; 
        this->nu_count = 0; 
    }

    this->sample_alpha(); 

    this->sample_eta();
    this->beta_restore(*(this->beta), *(this->eta)); 
    this->compute_residual(); 

    this->sample_Omegas();
    this->Sigma_restore(*(this->Sigma_inv), *(this->Omega_inv), *(this->Omega0_inv)); 

    this->compute_deltaRM(); 
    if(this->ctype != Corr_Type::iid) 
        this->sample_rho(); 
    
    this->sample_Amat();   

    /* 0 = t-distribution, 1 = normal */
    if(this->assume_normal == 0)
    {
        this->sample_tauRM(*(this->Jvec), *(this->deltaRM), this->r_resp); 
        this->sample_nu(); 
    }

    this->pars[0] = this->rho;
    this->pars[1] = this->nu; 
} 

/* count_mcmc, count_output_mcmc, rho_count, A_count, nu_count */

void CBrmlmRM_envlp::get_all_count(int count_length, int *count_pt)
{
    if(count_length < 5)
        error("CBrmlmRM_envlp::get_all_count(): incorrect length.\n"); 

    count_pt[0] = this->count_mcmc;
    count_pt[1] = this->count_output_mcmc; 
    count_pt[2] = this->rho_count; 
    count_pt[3] = this->A_count; 
    count_pt[4] = this->nu_count; 
} 

/**********************************************************************
 * compute log-likelihood corresponding to each draw from posterior distribution
 * logf has count_output_mcmc rows and m_sub columns
 **********************************************************************/

void CBrmlmRM_envlp::compute_loglik_draws(Cmat &logf) 
{
    if(logf.get_ncol() != (this->m_sub))
        error("CBrmlmRM_envlp::compute_loglik_draws(): logf has incompatible number of columns.\n");

    /* compute log-density for each subject at each posterior draw */
    for(int s = 0; s < logf.get_nrow(); s++)
    {
        /* set parameters, avoid the first one */
        this->set_ini_pars(this->length_pars, 
                           this->samples + (this->length_saved_pars) * s); 

        /* compute beta, Sigma_inv, res, and deltaRM*/
        this->compute_Gammas(); 
        this->Sigma_restore(*(this->Sigma_inv), *(this->Omega_inv), *(this->Omega0_inv)); 
        this->beta_restore(*(this->beta), *(this->eta)); 
        this->compute_residual(); 
        this->compute_deltaRM(); 

        double logdetS = - (this->Omega_inv->logdet_chol()) - (this->Omega0_inv->logdet_chol());
        
        for(int i = 0; i < (this->m_sub); i++)
        {
            int Ji = this->Jvec->get_entry_vec(i); 

            Ccormat cor(Ji, this->ctype, this->rho); 
            double logdetR = cor.logdet(); 

            double logden = 0.0; 
            if(this->assume_normal)
            {
                logden = log_dMnorm0(this->r_resp, Ji, 
                            this->deltaRM->get_entry_vec(i), logdetS, logdetR); 
            }
            else 
            {
                logden = log_dMT0(this->r_resp, Ji, this->nu, 
                            this->deltaRM->get_entry_vec(i), logdetS, logdetR); 
            }

            logf.set_entry(s, i, logden); 
        }
    }
}

/**********************************************************************
 * compute WAIC 
 **********************************************************************/

/**********************************************************************
 * this->samples: all samples 
 * this->length_saved_pars: length of each draw 
 * this->count_output_mcmc: number of draws 
 **********************************************************************/

double CBrmlmRM_envlp::compute_WAIC()
{
    Cmat logf(this->count_output_mcmc, this->m_sub);
    this->compute_loglik_draws(logf);
    
    double waic = 0.0;
    Cmat logf_col(this->count_output_mcmc, 1, nullptr); 
    for(int i = 0; i < (this->m_sub); i++)
    {
        logf_col.as_col(logf, i);
        double lppd = logspace_sum(logf_col.get_value_pt(), this->count_output_mcmc); 
        double df = logf_col.var(); 

        waic += lppd - df; 

    }

    waic -= (double)(this->m_sub) * log((double)(this->count_output_mcmc)); 
    return(-2.0 * waic); 
}

/**********************************************************************
 * THE END
 **********************************************************************/
