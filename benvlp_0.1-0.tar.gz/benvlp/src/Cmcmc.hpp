/**********************************************************************
 * Class for MCMC
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 * updated: 2025-10-17 
 * updated: 2025-10-22 
 **********************************************************************/

#include <R.h>

#ifndef __ZP__CMCMC_HPP__ 
#define __ZP__CMCMC_HPP__ 

class Cmcmc {
    protected: 
        int burn_in_mcmc;          /* number of samples to be discarded */
        int size_mcmc;             /* number of samples after burn-in period */
        int thinning_mcmc;         /* save every k-th samples */
        int info_mcmc;             /* display information every k samples */
        int count_mcmc;            /* total number of samples generated */
        int count_output_mcmc;     /* number of samples saved */

        int length_pars;           /* length of parameters, including latent variables */
        double *pars;              /* vector of parameters, length = length_pars */

        int max_saved_draws;       /* maximum number of saved samples */
        int length_saved_pars;     /* length of parameters to be saved */
        double *samples;           /* space to save samples = max_saved_draws * length_saved_pars */ 

        int length_hyperpars;      /*  number of hyperparameters in prior distribution */
        int length_tuning;         /*  number of tuning parameters in proposal distribution */

    public: 
        Cmcmc(); 
        Cmcmc(int burn_in, int size, int thinning, int info, int length);
        ~Cmcmc(); 

        int get_mcmc_count(); 
        int get_mcmc_count_output(); 

        void write2stream(std::ostream &stream);

        /* set space for saving generated samples */
        void set_output_space(int length_draws, int length_each, double *pt); 

        virtual void mcmc_initialize() {};      /* initialization before sampling */
        virtual void mcmc_one_pass() {};        /* sample all parameters once */
        void mcmc_save_samples();               /* save the current sample */
        void mcmc_run();                        /* run MCMC */
        virtual void mcmc_display();            /* display information */
        void mcmc_display_now();                /* display the current time */
}; 

#endif

/**********************************************************************
 * THE END 
 **********************************************************************/
