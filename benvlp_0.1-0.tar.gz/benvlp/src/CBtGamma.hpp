/**********************************************************************
 * Class for Bayesian inference - t-distribution, v ~ Gamma(a, b)
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-27 
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CBTGAMMA__HPP__ 
#define __ZP__CBTGAMMA__HPP__ 

#include <R.h> 
#include <Rmath.h>
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include "Cmat.hpp"
#include "Cimat.hpp"

class CBtGamma {
    protected: 
        Cmat *tau;                   /* latent variable */ 
        double nu;                   /* degrees of freedom */ 

        double hyper_nu_shape;       /* scalar - hyperparameter in Gamma distribution */
        double hyper_nu_rate;        /* scalar - hyperparameter in Gamma distribution */

        double pro_nu_delta;         /* tuning parameter in proposal distribution */
        int nu_count;                /* count the number of accepted nu */

    public: 
        CBtGamma(); 
        CBtGamma(int length_tau); 
        ~CBtGamma(); 

        /* sample from posterior distributions */
        void sample_tau(Cmat &delta, int r); 
        void sample_tauRM(Cimat &Jvec, Cmat &deltaRM, int r); 
        void sample_nu(); 
        double compute_loglik_nu(double inu); 
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
