/**********************************************************************
 * Class for MCMC
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 * updated: 2025-10-17 
 * updated: 2025-10-22  
 **********************************************************************/

#include <R.h>
#include <R_ext/Random.h>

#include <iostream>
#include <iomanip>
#include <ctime>
#include <string.h>

#include "Cmcmc.hpp"

/**********************************************************************
 * variables defined in Cmcmc: (9)
 *     int burn_in_mcmc;            number of samples to be discarded 
 *     int size_mcmc;               number of samples after burn-in period 
 *     int thinning_mcmc;           save every k-th samples 
 *     int info_mcmc;               display information every k samples 
 *     int count_mcmc;              total number of samples generated 
 *     int count_output_mcmc;       number of samples saved 
 *     int length_pars;             length of parameters, including latent variables 
 *     double *pars;                vector of parameters, length = length_pars 
 *     int max_saved_draws;         maximum number of saved samples 
 *     int length_saved_pars;       length of parameters to be saved 
 *     double *samples;             space to save samples = max_saved_draws * length_saved_pars 
 *     int length_hyperpars;        number of hyperparameters in prior distribution 
 *     int length_tuning;           number of tuning parameters in proposal distribution
 **********************************************************************/

Cmcmc::Cmcmc()
{
    this->burn_in_mcmc = 0; 
    this->size_mcmc = 0; 
    this->thinning_mcmc = 0; 
    this->info_mcmc = 0; 
    this->count_mcmc = 0; 
    this->count_output_mcmc = 0;

    this->length_pars = 0;       
    this->pars = nullptr;        
    this->max_saved_draws = 0;   
    this->length_saved_pars = 0; 
    this->samples = nullptr; 
    this->length_hyperpars = 0;
    this->length_tuning = 0; 
}

Cmcmc::Cmcmc(int burn_in, int size, int thinning, int info, int length)
{
    this->burn_in_mcmc = burn_in; 
    this->size_mcmc = size; 
    this->thinning_mcmc = thinning; 
    this->info_mcmc = info; 
    this->count_mcmc = 0; 
    this->count_output_mcmc = 0;

    this->length_pars = length; 
    this->pars = new double[length]();  
    this->max_saved_draws = 0;   
    this->length_saved_pars = length; 
    this->samples = nullptr; 
    this->length_hyperpars = 0;
    this->length_tuning = 0; 
}

/**********************************************************************
 * destructor 
 **********************************************************************/

Cmcmc::~Cmcmc()
{
    if(this->pars != nullptr) delete this->pars; 
}

/**********************************************************************
 * get or set values 
 **********************************************************************/

int Cmcmc::get_mcmc_count()
{
    return(this->count_mcmc); 
}

int Cmcmc::get_mcmc_count_output()
{
    return(this->count_output_mcmc); 
}

/**********************************************************************
 * write information to a stream
 **********************************************************************/
  
void Cmcmc::write2stream(std::ostream &stream)
{
    stream << "\nburn in = " << this->burn_in_mcmc << std::endl;
    stream << "\nsize = " << this->size_mcmc << std::endl;
    stream << "\nthinning = " << this->thinning_mcmc << std::endl;
    stream << "\ninfo = " << this->info_mcmc << std::endl;
}

/**********************************************************************
 * set space for saving generated samples 
 **********************************************************************/

void Cmcmc::set_output_space(int length_draws, int length_each, double *pt)
{
    this->max_saved_draws = length_draws; 
    this->length_saved_pars = length_each; 
    this->samples = pt; 
} 

/**********************************************************************
 * methods 
 **********************************************************************/

void Cmcmc::mcmc_run()
{
    if((this->info_mcmc) > 0)
    {
        std::cout << "\n==================================================\n"; 
        std::cout << "burn-in = " << this->burn_in_mcmc 
                  << ", size = " << this->size_mcmc 
                  << ", thinning = " << this->thinning_mcmc << std::endl;
        std::cout << "Start at "; 
        this->mcmc_display_now(); 
        std::cout << "\n==========> Start Sampling <==========\n" << std::endl;
    }

    GetRNGstate();  

    this->count_mcmc = 0; 
    this->count_output_mcmc = 0; 

    this->mcmc_initialize(); 

    for(int icount = 1-(this->burn_in_mcmc); icount <= (this->size_mcmc); icount++)
    {
        if(((this->info_mcmc) > 0) && (icount % (this->info_mcmc) == 0))
        {
            std::cout << "Sample = " << icount << " : "; 
            this->mcmc_display(); 
            std::cout << std::endl; 
        }

        this->mcmc_one_pass(); 
        
        if((icount % (this->thinning_mcmc) == 0) && (icount > 0))
        {
            this->mcmc_save_samples(); 
            (this->count_output_mcmc) ++; 
        }

        (this->count_mcmc) ++; 
    }

    PutRNGstate();  

    if((this->info_mcmc) > 0)
    {
        std::cout << "\n==========> End Sampling <==========" << std::endl;
        std::cout << "Number of samples saved = " << this->count_output_mcmc << std::endl;
        std::cout << "Stop at "; 
        this->mcmc_display_now(); 
        std::cout << "\n==================================================\n\n"; 
    }
} 

void Cmcmc::mcmc_display()
{
    this->mcmc_display_now(); 
}

void Cmcmc::mcmc_display_now()
{
    std::time_t currentTime = std::time(nullptr);
    std::tm *localTime = std::localtime(&currentTime); 
    std::cout << std::put_time(localTime, "%Y-%m-%d %H:%M:%S");
}

/**********************************************************************
 * save sample to sample_seq 
 **********************************************************************/

void Cmcmc::mcmc_save_samples()
{
    memcpy(this->samples + (this->count_output_mcmc) * this->length_saved_pars,  
           this->pars, this->length_saved_pars * sizeof(double));
}

/**********************************************************************
 * THE END 
 **********************************************************************/
