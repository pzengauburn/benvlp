######################################################################
# correlation matrices 
# 2024-11-22
######################################################################

######################################################################
# generate a correlation matrix 
######################################################################

cor_mat = function(p, rho, cor_type = c("iid", "cs", "ar1"))
{
    cor_type = match.arg(cor_type); 
    switch(cor_type, 
        "iid" = diag(rep(1, p)),
        "cs" = cor_cs(p, rho),
        "ar1" = cor_ar1(p, rho));
}

######################################################################
# return the inverse of a correlation matrix 
######################################################################

cor_inv = function(p, rho, cor_type = c("iid", "cs", "ar1"))
{
    cor_type = match.arg(cor_type); 
    switch(cor_type, 
        "iid" = diag(rep(1, p)),
        "cs" = cor_cs_inv(p, rho),
        "ar1" = cor_ar1_inv(p, rho));
}

######################################################################
# return the log-determinant of a correlation matrix 
######################################################################

cor_logdet = function(p, rho, cor_type = c("iid", "cs", "ar1"))
{
    cor_type = match.arg(cor_type); 
    switch(cor_type, 
        "iid" = 0,
        "cs" = cor_cs_logdet(p, rho),
        "ar1" = cor_ar1_logdet(p, rho));
}

######################################################################
# AR(1) 
######################################################################

cor_ar1 = function(p, rho) 
{
    stopifnot(p > 1, abs(rho) < 1);    
    matrix(rho^(abs(rep(1:p, p) - rep(1:p, rep(p, p)))), nrow = p, ncol = p);
}

cor_ar1_inv = function(p, rho)
{
    stopifnot(p > 1, abs(rho) < 1);
    Rmat = matrix(0, nrow = p, ncol = p);
    b = rho / (rho * rho - 1); 
    Rmat[seq(2, p*p, by = p+1)] = b; 
    Rmat[seq(p+1, p*p, by = p+1)] = b; 
    diag(Rmat) = 1 - 2 * rho * b; 
    a = 1 - rho * b; 
    Rmat[1, 1] = a; Rmat[p, p] = a; 
    Rmat; 
}

cor_ar1_logdet = function(p, rho)
{
    (p - 1) * log(1 - rho * rho); 
}

######################################################################
# compound symmetry 
######################################################################

cor_cs = function(p, rho)
{
    stopifnot(p > 1, abs(rho) < 1);
    Rmat = matrix(rho, nrow = p, ncol = p); 
    diag(Rmat) = 1.0; 
    Rmat; 
}

cor_cs_inv = function(p, rho)
{
    stopifnot(p > 1, abs(rho) < 1);
    b = -rho / (1-rho) / (1 + (p-1)*rho);
    Rmat = matrix(b, nrow = p, ncol = p);
    diag(Rmat) = b + 1 / (1 - rho); 
    Rmat; 
}

cor_cs_logdet = function(p, rho)
{
    (p - 1) * log(1 - rho) + log(1 - rho + p * rho);
}

######################################################################
# THE END 
######################################################################
