######################################################################
# Bayesian inference for multivariate linear regression 
# with repeated measures and envelope structure, t-distribution 
# 2025-10-25
######################################################################

######################################################################
# parameters to be estimated 
#     alpha  - r-by-1 vector 
#     beta   - r-by-p matrix 
#     Sigma  - r-by-r positive definite matrix 
#     eta    - u-by-p matrix 
#     Amat   - (r-u)-by-u matrix 
#     Omega  - u-by-u positive definite matrix 
#     Omega0 - (r-u)-by-(r-u) positive definite matrix 
#     Gamma  - r-by-u orthogonal matrix 
#     Gamma0 - r-by-(r-u) orthogonal matrix 
#     rho    - scalar 
#     tau    - n_subject vector 
#     nu     - scalar 
# 
# prior distributions 
#     alpha  - noninformative 
#     eta    - matrix-variate normal distribution (Gamma' xi, Omega, H-inv) 
#     Pmax   ~ etr(MP) 
#     Omega  - inverse-Wishart(k, Psi) 
#     Omega0 - inverse-Wishart(k0, Psi0) 
#     rho    - noninformative 
#     nu     - Gamma(a, b)
# 
# posterior distribution 
#     alpha  - normal 
#     eta    - matrix-variate normal distribution 
#     Omega  - inv-Wishart 
#     Omage0 - inv-Wishart 
#     Amat   - nonstandard
#     rho    - nonstandard 
#     nu     - nonstandard 
#     tau    - Gamma 
######################################################################

######################################################################
# interface to C functions 
######################################################################

rolem = function(
    y,                     # n-by-r matrix  
    x,                     # n-by-p matrix 
    subject,               # n-by-1 vector 
    u,                     # dimension of envelope 
    Umat = NULL,           # r-by-r matrix 
    cor_type = c("iid", "cs", "ar1"),  # type of correlation structure
    normal = FALSE,        # assume normal distribution instead of t-distribution 
    burn_in = 500,         # number of samples thrown away 
    size = 2000,           # number of samples generated after burn-in 
    thinning = 5,          # keep one out of every k samples  
    info = 500,            # display information for every k samples 
    ini = list(),          # initial values 
    hyper_pars = list(),   # parameters in prior distributions 
    pro_pars = list())     # parameters in proposal distributions 
{
    ##################################################################
    # compute some quantities    
    ##################################################################

    stopifnot(nrow(y) == nrow(x), length(subject) == nrow(y)); 

    index_order = order(subject); 
    subject = subject[index_order]; 
    x = x[index_order, ];
    y = y[index_order, ];

    sumJ = nrow(y);                   # number of observations 
    r = ncol(y);                      # number of responses 
    p = ncol(x);                      # number of predictors  
    subject_ID = unique(subject);     # distinct ID 
    n_subject = length(subject_ID);   # number of subject 

    ##################################################################
    # set default values for hyper_pars if necessary  
    ##################################################################

    hyper_pars_names = c("eta_mean", "eta_cov_inv", 
                         "Omega_df", "Omega_scale", 
                         "Omega0_df", "Omega0_scale", 
                         "P_Mmat",
                         "nu_shape", "nu_rate");
    if(! all(hyper_pars_names %in% names(hyper_pars)))
        hyper_pars = set_hyper_pars_envlp(hyper_pars, r, p, u)[hyper_pars_names]; 

    ##################################################################
    # set default values for pro_pars if necessary  
    ##################################################################

    pro_pars_names = c("Pmat_sigma2", "rho_delta", "nu_delta"); 
    if(! all(pro_pars_names %in% names(pro_pars)))
        pro_pars = set_pro_pars_envlp(pro_pars)[pro_pars_names]; 

    ##################################################################
    # set default values for ini, and set the initial sample 
    ##################################################################

    ini_names = c("alpha", "eta", "Amat", "Omega", "Omega0", "rho", "tau", "nu");
    if(! all(ini_names %in% names(ini)))
        ini = set_ini(y, x, subject, u, Umat)[ini_names]; 

    ##################################################################
    # sample from posterior distributions  
    ##################################################################

    if(is.null(Umat)) Umat = diag(rep(1, r), nrow = r); 

    ini_vec = c(ini$rho, ini$nu, ini$tau, ini$alpha, ini$eta, ini$Amat, solve(ini$Omega), solve(ini$Omega0));
    hyper_pars_vec = c(hyper_pars$eta_mean, hyper_pars$eta_cov_inv, 
                       hyper_pars$Omega_df, hyper_pars$Omega_scale, 
                       hyper_pars$Omega0_df, hyper_pars$Omega0_scale, 
                       hyper_pars$P_Mmat, 
                       hyper_pars$nu_shape, hyper_pars$nu_rate); 
    pro_pars_vec = c(pro_pars$rho_delta, pro_pars$Pmat_sigma2, pro_pars$nu_delta);

    Jvec = numeric(n_subject); 
    for (i in 1:n_subject) Jvec[i] = sum(subject == subject_ID[i]); 

    cor_type = match.arg(cor_type); 
    ctype = switch(cor_type, "iid" = 0, "cs" = 1, "ar1" = 2); 

    N = floor(size / thinning);

    ans = .C(.benvlp_BrmlmRM_envlp_API, 
                as.integer(c(sumJ, r, p, n_subject, u)), 
                as.double(c(t(y), t(x), Umat)),
                as.integer(c(ctype, Jvec)), 
                as.integer(c(burn_in, size, thinning, info, normal)),
                as.integer(length(ini_vec)), 
                as.double(ini_vec),
                as.integer(length(hyper_pars_vec)), 
                as.double(hyper_pars_vec), 
                as.integer(length(pro_pars_vec)), 
                as.double(pro_pars_vec), 
                as.integer(N), 
                samples = double(N * length(ini_vec)), 
                as.integer(1 + length(ini_vec)), 
                pmean = double(length(ini_vec)), 
                count = integer(5));                                         
        
    ##################################################################
    # samples:   
    #     rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv
    # pmean: 
    #     rho, nu, tau, alpha, eta, Amat, Omega, Omega0
    #     1 + 1 + n_subject + r + u*p + (r-u)*u + u*u + (r-u)*(r-u)
    ##################################################################

    samples = get_all_samples(
                matrix(ans$samples, ncol = N),
                list(rho = 1,
                     nu = 1, 
                     tau = n_subject, 
                     alpha = r, 
                     eta = c(u, p), 
                     Amat = c(r-u, u), 
                     Omega_inv = c(u, u), 
                     Omega0_inv = c(r-u, r-u)));

    posterior_mean = get_all_pmeans(ans$pmean, 
                list(rho = 1,
                     nu = 1, 
                     tau = n_subject, 
                     alpha = r, 
                     eta = c(u, p), 
                     Amat = c(r-u, u), 
                     Omega = c(u, u), 
                     Omega0 = c(r-u, r-u)));

    iSample = get_k_sample(samples, N, Umat); 

    npars = (normal == FALSE) + 1 + r + u * p + r * (r + 1)/2;

    out = list(y = y, x = x, subject = subject, u = u, 
        normal = normal, cor_type = cor_type, Umat = Umat,  
        ini = ini,                    # initial value
        hyper_pars = hyper_pars,      # parameters in prior distributions
        pro_pars = pro_pars,          # parameters in proposal distributions
        posterior_mean = posterior_mean, 
        npars = npars,                # number of parameters 
        count = ans$count[2],         # number of saved samples 
        rho_accept = ans$count[3] / size, 
        Amat_accept = ans$count[4] / size, 
        nu_accept = ans$count[5] / size, 
        iSample = iSample,            # the last sample generated 
        samples = samples);           # saved samples 
    
    class(out) = "rolem"; 
    out; 
}


pred_loglik_mat.rolem = function(
    fit,  
    y = NULL,                     # n-by-r matrix  
    x = NULL,                     # n-by-p matrix 
    subject = NULL)               # n-by-1 vector 
{
    ##################################################################
    # compute some quantities    
    ##################################################################

    if(is.null(y)) y = fit$y; 
    if(is.null(x)) x = fit$x;
    if(is.null(subject)) subject = fit$subject; 
    u = fit$u; 

    stopifnot(nrow(y) == nrow(x), length(subject) == nrow(y)); 

    index_order = order(subject); 
    subject = subject[index_order]; 
    x = x[index_order, ];
    y = y[index_order, ];

    sumJ = nrow(y);                   # number of observations 
    r = ncol(y);                      # number of responses 
    p = ncol(x);                      # number of predictors  
    subject_ID = unique(subject);     # distinct ID 
    n_subject = length(subject_ID);   # number of subject 

    ##################################################################
    # sample from posterior distributions  
    ##################################################################

    Jvec = numeric(n_subject); 
    for (i in 1:n_subject) Jvec[i] = sum(subject == subject_ID[i]); 

    ctype = switch(fit$cor_type, "iid" = 0, "cs" = 1, "ar1" = 2); 

    N = fit$count;  
    length_pars = 1 + 1 + n_subject + r + u*p + (r-u)*u + u*u + (r-u)*(r-u); 
    # rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv 

    allsamples = rbind(        
        fit$samples$rho,
        fit$samples$nu,
        matrix(1.0, nrow = n_subject, ncol = N),          # tau 
        fit$samples$alpha,
        matrix(fit$samples$eta, nrow = u*p, ncol = N),
        matrix(fit$samples$Amat, nrow = (r-u)*u, ncol = N),
        matrix(fit$samples$Omega_inv, nrow = u*u, ncol = N),
        matrix(fit$samples$Omega0_inv, nrow = (r-u)*(r-u), ncol = N)); 

    ans = .C(.benvlp_BrmlmRM_envlp_loglik, 
                as.integer(c(sumJ, r, p, n_subject, u)), 
                as.double(c(t(y), t(x), fit$Umat)),
                as.integer(c(ctype, Jvec)), 
                as.integer(c(fit$normal)),
                as.integer(N), 
                as.double(allsamples), 
                logf = double(N * n_subject));                                         
        
    matrix(ans$logf, nrow = N, ncol = n_subject);     
}


pred_loglik_mat = function(fit, ...)
{
    UseMethod("pred_loglik_mat"); 
}

######################################################################
# THE END 
######################################################################
