######################################################################
# generate synthetic data 
# 2025-03-23 
######################################################################

######################################################################
# generate synthetic data:
#     multivariate linear regression with possible repeated measures 
######################################################################

synthetic_mlm = function(n, alpha, beta, Sigma, 
    subject = NULL, rho = 0.0, cor_type = c("iid", "cs", "ar1"),
    x_sd = 1.0, normal = TRUE, nu = 10)
{
    r = NROW(beta); p = NCOL(beta); 
    stopifnot(nrow(Sigma) == r, ncol(Sigma) == r); 

    if(is.null(alpha)) alpha = numeric(r); 
    stopifnot(length(alpha) == r); 

    if(! is.null(subject))
    {
        n_subject = length(unique(subject)); 
        stopifnot(length(subject) == n); 
        stopifnot(all(subject %in% 1:n_subject)); 
    }
    else 
    {
        rho = 0.0; 
        cor_type = "iid"; 
    }

    stopifnot(rho >= 0.0, rho <= 1.0);
    cor_type = match.arg(cor_type); 

    x = matrix(rnorm(n * p, sd = x_sd), nrow = n, ncol = p); 
    e = matrix(rnorm(n * r), nrow = n, ncol = r) %*% chol(Sigma); 

    if(! is.null(subject))
    for(i in 1:n_subject)
    {
        index = which(subject == i); 
        Rmat = cor_mat(length(index), rho, cor_type); 
        tau = ifelse(normal, 1, rgamma(1, shape = nu/2, rate = nu/2)); 
        e[index, ] = t(chol(Rmat)) %*% e[index, ] / sqrt(tau); 
    }

    y = sweep(x %*% t(beta) + e, 2, alpha, "+"); 

    list(alpha = alpha, beta = beta, Sigma = Sigma, 
        rho = rho, cor_type = cor_type, x_sd = x_sd, 
        x = x, y = y, subject = subject, normal = normal, nu = nu);
}

######################################################################
# THE END 
######################################################################

synthetic_mlm_envlp = function(n, alpha, eta, Amat, Omega, Omega0,  
    subject = NULL, rho = 0.0, cor_type = c("iid", "cs", "ar1"),
    Umat = NULL, x_sd = 1.0, normal = TRUE, nu = 10)
{
    Sigma = A2Sigma(Amat, Omega, Omega0, Umat); 
    beta = A2Gamma(Amat, Umat) %*% eta;

    c(list(eta = eta, Amat = Amat, Omega = Omega, Omega0 = Omega0, Umat = Umat),
        synthetic_mlm(
                n = n, alpha = alpha, beta = beta, Sigma = Sigma, 
                subject = subject, rho = rho, cor_type = cor_type,
                x_sd = x_sd, normal = normal, nu = nu)); 
}

######################################################################
# generate synthetic data:
######################################################################

synthetic_data = function(n_subject = 50, r = 5, J = 5, p = 6, u = 2, 
    rho = 0.5, cor_type = c("iid", "cs", "ar1"),
    distr = c("normal", "t", "mixnormal"))
{
    stopifnot(rho >= 0.0, rho <= 1.0);
    cor_type = match.arg(cor_type); 

    distr = match.arg(distr); 

    alpha = runif(r, -5, 5);
    eta = matrix(runif(u * p, -5, 5), nrow = u, ncol = p);
    Amat = matrix(runif((r-u) * u, -1, 1), nrow = r-u, ncol = u);
    Omega  = diag(runif(u, 0, 1), nrow = u);
    Omega0 = diag(runif(r-u, 5, 10), nrow = r-u);
    Umat = NULL; 

    Sigma = A2Sigma(Amat, Omega, Omega0, Umat); 
    beta = A2Gamma(Amat, Umat) %*% eta;

    subject = sort(rep(1:n_subject, J));

    n = n_subject * J; 
    x = matrix(rnorm(n * p, sd = 1.0), nrow = n, ncol = p); 
    e = matrix(rnorm(n * r), nrow = n, ncol = r); 

    nu = NULL; 

    for(i in 1:n_subject)
    {
        index = which(subject == i); 
        Rmat = cor_mat(length(index), rho, cor_type); 

        if(distr == "normal")
        {
            # normal distribution, mean = 0, var = 2
            e[index, ] = e[index, ] * sqrt(2); 
        } 
        else if(distr == "t")
        {
            # t-distribution, df = 4 and var = 2 
            nu = 4; 
            tau = rgamma(1, shape = nu/2, rate = nu/2); 
            e[index, ] = e[index, ] / sqrt(tau); 
        }
        else if(distr == "mixnormal")
        {
            # mixture-normal 0.9 N(0, 1) + 0.1 N(0, 11), var = 2
            e[index, ] = e[index, ] * sample(c(1, sqrt(11)), r * J, replace = TRUE, prob = c(0.9, 0.1));
        }
        else stop("unsupported distribution.\n"); 

        e[index, ] = t(chol(Rmat)) %*% e[index, ] %*% chol(Sigma); 
    }

    y = sweep(x %*% t(beta) + e, 2, alpha, "+"); 

    list(alpha = alpha, beta = beta, Sigma = Sigma, 
        eta = eta, Amat = Amat, Omega = Omega, Omega0 = Omega0, Umat = Umat, 
        rho = rho, cor_type = cor_type, nu = nu, 
        x = x, y = y, subject = subject, distr = distr);
}

######################################################################
# compute performance measures 
######################################################################

get_performance = function(fit, dataDF)
{
    ans = posterior_mean(fit); 

    alpha = sqrt(sum((ans$alpha - dataDF$alpha)^2));
    beta = sqrt(sum((ans$beta - dataDF$beta)^2));
    Sigma = sqrt(sum((ans$Sigma - dataDF$Sigma)^2));
    nu = ifelse(is.null(ans$nu), NA, abs(ans$nu - dataDF$nu));
    rho = ifelse(is.null(ans$rho), NA, abs(ans$rho - dataDF$rho));
    
    A_accept   = ifelse(is.null(fit$Amat_accept),   NA, fit$Amat_accept);
    rho_accept = ifelse(is.null(fit$rho_accept), NA, fit$rho_accept);
    nu_accept  = ifelse(is.null(fit$nu_accept),  NA, fit$nu_accept);

    out = data.frame(var = c("alpha", "beta", "Sigma", "nu", "rho", 
                           "A_accept", "rho_accept", "nu_accept"),
                    value = c(alpha, beta, Sigma, nu, rho, 
                            A_accept, rho_accept, nu_accept));

    out; 
}

get_more_performance = function(fit, dataDF, alpha = 0.05)
{
    ans = summary(fit, alpha);
    out = NULL; 

    for(var in c("alpha", "beta", "eta", "Amat", "rho", "nu"))
    if(var %in% names(ans))
    {
        HPD_upp = ans[[var]]$HPD_upp; 
        HPD_low = ans[[var]]$HPD_low; 
        HPD_length = HPD_upp - HPD_low; 
        HPD_prob =  ((HPD_upp >= dataDF[[var]]) & (HPD_low <= dataDF[[var]]));

        ess = ans[[var]]$ess;

        out = rbind(out, 
            data.frame(var = var, 
                       HPD_length = as.vector(HPD_length),
                       HPD_prob = as.vector(HPD_prob),
                       ess = as.vector(ess), 
                       index = 1:length(HPD_length))); 
    }

    out; 
}

######################################################################
# THE END 
######################################################################
