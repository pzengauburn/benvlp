######################################################################
# compute posterior means 
######################################################################

posterior_mean = function(fit, ...)
{
    UseMethod("posterior_mean"); 
}

posterior_mean.bmlm = function(fit, ...)
{
    N = ncol(fit$samples$alpha); 
    r = nrow(fit$samples$alpha);
    p = dim(fit$samples$beta)[2]; 

    out = list(); 
    out$alpha = rowMeans(fit$samples$alpha);
    out$beta = apply(fit$samples$beta, c(1, 2), mean); 

    Sigma_seq = array(0, dim = c(r, r, N));
    for(i in 1:N) Sigma_seq[, , i] = solve(fit$samples$Sigma_inv[, , i]);
    out$Sigma = apply(Sigma_seq, c(1, 2), mean); 

    out; 
}

posterior_mean.benvlp = function(fit, ...)
{
    N = ncol(fit$samples$alpha); 
    r = nrow(fit$samples$alpha);
    u = dim(fit$samples$Omega_inv)[1]; 
    p = dim(fit$samples$eta)[2]; 

    out = list(); 
    out$alpha = rowMeans(fit$samples$alpha);
    out$eta = apply(fit$samples$eta, c(1, 2), mean); 
    out$Amat = apply(fit$samples$Amat, c(1, 2), mean); 

    beta_seq = array(0, dim = c(r, p, N));
    Sigma_seq = array(0, dim = c(r, r, N));
    Omega_seq = array(0, dim = c(u, u, N));
    Omega0_seq = array(0, dim = c(r - u, r - u, N));
    for (i in 1:N) {
        iGamma = A2Gamma(fit$samples$Amat[, , i], fit$Umat);
        iGamma0 = A2Gamma0(fit$samples$Amat[, , i], fit$Umat);
        beta_seq[, , i] = iGamma %*% fit$samples$eta[, , i];
        Omega_seq[, , i] = solve(fit$samples$Omega_inv[, , i]);
        Omega0_seq[, , i] = solve(fit$samples$Omega0_inv[, , i]);
        Sigma_seq[, , i] = Gamma2Sigma(iGamma, iGamma0, Omega_seq[, , i], Omega0_seq[, , i]);
    }

    out$Omega = apply(Omega_seq, c(1, 2), mean); 
    out$Omega0 = apply(Omega0_seq, c(1, 2), mean); 
    out$beta = apply(beta_seq, c(1, 2), mean); 
    out$Sigma = apply(Sigma_seq, c(1, 2), mean); 

    out; 
}

posterior_mean.brenvlp = function(fit, ...)
{
    out = posterior_mean.benvlp(fit, ...);
    out$nu = mean(fit$samples$nu);
    out$tau = rowMeans(fit$samples$tau)
    out; 
}

posterior_mean.lmm = function(fit, ...)
{
    out = posterior_mean.bmlm(fit, ...); 
    
    out$rho = mean(fit$samples$rho);

    out; 
}

posterior_mean.rlmm = function(fit, ...)
{
    out = posterior_mean.lmm(fit, ...);

    out$nu = mean(fit$samples$nu);
    out$tau = rowMeans(fit$samples$tau); 

    out; 
}

posterior_mean.lem = function(fit, ...)
{
    out = posterior_mean.benvlp(fit, ...); 

    out$rho = mean(fit$samples$rho); 

    out; 
}

posterior_mean.rolem = function(fit, ...)
{
    out = posterior_mean.brenvlp(fit, ...); 

    out$rho = mean(fit$samples$rho); 

    out; 
}

######################################################################
# THE END 
######################################################################
