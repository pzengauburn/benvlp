######################################################################
# functions for envelope models 
# 2024-11-22  
######################################################################

######################################################################
# compute Gamma from A 
######################################################################

A2Gamma_v1 = function(Amat, Umat = NULL)
{
    u = NCOL(Amat); 
    Ainfo = eigen(t(Amat) %*% Amat);   # eigen of u-by-u matrix 
    Bmat = (Ainfo$vectors %*% 
            diag(1/sqrt(Ainfo$values + 1), nrow = u, ncol = u) %*% 
            t(Ainfo$vectors));
    Gamma = rbind(diag(rep(1, u), nrow = u, ncol = u), Amat) %*% Bmat;
    if(!is.null(Umat)) Gamma = Umat %*% Gamma; 
    Gamma; 
}

A2Gamma = function(Amat, Umat = NULL)
{
    u = NCOL(Amat); 

    Asvd = svd(Amat, nv = u); 
    dvec = rep(1.0, u);
    dvec[1:length(Asvd$d)] = 1.0 / sqrt(Asvd$d^2 + 1.0);  
    Bmat = Asvd$v %*% diag(dvec, nrow = u) %*% t(Asvd$v); 

    Gamma = rbind(Bmat, Amat %*% Bmat);
    if(!is.null(Umat)) Gamma = Umat %*% Gamma; 
    Gamma; 
}

######################################################################
# compute Gamma0 from A 
######################################################################

A2Gamma0_v1 = function(Amat, Umat = NULL)
{
    ru = NROW(Amat); 
    Ainfo = eigen(Amat %*% t(Amat));  # eigen of ru-by-ru matrix 
    Bmat = (Ainfo$vectors %*% 
            diag(1/sqrt(Ainfo$values + 1), nrow = ru, ncol = ru) %*% 
            t(Ainfo$vectors));
    Gamma0 = rbind(-t(Amat), diag(rep(1, ru), nrow = ru, ncol = ru)) %*% Bmat;
    if(!is.null(Umat)) Gamma0 = Umat %*% Gamma0; 
    Gamma0; 
}


A2Gamma0 = function(Amat, Umat = NULL)
{
    ru = NROW(Amat); 

    Asvd = svd(Amat, nu = ru); 
    dvec = rep(1.0, ru);
    dvec[1:length(Asvd$d)] = 1.0 / sqrt(Asvd$d^2 + 1.0);  
    Bmat = Asvd$u %*% diag(dvec, nrow = ru) %*% t(Asvd$u); 

    Gamma0 = rbind(-t(Amat) %*% Bmat, Bmat);
    if(!is.null(Umat)) Gamma0 = Umat %*% Gamma0; 
    Gamma0; 
}

######################################################################
# compute Gamma and Gamma0 from A 
######################################################################

A2Gammas = function(Amat, Umat = NULL)
{
    ru = NROW(Amat); u = NCOL(Amat); 
    Asvd = svd(Amat);   

    dvec = rep(1.0, max(ru, u));
    dvec[1:length(Asvd$d)] = 1.0 / sqrt(Asvd$d^2 + 1);  

    if(ru < u)
    {
        Asvd$v = qr.Q(qr(Asvd$v), complete = TRUE);
    }
    else 
    {
        Asvd$u = qr.Q(qr(Asvd$u), complete = TRUE);
    }

    # for Gamma, BmatV is u-by-u matrix  
    BmatV = (Asvd$v %*% diag(dvec, nrow = u, ncol = u) %*% t(Asvd$v));
    Gamma = rbind(diag(rep(1, u), nrow = u, ncol = u), Amat) %*% BmatV;

    # for Gamma0, BmatU is ru-by-ru matrix 
    BmatU = (Asvd$u %*% diag(dvec, nrow = ru, ncol = ru) %*% t(Asvd$u));
    Gamma0 = rbind(-t(Amat), diag(rep(1, ru), nrow = ru, ncol = ru)) %*% BmatU;

    if(!is.null(Umat)) 
    {
        Gamma = Umat %*% Gamma; 
        Gamma0 = Umat %*% Gamma0; 
    }
    list(Gamma = Gamma, Gamma0 = Gamma0); 
}

######################################################################
# compute Sigma from A 
######################################################################

A2Sigma = function(Amat, Omega, Omega0, Umat = NULL)
{
    Gamma = A2Gamma(Amat, Umat); 
    Gamma0 = A2Gamma0(Amat, Umat); 
    Gamma2Sigma(Gamma, Gamma0, Omega, Omega0);
}

######################################################################
# compute Sigma from (Gamma, Gamma0, Omega, Omega0)
######################################################################

Gamma2Sigma = function(Gamma, Gamma0, Omega, Omega0)
{
    Gamma %*% Omega %*% t(Gamma) + Gamma0 %*% Omega0 %*% t(Gamma0); 
}

######################################################################
# compute A from P_Z with Umat, where P_Z is the projection matrix of Z 
######################################################################

Z2Amat = function(Zmat, Umat = NULL)
{
    u = ncol(Zmat); 
    Q = qr.Q(qr(Zmat)); 
    if(is.null(Umat))
    {
        Amat = Q[-(1:u), ] %*% solve(Q[1:u, ]);
    }
    else 
    {
        Amat = (t(Umat[, -(1:u)]) %*% Q) %*% solve(t(Umat[, 1:u]) %*% Q); 
    }

    Amat;  # (r-u)-by-u matrix 
}

######################################################################
# propose an Amat based on current value  
######################################################################

propose.Amat = function(Gamma, sigma2 = 1e-5, Umat = NULL)
{
    r = NROW(Gamma); u = NCOL(Gamma); 

    # M = sigma2 * I_r + Gamma * Gamma'
    Mmat = Gamma %*% t(Gamma); 
    diag(Mmat) = diag(Mmat) + sigma2; 

    # simulate Z from matrix-variate normal(0, Mmat, I_u)
    Zmat = t(chol(Mmat)) %*% matrix(rnorm(r * u), nrow = r, ncol = u); 

    Z2Amat(Zmat, Umat); 
}

######################################################################
# THE END 
######################################################################
