######################################################################
# compute a raw estimate for initial values 
######################################################################

set_ini = function(y, x, subject = NULL, u = NULL, Umat = NULL)
{
    lmfit = lm.fit(cbind(1, x), y); 
    ab = t( coef(lmfit) );
    res = residuals(lmfit);  

    ini = list(alpha = ab[, 1], beta = ab[, -1], Sigma = cov(res));

    ini$tau = rep(1.0, nrow(x)); 
    ini$nu = 10; 

    ##################################################################
    # add initial values for eta, A, Omega, Omega0 if applicable 
    ##################################################################
    
    if(! is.null(u))
    {
        ini$Amat = Z2Amat(svd(ini$beta)$u[, 1:u, drop = FALSE], Umat); 
        ini$Gamma  = A2Gamma(ini$Amat, Umat); 
        ini$Gamma0 = A2Gamma0(ini$Amat, Umat); 

        ini$eta = t(ini$Gamma) %*% ini$beta; 
        ini$beta = ini$Gamma %*% ini$eta; 

        ini$Omega = t(ini$Gamma) %*% ini$Sigma %*% ini$Gamma; 
        ini$Omega0 = t(ini$Gamma0) %*% ini$Sigma %*% ini$Gamma0; 
        ini$Sigma = Gamma2Sigma(ini$Gamma, ini$Gamma0, ini$Omega, ini$Omega0); 
    }

    ##################################################################
    # add initial values for rho if applicable 
    ##################################################################

    if(! is.null(subject))
    {
        res = sweep(res, 2, 1.0 / sqrt(diag(ini$Sigma)), "*"); 
        ID_list = sort(unique(subject));

        r1 = NULL; 
        r2 = NULL; 
        for(i in 1:length(ID_list))
        {
            index = which(subject == ID_list[i]); 
            if(length(index) > 1)
            {
                r1 = c(r1, res[index[-1], ]); 
                r2 = c(r2, res[index[-length(index)], ]);
            }
        }

        ini$rho = cor(r1, r2); 
        ini$tau = rep(1.0, length(ID_list));
    }

    ini; 
}

######################################################################
# THE END 
######################################################################
