######################################################################
# summarize results 
######################################################################

summary.bmlm = function(fit, alpha = 0.05)
{
    out = list(); 

    out$alpha = summary_draws_array(fit$samples$alpha);
    out$beta = summary_draws_array(fit$samples$beta);
    out$Sigma = summary_draws_array(fit$samples$Sigma);

    out; 
}

summary.lmm = function(fit, alpha = 0.05)
{
    out = summary.bmlm(fit, alpha); 
    out$rho = summary_draws(fit$samples$rho); 
    out; 
}

summary.rlmm = function(fit, alpha = 0.05)
{
    out = summary.lmm(fit, alpha);
    out$nu = summary_draws(fit$samples$nu); 

    # row - samples; col - observations 
    mat = pred_loglik_mat(fit);
    n_subject = length(unique(fit$subject));   # number of subject 
    deviance = -2.0 * max(rowSums(mat)); 

    out$BIC = deviance + log(n_subject) * fit$npars; 

    tmp = apply(mat, 2, function(a) {matrixStats::logSumExp(a) - var(a)} );
    out$WAIC = -2.0 * (sum(tmp) - ncol(mat) * log(nrow(mat)));

    out; 
}

summary.benvlp = function(fit, alpha = 0.05)
{
    fit$samples = add_beta_Sigma(fit$samples, fit$Umat); 
    out = summary.bmlm(fit, alpha); 

    out$eta = summary_draws_array(fit$samples$eta);
    out$Amat = summary_draws_array(fit$samples$Amat);

    out$Omega = summary_draws_array(fit$samples$Omega);
    out$Omega0 = summary_draws_array(fit$samples$Omega0);

    out; 
}

summary.brenvlp = function(fit, alpha = 0.05)
{
    out = summary.benvlp(fit, alpha); 
    out$nu = summary_draws(fit$samples$nu); 
    out; 
}

summary.lem = function(fit, alpha = 0.05)
{
    out = summary.benvlp(fit, alpha); 
    out$rho = summary_draws(fit$samples$rho); 

    # row - samples; col - observations 
    mat = pred_loglik_mat(fit);
    n_subject = length(unique(fit$subject));   # number of subject 
    deviance = -2.0 * max(rowSums(mat)); 
    
    out$BIC = deviance + log(n_subject) * fit$npars; 

    tmp = apply(mat, 2, function(a) {matrixStats::logSumExp(a) - var(a)} );
    out$WAIC = -2.0 * (sum(tmp) - ncol(mat) * log(nrow(mat)));

    out; 
}

summary.rolem = function(fit, alpha = 0.05)
{   
    out = summary.lem(fit, alpha); 
    out$nu = summary_draws(fit$samples$nu); 
    out; 
}

summary_draws = function(draws, alpha = 0.05)
{
    N = length(draws); 
    draws_mean = mean(draws); 
    draws_median = median(draws); 
    draws_sd = sd(draws); 

    draws_mcmc = coda::mcmc(draws); 
    draws_HPD = coda::HPDinterval(draws_mcmc, prob = 1 - alpha);
    ess = coda::effectiveSize(draws_mcmc); 

    list(mean = draws_mean, median = draws_median, sd = draws_sd, 
         ess = ess, 
         HPD_low = draws_HPD[1], HPD_upp = draws_HPD[2]);  
}

summary_draws_array = function(draws, alpha = 0.05)
{
    xdim = dim(draws)[-length(dim(draws))];
    out = apply(draws, 1:length(xdim), summary_draws, alpha = alpha);
    list(mean = array(sapply(out, "[[", "mean"), dim = xdim),
         median = array(sapply(out, "[[", "median"), dim = xdim),
         sd = array(sapply(out, "[[", "sd"), dim = xdim),
         ess = array(sapply(out, "[[", "ess"), dim = xdim),
         HPD_low = array(sapply(out, "[[", "HPD_low"), dim = xdim),
         HPD_upp = array(sapply(out, "[[", "HPD_upp"), dim = xdim));
}

######################################################################
# compute WAIC and more 
######################################################################

compute_WAIC = function(fit)
{
    # row - samples; col - observations 
    mat = pred_loglik_mat(fit);

    tmp = apply(mat, 2, function(a) {matrixStats::logSumExp(a) - var(a)} );
    -2.0 * (sum(tmp) - ncol(mat) * log(nrow(mat)));
}

compute_LPPD = function(fit, ...)
{
    mat = pred_loglik_mat(fit, ...);
    tmp = apply(mat, 2, function(a) {matrixStats::logSumExp(a)} );
    (sum(tmp) - ncol(mat) * log(nrow(mat)));
}

######################################################################
# THE END 
######################################################################
