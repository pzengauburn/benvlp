/**********************************************************************
 * Class for correlation matrix   
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CCORMAT__HPP__ 
#define __ZP__CCORMAT__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "Cmat.hpp"

enum class Corr_Type { iid, cs, ar1 };

class Ccormat {
    protected: 
        int order;                /* order of the matrix */
        Corr_Type type;           /* type of correlation matrix */
        double rho;               /* parameter */

    public: 
        Ccormat(); 
        Ccormat(int p, Corr_Type ctype, double param); 
        ~Ccormat(); 

        /**************************************************************
         * get or set values   
         **************************************************************/

        int get_order(); 
        Corr_Type get_type(); 
        double get_rho(); 

        /**************************************************************
         * more functions      
         **************************************************************/

        double det();     /* determinant of the correlation matrix */
        double logdet();  /* log-determinant of the correlation matrix */

        void set_mat(Cmat &Rmat);      /* create the correlation matrix */
        void set_mat_inv(Cmat &Rinv);  /* create the inverse of the correlation matrix */
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
