/**********************************************************************
 * random distributions, density, random number generating 
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28
 * updated: 2025-05-22 (logd_invWishart_inv, logd1_invWishart_inv, logd2_invWishart_inv)
 * updated: 2025-10-17 (log_dinvgauss, rinvgauss) 
 * updated: 2025-10-25 (log_dMnorm0, log_dMT0) 
 **********************************************************************/

#include <R.h> 

#include "distribution.hpp" 

/**********************************************************************
 * log density - normal distribution 
 * log_dnorm() for univariate normal distribution  
 * log_dnorm_vec() for multivariate normal distribution 
 * log_dnorm_mat() for matrix-variate normal distribution 
 *
 * functions with _chol: the input is the Cholesky factorization of Sigma
 * log_dnorm_vec_chol() for multivariate normal distribution 
 * log_dnorm_mat_chol() for matrix-variate normal distribution 
 **********************************************************************/

/* p = dimension, logdet = log(det(Sigma)), delta = (x - mu)' * solve(Sigma) * (x - mu) */
double log_dnorm0(double p, double logdet, double delta)
{
    return( -p * M_LN_SQRT_2PI - 0.5 * logdet - 0.5 * delta ); 
}

double log_dnorm(double x, double mu, double sd)
{
    double z = (x - mu) / sd; 
    return( log_dnorm0(1, 2.0 * log(sd), z * z) ); 
}

double log_dnorm_vec(Cmat &x, Cmat &mu, Cmat &Sigma)
{
    if(! x.is_vector()) 
        error("log_dnorm_vec(): x must be a vector.\n"); 
    if(! mu.is_vector()) 
        error("log_dnorm_vec(): mu must be a vector.\n"); 

    const int p = x.get_vec_length(); 

    if(mu.get_vec_length() != p)
        error("log_dnorm_vec(): x and mu must be the same length.\n"); 
    if((Sigma.get_nrow() != p) || (Sigma.get_ncol() != p))
        error("log_dnorm_vec(): Sigma has an incompatible dimension.\n"); 

    Cmat Schol(p, p);
    Schol.copy(Sigma); 
    Schol.chol(); 
    return( log_dnorm_vec_chol(x, mu, Schol) );  
}

double log_dnorm_vec_chol(Cmat &x, Cmat &mu, Cmat &Schol)
{
    if(! x.is_vector()) 
        error("log_dnorm_vec_chol(): x must be a vector.\n"); 
    if(! mu.is_vector()) 
        error("log_dnorm_vec_chol(): mu must be a vector.\n"); 

    const int p = x.get_vec_length(); 

    if(mu.get_vec_length() != p)
        error("log_dnorm_vec_chol(): x and mu must be the same length.\n"); 
    if((Schol.get_nrow() != p) || (Schol.get_ncol() != p))
        error("log_dnorm_vec_chol(): Sigma has an incompatible dimension.\n"); 

    double logdet = 0.0;  /* log-determinant */
    for(int i = 0; i < p; i++) logdet += log(Schol.get_entry(i, i)); 
    logdet *= 2.0; 

    Cmat xmu(p, 1); 
    xmu.copy(x);
    xmu.axpy(-1.0, mu);               /* xmu = x - mu */
    xmu.trsv("L", "N", "N", Schol);   /* xmu = solve(Schol) * (x - mu) */

    return(log_dnorm0(p, logdet, xmu.sum_sq())); 
}

double log_dnorm_mat(Cmat &x, Cmat &mu, Cmat &Sigma1, Cmat &Sigma2)
{
    const int m = x.get_nrow(); 
    const int n = x.get_ncol(); 

    if((mu.get_nrow() != m) || (mu.get_ncol() != n))
        error("log_dnorm_mat(): the dimension of x and mu do not match.\n"); 
    if((Sigma1.get_nrow() != m) || (Sigma1.get_ncol() != m))
        error("log_dnorm_mat(): the dimension of Sigma1 do not match.\n"); 
    if((Sigma2.get_nrow() != n) || (Sigma2.get_ncol() != n))
        error("log_dnorm_mat(): the dimension of Sigma2 do not match.\n"); 

    Cmat Schol1(m, m);
    Schol1.copy(Sigma1); 
    Schol1.chol(); 

    Cmat Schol2(n, n);
    Schol2.copy(Sigma2); 
    Schol2.chol(); 

    return( log_dnorm_mat_chol(x, mu, Schol1, Schol2) );  
}

double log_dnorm_mat_chol(Cmat &x, Cmat &mu, Cmat &Schol1, Cmat &Schol2)
{
    const int m = x.get_nrow(); 
    const int n = x.get_ncol(); 

    if((mu.get_nrow() != m) || (mu.get_ncol() != n))
        error("log_dnorm_mat(): the dimension of x and mu do not match.\n"); 
    if((Schol1.get_nrow() != m) || (Schol1.get_ncol() != m))
        error("log_dnorm_mat(): the dimension of Schol1 do not match.\n"); 
    if((Schol2.get_nrow() != n) || (Schol2.get_ncol() != n))
        error("log_dnorm_mat(): the dimension of Schol2 do not match.\n"); 

    double logdetS1 = 0.0;  /* log-determinant */
    for(int i = 0; i < m; i++) logdetS1 += log(Schol1.get_entry(i, i)); 
    logdetS1 *= 2.0; 

    double logdetS2 = 0.0;  /* log-determinant */
    for(int i = 0; i < n; i++) logdetS2 += log(Schol2.get_entry(i, i)); 
    logdetS2 *= 2.0; 

    Cmat xmu(m, n);
    xmu.copy(x);
    xmu.axpy(-1.0, mu);                         /* xmu = x - mu */
    xmu.trsm("L", "L", "N", "N", 1.0, Schol1);  /* solve(Schol1) * xmu */
    xmu.trsm("R", "L", "T", "N", 1.0, Schol2);  /* solve(Schol1) * xmu * solve(t(Schol2)) */

    return( log_dnorm0(m*n, (double)(n) * logdetS1 + (double)(m) * logdetS2, xmu.sum_sq())) ; 
}

/**********************************************************************
 * log density of matrix-variate normal distribution Mnorm(M, S1, S2) 
 *     Y  -- a-by-b matrix 
 *     M  -- a-by-b matrix 
 *     S1 -- a-by-a matrix 
 *     S2 -- b-by-b matrix 
 *
 * delta = tr(S1^{-1} * (Y - M) * S2^{-1} * (Y - M)^T)
 * logdetS1 = log(det(S1)) 
 * logdetS2 = log(det(S2)) 
 **********************************************************************/

double log_dMnorm0(double a, double b, double delta, double logdetS1, double logdetS2)
{
    double ans = - a * b * M_LN_SQRT_2PI; 
    ans -= 0.5 * b * logdetS1; 
    ans -= 0.5 * a * logdetS2; 
    ans -= 0.5 * delta; 

    return(ans); 
}

/**********************************************************************
 * log density - t distribution 
 * log_dt() for univariate t distribution  
 * log_dt_vec() for multivariate t distribution 
 * log_dt_mat() for matrix-variate t distribution 
 *
 * functions with _chol: the input is the Cholesky factorization of Sigma
 * log_dt_vec_chol() for multivariate t distribution 
 * log_dt_mat_chol() for matrix-variate t distribution 
 **********************************************************************/

/* p = dimension, logdet = log(det(Sigma)), delta = (x - mu)' * solve(Sigma) * (x - mu) */
double log_dt0(double p, double df, double logdet, double delta)
{
    double ans = lgamma(0.5 * (df + p)) - lgamma(0.5 * df); 
    ans -= (0.5 * log(df) + M_LN_SQRT_PI) * p; 
    ans -= 0.5 * logdet; 
    ans -= 0.5 * (df + p) * log(1.0 + delta / df); 

    return(ans); 
}

double log_dt(double x, double df, double mu, double sd)
{
    double z = (x - mu) / sd; 
    return(log_dt0(1, df, 2.0 * log(sd), z * z)); 
}

double log_dt_vec(Cmat &x, double df, Cmat &mu, Cmat &Sigma)
{
    if(! x.is_vector()) 
        error("log_dt_vec(): x must be a vector.\n"); 
    if(! mu.is_vector()) 
        error("log_dt_vec(): mu must be a vector.\n"); 

    const int p = x.get_vec_length(); 

    if(mu.get_vec_length() != p)
        error("log_dnorm_vec(): x and mu must be the same length.\n"); 
    if((Sigma.get_nrow() != p) || (Sigma.get_ncol() != p))
        error("log_dnorm_vec(): Sigma has an incompatible dimension.\n"); 

    Cmat Schol(p, p);
    Schol.copy(Sigma); 
    Schol.chol(); 
    return( log_dt_vec_chol(x, df, mu, Schol) );  
}

double log_dt_vec_chol(Cmat &x, double df, Cmat &mu, Cmat &Schol)
{
    if(! x.is_vector()) 
        error("log_dt_vec_chol(): x must be a vector.\n"); 
    if(! mu.is_vector()) 
        error("log_dt_vec_chol(): mu must be a vector.\n"); 

    const int p = x.get_vec_length(); 

    if(mu.get_vec_length() != p)
        error("log_dt_vec_chol(): x and mu must be the same length.\n"); 
    if((Schol.get_nrow() != p) || (Schol.get_ncol() != p))
        error("log_dt_vec_chol(): Sigma has an incompatible dimension.\n"); 

    double logdet = 0.0;  /* log-determinant */
    for(int i = 0; i < p; i++) logdet += log(Schol.get_entry(i, i)); 
    logdet *= 2.0; 

    Cmat xmu(p, 1); 
    xmu.copy(x);
    xmu.axpy(-1.0, mu);               /* xmu = x - mu */
    xmu.trsv("L", "N", "N", Schol);   /* xmu = solve(Schol) * (x - mu) */

    return( log_dt0(p, df, logdet, xmu.sum_sq()) );
}

double log_dt_mat(Cmat &x, double df, Cmat &mu, Cmat &Sigma1, Cmat &Sigma2)
{
    const int m = x.get_nrow(); 
    const int n = x.get_ncol(); 

    if((mu.get_nrow() != m) || (mu.get_ncol() != n))
        error("log_dt_mat(): the dimension of x and mu do not match.\n"); 
    if((Sigma1.get_nrow() != m) || (Sigma1.get_ncol() != m))
        error("log_dt_mat(): the dimension of Sigma1 do not match.\n"); 
    if((Sigma2.get_nrow() != n) || (Sigma2.get_ncol() != n))
        error("log_dt_mat(): the dimension of Sigma2 do not match.\n"); 

    Cmat Schol1(m, m);
    Schol1.copy(Sigma1); 
    Schol1.chol(); 

    Cmat Schol2(n, n);
    Schol2.copy(Sigma2); 
    Schol2.chol(); 

    return( log_dt_mat_chol(x, df, mu, Schol1, Schol2) );  
}

double log_dt_mat_chol(Cmat &x, double df, Cmat &mu, Cmat &Schol1, Cmat &Schol2)
{
    const int m = x.get_nrow(); 
    const int n = x.get_ncol(); 

    if((mu.get_nrow() != m) || (mu.get_ncol() != n))
        error("log_dt_mat_chol(): the dimension of x and mu do not match.\n"); 
    if((Schol1.get_nrow() != m) || (Schol1.get_ncol() != m))
        error("log_dt_mat_chol(): the dimension of Schol1 do not match.\n"); 
    if((Schol2.get_nrow() != n) || (Schol2.get_ncol() != n))
        error("log_dt_mat_chol(): the dimension of Schol2 do not match.\n"); 

    double logdetS1 = 0.0;  /* log-determinant */
    for(int i = 0; i < m; i++) logdetS1 += log(Schol1.get_entry(i, i)); 
    logdetS1 *= 2.0; 

    double logdetS2 = 0.0;  /* log-determinant */
    for(int i = 0; i < n; i++) logdetS2 += log(Schol2.get_entry(i, i)); 
    logdetS2 *= 2.0; 

    Cmat xmu(m, n);
    xmu.copy(x);
    xmu.axpy(-1.0, mu);                         /* xmu = x - mu */
    xmu.trsm("L", "L", "N", "N", 1.0, Schol1);  /* solve(Schol1) * xmu */
    xmu.trsm("R", "L", "T", "N", 1.0, Schol2);  /* solve(Schol1) * xmu * solve(t(Schol2)) */

    return(log_dt0(m*n, df, (double)(n) * logdetS1 + (double)(m) * logdetS2, xmu.sum_sq())); 
}

/**********************************************************************
 * log density of matrix-variate t-distribution MT(nu, M, S1, S2) 
 *     Y  -- a-by-b matrix 
 *     M  -- a-by-b matrix 
 *     S1 -- a-by-a matrix 
 *     S2 -- b-by-b matrix 
 *
 * delta = tr(S1^{-1} * (Y - M) * S2^{-1} * (Y - M)^T)
 * logdetS1 = log(det(S1)) 
 * logdetS2 = log(det(S2)) 
 **********************************************************************/

double log_dMT0(double a, double b, double nu, double delta, double logdetS1, double logdetS2)
{
    double ans = lgamma(0.5 * (nu + a * b)) - lgamma(0.5 * nu); 
    ans -= a * b * (0.5 * log(nu) + M_LN_SQRT_PI); 
    ans -= 0.5 * b * logdetS1; 
    ans -= 0.5 * a * logdetS2; 
    ans -= 0.5 * (nu + a * b) * log(1.0 + delta / nu); 

    return(ans); 
}

/**********************************************************************
 * random number generation - normal distribution 
 **********************************************************************/

void rnorm_std(Cmat &x)
{
    const int row = x.get_nrow(); 
    const int col = x.get_ncol(); 
    const int ldx = x.get_ld(); 
    
    double *values = x.get_value_pt(); 
    for(int i = 0; i < row; i++)
    for(int j = 0; j < col; j++)
    {
        values[i + j * ldx] = norm_rand(); 
    }
}

void rnorm_vec(Cmat &x, Cmat &mu, Cmat &Sigma)
{
    if(! x.is_vector()) 
        error("rnorm_vec(): x must be a vector.\n"); 
    if(! mu.is_vector()) 
        error("rnorm_vec(): mu must be a vector.\n"); 

    const int p = x.get_vec_length(); 

    if(mu.get_vec_length() != p)
        error("rnorm_vec(): x and mu must be the same length.\n"); 
    if((Sigma.get_nrow() != p) || (Sigma.get_ncol() != p))
        error("rnorm_vec(): Sigma has an incompatible dimension.\n"); 

    Cmat Schol(p, p);
    Schol.copy(Sigma); 
    Schol.chol();                      /* low-triangular matrix */

    rnorm_vec_chol(x, mu, Schol); 
}

void rnorm_vec_chol(Cmat &x, Cmat &mu, Cmat &Schol)
{
    if(! x.is_vector()) 
        error("rnorm_vec_chol(): x must be a vector.\n"); 
    if(! mu.is_vector()) 
        error("rnorm_vec_chol(): mu must be a vector.\n"); 

    const int p = x.get_vec_length(); 

    if(mu.get_vec_length() != p)
        error("rnorm_vec_chol(): x and mu must be the same length.\n"); 
    if((Schol.get_nrow() != p) || (Schol.get_ncol() != p))
        error("rnorm_vec_chol(): Sigma has an incompatible dimension.\n"); 

    rnorm_std(x);                      /* components are iid N(0, 1) */
    x.trmv("L", "N", "N", Schol);      /* x = Schol * z */
    x.axpy(1.0, mu);                   /* x = mu + Schol * z */
}

void rnorm_vec_inv(Cmat &x, Cmat &mu, Cmat &Sinv)
{
    if(! x.is_vector()) 
        error("rnorm_vec_inv(): x must be a vector.\n"); 
    if(! mu.is_vector()) 
        error("rnorm_vec_inv(): mu must be a vector.\n"); 

    const int p = x.get_vec_length(); 

    if(mu.get_vec_length() != p)
        error("rnorm_vec_inv(): x and mu must be the same length.\n"); 
    if((Sinv.get_nrow() != p) || (Sinv.get_ncol() != p))
        error("rnorm_vec_inv(): Sigma has an incompatible dimension.\n"); 

    Cmat Sinv_chol(p, p);
    Sinv_chol.copy(Sinv); 
    Sinv_chol.chol();                  /* low-triangular matrix */

    rnorm_vec_inv_chol(x, mu, Sinv_chol); 
}

void rnorm_vec_inv_chol(Cmat &x, Cmat &mu, Cmat &Sinv_chol)
{
    if(! x.is_vector()) 
        error("rnorm_vec_inv_chol(): x must be a vector.\n"); 
    if(! mu.is_vector()) 
        error("rnorm_vec_inv_chol(): mu must be a vector.\n"); 

    const int p = x.get_vec_length(); 

    if(mu.get_vec_length() != p)
        error("rnorm_vec_inv_chol(): x and mu must be the same length.\n"); 
    if((Sinv_chol.get_nrow() != p) || (Sinv_chol.get_ncol() != p))
        error("rnorm_vec_inv_chol(): Sigma has an incompatible dimension.\n"); 

    rnorm_std(x);                      /* components are iid N(0, 1) */
    x.trsv("L", "T", "N", Sinv_chol);  /* x = Schol^{-T} * z */
    x.axpy(1.0, mu);                   /* x = mu + Schol^{-T} * z */
}

void rnorm_mat(Cmat &x, Cmat &mu, Cmat &Sigma1, Cmat &Sigma2)
{
    const int m = x.get_nrow(); 
    const int n = x.get_ncol(); 

    if((mu.get_nrow() != m) || (mu.get_ncol() != n))
        error("rnorm_mat(): the dimension of x and mu do not match.\n"); 
    if((Sigma1.get_nrow() != m) || (Sigma1.get_ncol() != m))
        error("rnorm_mat(): the dimension of Sigma1 do not match.\n"); 
    if((Sigma2.get_nrow() != n) || (Sigma2.get_ncol() != n))
        error("rnorm_mat(): the dimension of Sigma2 do not match.\n"); 

    Cmat Schol1(m, m);
    Schol1.copy(Sigma1); 
    Schol1.chol(); 

    Cmat Schol2(n, n);
    Schol2.copy(Sigma2); 
    Schol2.chol(); 

    rnorm_mat_chol(x, mu, Schol1, Schol2);  
}

void rnorm_mat_chol(Cmat &x, Cmat &mu, Cmat &S1chol, Cmat &S2chol)
{
    const int m = x.get_nrow(); 
    const int n = x.get_ncol(); 

    if((mu.get_nrow() != m) || (mu.get_ncol() != n))
        error("rnorm_mat_chol(): the dimension of x and mu do not match.\n"); 
    if((S1chol.get_nrow() != m) || (S1chol.get_ncol() != m))
        error("rnorm_mat_chol(): the dimension of Sigma1 do not match.\n"); 
    if((S2chol.get_nrow() != n) || (S2chol.get_ncol() != n))
        error("rnorm_mat_chol(): the dimension of Sigma2 do not match.\n"); 

    rnorm_std(x);                                /* components are iid N(0, 1) */
    x.trmm("L", "L", "N", "N", 1.0, S1chol);     /* x = S1chol * z */
    x.trmm("R", "L", "T", "N", 1.0, S2chol);     /* x = S1chol * z * S2chol^T */
    x.axpy(1.0, mu);                             /* x = mu + S1chol * z * S2chol^T */
}

void rnorm_mat_inv(Cmat &x, Cmat &mu, Cmat &Sinv1, Cmat &Sinv2)
{
    const int m = x.get_nrow(); 
    const int n = x.get_ncol(); 

    if((mu.get_nrow() != m) || (mu.get_ncol() != n))
        error("rnorm_mat_inv(): the dimension of x and mu do not match.\n"); 
    if((Sinv1.get_nrow() != m) || (Sinv1.get_ncol() != m))
        error("rnorm_mat_inv(): the dimension of Sigma1 do not match.\n"); 
    if((Sinv2.get_nrow() != n) || (Sinv2.get_ncol() != n))
        error("rnorm_mat_inv(): the dimension of Sigma2 do not match.\n"); 

    Cmat Sinv1_chol(m, m);
    Sinv1_chol.copy(Sinv1); 
    Sinv1_chol.chol(); 

    Cmat Sinv2_chol(n, n);
    Sinv2_chol.copy(Sinv2); 
    Sinv2_chol.chol(); 

    rnorm_mat_inv_chol(x, mu, Sinv1_chol, Sinv2_chol);  
}

void rnorm_mat_inv_chol(Cmat &x, Cmat &mu, Cmat &Sinv1chol, Cmat &Sinv2chol)
{
    const int m = x.get_nrow(); 
    const int n = x.get_ncol(); 

    if((mu.get_nrow() != m) || (mu.get_ncol() != n))
        error("rnorm_mat_inv_chol(): the dimension of x and mu do not match.\n"); 
    if((Sinv1chol.get_nrow() != m) || (Sinv1chol.get_ncol() != m))
        error("rnorm_mat_inv_chol(): the dimension of Sigma1 do not match.\n"); 
    if((Sinv2chol.get_nrow() != n) || (Sinv2chol.get_ncol() != n))
        error("rnorm_mat_inv_chol(): the dimension of Sigma2 do not match.\n"); 

    rnorm_std(x);                                /* components are iid N(0, 1) */
    x.trsm("L", "L", "T", "N", 1.0, Sinv1chol);  /* x = Sinv1chol^{-T} * z */
    x.trsm("R", "L", "N", "N", 1.0, Sinv2chol);  /* x = Sinv1chol^{-T} * z * S2chol^{-1} */
    x.axpy(1.0, mu);                             /* x = mu + Sinv1chol^{-T} * z * S2chol^{-1} */
}

/**********************************************************************
 * random number generation - Wishart distribution 
 **********************************************************************/

/**********************************************************************
 * generate a random matrix from Wishart distribution 
 * dimension = n, DF, scale = S 
 * use Bartlett decomposition: X = LAA'L'
 * where S = LL' is the Cholesky factorization of S 
 *       A is lower triangle, on-diagonal iid sqrt( chi^2_{n-i+1} ) 
 *            independent of off-diagonal iid N(0, 1) 
 * the input is the inverse of S or chol of the inverse of S 
 * notice that Sinv = LL' then S = (L')^{-1} * L^{-1}
 **********************************************************************/

void rwishart_std(Cmat &x, double df)
{
    const int n = x.get_nrow(); 
    if(x.get_ncol() != n)
        error("rwishart_std_chol(): x should be a square matrix.\n"); 

    rwishart_std_chol(x, df);
    x.chol_restore();  
}

void rwishart_std_chol(Cmat &x, double df)
{
    const int n = x.get_nrow(); 
    if(x.get_ncol() != n)
        error("rwishart_std_chol(): x should be a square matrix.\n"); 

    const int ldx = x.get_ld(); 
    double *values = x.get_value_pt(); 
    /* create the lower triangle matrix with iid entries */
    for(int i = 0; i < n; i++)
    {
        values[i + i * ldx] = sqrt(rchisq(df - i)); 
        for(int j = 0; j < i; j++) values[i + j * ldx] = norm_rand(); 
        for(int j = i + 1; j < n; j++) values[i + j * ldx] = 0.0; 
    }
}

void rwishart_chol(Cmat &x, double df, Cmat &Schol)
{
    rwishart_std_chol(x, df);  
    x.trmm("L", "L", "N", "N", 1.0, Schol); 
    x.chol_restore(); 
}

void rwishart(Cmat &x, double df, Cmat &Sigma)
{
    const int n = x.get_nrow(); 
    if(x.get_ncol() != n)
        error("rwishart(): x should be a square matrix.\n"); 

    Cmat Schol(n, n);
    Schol.copy(Sigma); 
    Schol.chol(); 

    rwishart_chol(x, df, Schol);  
}

void rwishart_inv(Cmat &x, double df, Cmat &Sinv) 
{
    const int n = x.get_nrow(); 
    if(x.get_ncol() != n)
        error("rwishart_inv(): x should be a square matrix.\n"); 

    Cmat Sinv_chol(n, n);
    Sinv_chol.copy(Sinv); 
    Sinv_chol.chol(); 

    rwishart_inv_chol(x, df, Sinv_chol);  
}

void rwishart_inv_chol(Cmat &x, double df, Cmat &Sinv_chol)
{
    rwishart_std_chol(x, df);  
    x.chol_restore(); 
    x.trsm("L", "L", "T", "N", 1.0, Sinv_chol); 
    x.trsm("R", "L", "N", "N", 1.0, Sinv_chol); 
}

/**********************************************************************
 * compute log density for inverse Wishart (df, Psi)
 * logd1_invWishart_inv(): -0.5 * trace(x_inv * Psi) - 0.5 * (df + p + 1) * logdet(X)
 * logd2_invWishart_inv(): logd1 + 0.5 * df * logdet(Psi)
 * log_invWishart_inv(): log2 - 0.5 * n * p * log(2) - logGamma(df/2)
 **********************************************************************/

double logd1_invWishart_inv(Cmat &x_inv, double df, Cmat &Psi) 
{
    if(! x_inv.is_square())
        error("logd1_invWishart_inv(): x_inv should be a square matrix.\n");
    if(! Psi.is_square())
        error("logd1_invWishart_inv(): Psi should be a square matrix.\n");

    const int p = x_inv.get_nrow(); 
    if(Psi.get_nrow() != p)
        error("logd1_invWishart_inv(): incompatible matrix.\n"); 

    /* xinvPsi = x_inv * Psi */
    Cmat xinvPsi(p, p);
    xinvPsi.gemm("N", "N", 1.0, x_inv, Psi, 0.0); 

    double logd = -0.5 * xinvPsi.trace();
    logd += 0.5 * (df + 1.0 + (double)p) * x_inv.logdet_chol(); 
    return(logd); 
}

double logd2_invWishart_inv(Cmat &x_inv, double df, Cmat &Psi)
{
    double logd = logd1_invWishart_inv(x_inv, df, Psi);
    return(logd + 0.5 * df * Psi.logdet_chol()); 
}

double logd_invWishart_inv(Cmat &x_inv, double df, Cmat &Psi)
{
    const int p = x_inv.get_nrow(); 

    double logd = logd2_invWishart_inv(x_inv, df, Psi);

    logd -= 0.5 * p * df * M_LN2;
    logd -= 0.5 * p * (p - 1.0) * M_LN_SQRT_PI; 
    for(int i = 0; i < p; i++)
    {
        logd -= lgammafn(0.5 * (df - i)); 
    }

    return(logd);
}

/**********************************************************************
 * inverse Gaussian distribution - log density 
 **********************************************************************/

/* M_LN_SQRT_2PI = log(sqrt(2*pi)) */

double log_dinvgauss(double x, double mu, double lambda)
{
    double logden = 0.5 * (log(lambda) - 3.0 * log(x)) - M_LN_SQRT_2PI;
    logden -= lambda / (2.0 * mu) * (x / mu + mu / x - 2.0); 

    return(logden); 
}

/**********************************************************************
 * inverse Gaussian distribution - random number 
 **********************************************************************/

double rinvgauss(double mu, double lambda)
{
    double v = norm_rand(); 
    double w = mu * v * v; 
    double x = mu + mu / (2.0 * lambda) * (w - sqrt(w * (4 * lambda + w)));

    return( (unif_rand() > mu / (mu + x)) ? (mu * mu / x) : (x) ); 
}

/**********************************************************************
 * THE END
 **********************************************************************/
