/**********************************************************************
 * Class for integer matrices and vectors 
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-29  
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CIMAT__HPP__ 
#define __ZP__CIMAT__HPP__ 

#include <R.h> 
#include <Rversion.h>
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include <fstream>
#include <iostream>
#include <iomanip>

#if R_VERSION >= R_Version(4, 5, 0)
#define Calloc R_Calloc 
#define Free R_Free 
#endif

class Cimat {
    protected: 
        int nrow;              /* number of rows */
        int ncol;              /* number of columns */
        int ld;                /* leading dimension */
        int length;            /* length = ld * ncol - (ld - nrow) */
        int *value;            /* values */
        bool is_allocated;     /* true = allocated, false = assigned */

        int inc;               /* increment when it is a vector */
        int vec_length;        /* length as a vector */

    public: 
        Cimat(); 
        Cimat(int n_row, int n_col); 
        Cimat(int n_row, int n_col, int n_ld); 
        Cimat(int n_row, int n_col, int *pt_values); 
        Cimat(int n_row, int n_col, int *pt_values, int n_ld); 
        ~Cimat(); 

        void set_derived();    /* set derived variables in the constructor */

        /**************************************************************
         * get or set values   
         **************************************************************/

        int get_nrow();
        int get_ncol(); 
        int get_ld(); 
        int get_length(); 
        int get_inc(); 
        int get_vec_length(); 

        int get_entry(int row, int col); 
        int get_entry_vec(int i); 
        int *get_value_pt(); 

        void set_entry(int row, int col, int a); 
        void set_entry_vec(int i, int a); 
        void set_value_pt(int *pt_values); 

        /**************************************************************
         * write matrix to a text file  
         **************************************************************/

        void write2stream(std::ostream &stream); 
        void write2file(const char *filename);     /* write to a new file */
        void write2file_app(const char *filename); /* append to an existing file */

        /**************************************************************
         * basic matrix operations  
         **************************************************************/

        void copy(const int *pt_values);        /* values are saved in a contiguous memory block */
        void copy_mem(const int *pt_values);    /* directly copy a contiguous memory block without checking */        
        void copy(Cimat &A);                    /* copy values from an existing matrix */
        
        /* write matrix to a contiguous memory block of length size */
        void write(int *pt_values, int size);      
        /* directly write matrix to a contiguous memory block of length size without checking*/
        void write_mem(int *pt_values, int size);  

        void set_zero();                            /* set all values as zero */ 
        void set_const(int a);                      /* set all values to be a constant */

        bool is_scalar();   /* check whether it is a scalar */
        bool is_vector();   /* check whether it is a vector */
        bool is_square();   /* check whether it is a square matrix */

        /**************************************************************
         * more matrix operations  
         **************************************************************/

        int max();      /* find the maximum of the matrix */
        int min();      /* find the minimum of the matrix */
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
