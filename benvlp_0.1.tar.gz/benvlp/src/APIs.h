/**********************************************************************
 * Bayesian inference for multivariate linear regression  
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-22
 **********************************************************************/

#include <R.h>

/**********************************************************************
 * Bayesian multivariate linear regression 
 **********************************************************************/

void Bmlm_API(
    const int *dims,               /* (n, r, p), length = 3 */
    double *data,                  /* (y, x), length = r * n + p * n */
    const int *control,            /* (burn_in, size, thinning, info), length = 4 */
    int *length_ini,               /* length of ini = r + r * p + r * r */
    double *ini,                   /* (alpha, beta, Sigma_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + r * r */
    double *hyperpars,             /* (beta_mean, beta_col_inv, Sigma_df, Sigma_scale) */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = r + r * p + r * r */
    double *pmean,                 /* posterior mean (alpha, beta, Sigma) */
    int *count);                   /* length = 2, count number of sample generated, number of saved samples */  

/**********************************************************************
 * Bayesian multivariate linear regression, envelope model 
 **********************************************************************/

void Bmlm_envlp_API(
    const int *dims,               /* (n, r, p, u), length = 4 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    const int *control,            /* (burn_in, size, thinning, info), length = 4 */
    int *length_ini,               /* length of ini = r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *ini,                   /* (alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u) * (r-u) * r * r */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mat) */
    int *length_tuning,            /* length of tuning parameters, = 1 */
    double *tuning,                /* pro_Amat_sigma2 */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (alpha, eta, Amat, Omega, Omega0) */
    int *count);                   /* length = 3, count number of sample generated, number of saved samples, A_count */      


/**********************************************************************
 * Bayesian multivariate linear regression, repeated measures 
 **********************************************************************/

void BmlmRM_API(
    const int *dims,               /* (n, r, p, msub), length = 4 */
    double *data,                  /* (y, x), length = r * n + p * n */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* (burn_in, size, thinning, info), length = 4 */
    int *length_ini,               /* length of ini = 1 + r + r * p + r * r */
    double *ini,                   /* (rho, alpha, beta, Sigma_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + r * r */
    double *hyperpars,             /* (beta_mean, beta_col_inv, Sigma_df, Sigma_scale) */
    int *length_tuning,            /* length of tuning parameters, = 1 */
    double *tuning,                /* rho_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + r + r * p + r * r */
    double *pmean,                 /* posterior mean (rho, alpha, beta, Sigma) */
    int *count);                   /* length = 3, count number of sample generated, number of saved samples, rho_count */  

/**********************************************************************
 * Bayesian multivariate linear regression, repeated measures, envelope model 
 **********************************************************************/

void BmlmRM_envlp_API(
    const int *dims,               /* (n, r, p, msub, u), length = 5 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* (burn_in, size, thinning, info), length = 4 */
    int *length_ini,               /* length of ini = 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *ini,                   /* (rho, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u)*(r-u) + r * r */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mmat) */
    int *length_tuning,            /* length of tuning parameters, = 2 */
    double *tuning,                /* rho_delta, Mmat_sigma2 */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (rho, alpha, eta, Amat, Omega, Omega0) */
    int *count);                   /* length = 4, count number of sample generated, number of saved samples, rho_count, A_count */  

/**********************************************************************
 * Bayesian multivariate linear regression, repeated measures, envelope model, t-distribution  
 **********************************************************************/

void BrmlmRM_envlp_API(
    const int *dims,               /* (n, r, p, msub, u), length = 5 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) + msub */
    double *ini,                   /* (rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u)*(r-u) + r * r + 1 + 1 */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mmat, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 3 */
    double *tuning,                /* rho_delta, Mmat_sigma2, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + 1 + msub + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (rho, nu, tau, alpha, eta, Amat, Omega, Omega0) */
    int *count);                   /* length = 5, count number of sample generated, number of saved samples, rho_count, A_count, nu_count */  

void BrmlmRM_envlp_det_API(
    const int *dims,               /* (n, r, p, msub, u), length = 5 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) + msub */
    double *ini,                   /* (rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u)*(r-u) + r * r + 1 + 1 */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mmat, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 3 */
    double *tuning,                /* rho_delta, Mmat_sigma2, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + 1 + msub + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (rho, nu, tau, alpha, eta, Amat, Omega, Omega0) */
    int *count);                   /* length = 5, count number of sample generated, number of saved samples, rho_count, A_count, nu_count */  

void BrmlmRM2_envlp_API(
    const int *dims,               /* (n, r, p, msub, u), length = 5 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) + msub */
    double *ini,                   /* (rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u)*(r-u) + r * r + 1 + 1 */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mmat, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 3 */
    double *tuning,                /* rho_delta, Mmat_sigma2, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + 1 + msub + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (rho, nu, tau, alpha, eta, Amat, Omega, Omega0) */
    int *count);                   /* length = 5, count number of sample generated, number of saved samples, rho_count, A_count, nu_count */  

/**********************************************************************
 * Bayesian multivariate linear regression, repeated measures, envelope model, t-distribution  
 * assume equal time points 
 **********************************************************************/

void BrmlmRM_envlp0_API(
    const int *dims,               /* (n, r, p, msub, u, J, type), length = 7, 0 = IID, 1 = CS, 2 = AR1 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) + msub */
    double *ini,                   /* (rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u)*(r-u) + r * r + 1 + 1 */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mmat, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 3 */
    double *tuning,                /* rho_delta, Mmat_sigma2, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + 1 + msub + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (rho, nu, tau, alpha, eta, Amat, Omega, Omega0) */
    int *count);                   /* length = 5, count number of sample generated, number of saved samples, rho_count, A_count, nu_count */  

void BrmlmRM_envlp_det0_API(
    const int *dims,               /* (n, r, p, msub, u, J, type), length = 7, 0 = IID, 1 = CS, 2 = AR1 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) + msub */
    double *ini,                   /* (rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u)*(r-u) + r * r + 1 + 1 */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mmat, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 3 */
    double *tuning,                /* rho_delta, Mmat_sigma2, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + 1 + msub + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (rho, nu, tau, alpha, eta, Amat, Omega, Omega0) */
    int *count);                   /* length = 5, count number of sample generated, number of saved samples, rho_count, A_count, nu_count */  

void BrmlmRM_envlp_norm0_API(
    const int *dims,               /* (n, r, p, msub, u, J, type), length = 7, 0 = IID, 1 = CS, 2 = AR1 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + 1 + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) + msub */
    double *ini,                   /* (rho, nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u)*(r-u) + (r-u)*u + (r-u)*(r-u) + u*u + 1 + 1 */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Amat_mean, K_inv, L_inv, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 3 */
    double *tuning,                /* rho_delta, Mmat_sigma2, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + 1 + msub + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (rho, nu, tau, alpha, eta, Amat, Omega, Omega0) and WAIC */
    int *count);                   /* length = 5, count number of sample generated, number of saved samples, rho_count, A_count, nu_count */  
    
/**********************************************************************
 * Bayesian multivariate linear regression, repeated measures, t-distribution  
 **********************************************************************/

void BrmlmRM_API(
    const int *dims,               /* (n, r, p, msub), length = 4 */
    double *data,                  /* (y, x), length = r * n + p * n */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + 1 + nsub + r + r * p + r * r */
    double *ini,                   /* (rho, nu, tau, alpha, beta, Sigma_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + r * r + 2 */
    double *hyperpars,             /* (beta_mean, beta_col_inv, Sigma_df, Sigma_scale, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 2 */
    double *tuning,                /* rho_delta, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + 1 + msub + r + r * p + r * r */
    double *pmean,                 /* posterior mean (rho, nu, tau, alpha, beta, Sigma) */
    int *count);                   /* length = 4, count number of sample generated, number of saved samples, rho_count, nu_count */  

/**********************************************************************
 * Bayesian multivariate linear regression, envelope model 
 * robust 
 **********************************************************************/

void Brmlm_envlp_API(
    const int *dims,               /* (n, r, p, u), length = 4 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + n + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *ini,                   /* (nu, tau, alpha, eta, Amat, Omega_inv, Omega0_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + u * u + 1 + (r-u) * (r-u) * r * r + 1 + 1 */
    double *hyperpars,             /* (eta_mean, eta_col_inv, Omega_df, Omega_scale, Omega0_df, Omega0_scale, Mat, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 2 */
    double *tuning,                /* pro_Amat_sigma2, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + n + r + u * p + (r-u)*u + u*u + (r-u)*(r-u) */
    double *pmean,                 /* posterior mean (nu, tau, alpha, eta, Amat, Omega, Omega0) */
    int *count);                   /* length = 4, count number of sample generated, number of saved samples, A_count, nu_count */       

/**********************************************************************
 * compute log-likelihood 
 **********************************************************************/

void BrmlmRM_loglik(
    const int *dims,               /* (n, r, p, msub), length = 4 */
    double *data,                  /* (y, x), length = r * n + p * n */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* assume_normal, length = 1 */
    int *length_samples,           /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    double *logf);                 /* length_sample by msub matrix */  

void BmlmRM_envlp_loglik(
    const int *dims,               /* (n, r, p, msub, u), length = 5 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    int *length_samples,           /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    double *logf);                 /* length_sample by msub matrix */  

void BrmlmRM_envlp_loglik(
    const int *dims,               /* (n, r, p, msub, u), length = 5 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* assume_normal, length = 1 */
    int *length_samples,           /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    double *logf);                 /* length_sample by msub matrix */  

void BrmlmRM_envlp0_loglik(
    const int *dims,               /* (n, r, p, msub, u, J, type), length = 7, 0 = IID, 1 = CS, 2 = AR1 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    const int *control,            /* assume_normal, length = 1 */
    int *length_samples,           /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    double *logf);                 /* length_sample by msub matrix */  

/**********************************************************************
 * THE END
 **********************************************************************/
