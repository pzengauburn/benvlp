/**********************************************************************
 * Class for linear regression with repeated measures  
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-30
 * updated: 2025-03-13
 * updated: 2025-10-22  
 **********************************************************************/

#include <R.h> 
#include "ClinregRM.hpp"
#undef beta 

/**********************************************************************
 * variables defined in Creg: (5)
 *     Cmat *x;                     predictor - p-by-n matrix 
 *     Cmat *y;                     response - r-by-n matrix 
 *     int n_obs;                   number of observations 
 *     int p_var;                   number of predictors 
 *     int r_resp;                  number of responses 
 *
 * variables defined in Clinreg: (4) 
 *     bool has_intercept;          true = with intercept, false = no intercept 
 *     Cmat *alpha;                 intercept - r-by-1 matrix 
 *     Cmat *beta;                  slope - r-by-p matrix 
 *     Cmat *res;                   residual - r-by-n matrix 
 * 
 * variables defined in ClinregRM: (9)
 *     int m_sub;                   number of subjects 
 *     int Jmax;                    max(Jvec) 
 *     Cimat *Jvec;                 number of observations for each subject, length = n_sub 
 *     Corr_Type ctype;             correlation structure 
 *     double rho;                  parameter in correlation 
 *     Cmat *Sigma_inv;             r-by-r matrix 
 *     Cmat *deltaRM;               msub-by-1 matrix 
 *     double pro_rho_delta;        scalar - tuning parameter 
 *     int rho_count;               count the number of accepted rho 
 **********************************************************************/

ClinregRM::ClinregRM()
{
    this->m_sub = 0;
    this->Jmax = 0;
    this->Jvec = nullptr;
    this->ctype = Corr_Type::iid;
    this->rho = 0.0; 
    this->Sigma_inv = nullptr;
    this->deltaRM = nullptr;
    this->pro_rho_delta = 0.0; 
    this->rho_count = 0; 
}
        
ClinregRM::ClinregRM(Cmat *x_pt, Cmat *y_pt, bool intercept, Cimat *Jvec_pt, Corr_Type cp)
    : Clinreg(x_pt, y_pt, intercept)
{
    if(! Jvec_pt->is_vector())
        error("ClinregRM::ClinregRM(): Jvec should be a vector.\n"); 

    this->Jvec = Jvec_pt; 
    this->ctype = cp; 

    this->m_sub = this->Jvec->get_vec_length(); 
    this->Jmax = this->Jvec->max();  

    this->rho = 0.0; 

    this->Sigma_inv = new Cmat(this->r_resp, this->r_resp, nullptr); 
    this->deltaRM = new Cmat(this->m_sub, 1); 

    this->pro_rho_delta = 0.0; 
    this->rho_count = 0; 
}  

/**********************************************************************
 * destructor 
 **********************************************************************/

ClinregRM::~ClinregRM()
{
    delete this->Sigma_inv; 
    delete this->deltaRM; 
}

/**********************************************************************
 * write information to file 
 **********************************************************************/

void ClinregRM::write2stream(std::ostream &stream)  
{
    Clinreg::write2stream(stream); 

    stream << "\nnumber of subject = " << this->m_sub << std::endl;

    stream << "correlation type = ";  
    if(this->ctype == Corr_Type::iid) stream << "IID\n";
    else if(this->ctype == Corr_Type::cs) stream << "CS\n";
    else if (this->ctype == Corr_Type::ar1) stream << "AR1\n";
    else stream << "unsupported corelation type.\n"; 
    
    stream << "rho = " << this->rho << std::endl;
    stream << "Jvec = (" << this->Jvec->get_entry_vec(0) << ", ..., " 
           << this->Jvec->get_entry_vec(this->m_sub - 1) << ")\n";
}

/**********************************************************************
 * more functions  
 **********************************************************************/

/* compute deltaRM = tr() */

void ClinregRM::compute_deltaRM()
{
    Cmat rRr(this->r_resp, this->r_resp);

    for(int i = 0, pos = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 
        /* residual corresponding to the i-th subject */
        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji);
        cor.set_mat_inv(Rinv); 

        /* compute res[i] %*% Rinv %*% t(res[i]) */
        rRr.ABAt(1.0, res_i, Rinv, 0.0); 

        /* compute sum( Sigma_inv * (res[i] %*% Rinv %*% t(res[i])) ) */
        this->deltaRM->set_entry_vec(i, this->Sigma_inv->dot(rRr)); 

        /* update position for res_i */
        pos += Ji * (this->r_resp); 
    }
} 

/**********************************************************************
 * Rsum = 0.0; 
 * mu.alpha = numeric(r); 
 * res.alpha = y - x %*% t(iSample$beta); 
 * for(i in 1:n_subject)
 * {
 *     index = which(subject == i); 
 *     Rinv = cor.inv(length(index), iSample$rho, cor.type);
 *     mu.alpha = mu.alpha + colSums(Rinv %*% res.alpha[index, ]); 
 *     Rsum = Rsum + sum(Rinv); 
 * }
 *
 * iSample$alpha = MASS::mvrnorm(1, 
 *                     mu = mu.alpha / Rsum, 
 *                     Sigma = iSample$Sigma / Rsum); 
 **********************************************************************/

void ClinregRM::sample_alpha()
{
    /* res = y - beta * x */
    this->res->copy(*(this->y)); 
    this->res->gemm("N", "N", -1.0, *(this->beta), *(this->x), 1.0); 

    /* mu_alpha = numeric(r) */
    Cmat mu_alpha(this->r_resp, 1); 
    mu_alpha.set_zero(); 

    double Rsum = 0.0; 
    Cmat mu_i(this->r_resp, 1); 

    for(int i = 0, pos = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        /* resRinv = res.alpha[, index] %*% Rinv */
        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos); 
        Cmat resRinv(this->r_resp, Ji);
        resRinv.gemm("N", "N", 1.0, res_i, Rinv, 0.0); 

        /* mu_i = colSums(Rinv %*% res.alpha[index, ]) */
        mu_i.rowSums(resRinv); 

        /* mu_alpha = mu_alpha + mu_i */
        mu_alpha.axpy(1.0, mu_i); 

        /* Rsum = Rsum + sum(Rinv) */
        Rsum += Rinv.sum(); 

        /* update position for res_i */
        pos += Ji * (this->r_resp); 
    }

    mu_alpha.scale(1 / Rsum); 

    /* Sigma_inv_alpha = Rsum * Sigma_inv */
    Cmat Sigma_inv_alpha(this->r_resp, this->r_resp); 
    Sigma_inv_alpha.copy(*(this->Sigma_inv)); 
    Sigma_inv_alpha.scale(Rsum); 

    rnorm_vec_inv(*(this->alpha), mu_alpha, Sigma_inv_alpha);
}

/**********************************************************************
 * rho.new = iSample$rho + runif(1, -1, 1) * pro.pars$rho.delta; 
 * if(rho.new > 1) rho.new = 2 - rho.new;
 * if(rho.new < 0) rho.new = -rho.new; 
 * 
 * rho.loglik.old = 0.0; 
 * rho.loglik.new = 0.0; 
 * for(i in 1:n_subject)
 * {
 *    index = which(subject == i); 
 *    Rinv = cor.inv(length(index), iSample$rho, cor.type);
 *    idelta = sum((t(res[index, ]) %*% Rinv %*% res[index, ]) * Sigma.inv); 
 *    rho.loglik.old = (rho.loglik.old 
 *                        - 0.5 * r * cor.logdet(length(index), iSample$rho, cor.type) 
 *                        - 0.5 * idelta); 
 *
 *    Rinv = cor.inv(length(index), rho.new, cor.type);
 *    idelta = sum((t(res[index, ]) %*% Rinv %*% res[index, ]) * Sigma.inv); 
 *    rho.loglik.new = (rho.loglik.new 
 *                        - 0.5 * r * cor.logdet(length(index), rho.new, cor.type) 
 *                        - 0.5 * idelta); 
 * }
 *
 * rho.logratio = rho.loglik.new - rho.loglik.old; 
 * if(log(runif(1)) < rho.logratio)
 * {
 *    iSample$rho = rho.new; 
 *    iSample$rho.accept = iSample$rho.accept + 1; 
 * }
 **********************************************************************/

/* when tau  = 1 (normal), sum_tau_delta = this->deltaRM->sum() */
/* when tau != 1 (t),      sum_tau_delta = this->tau->dot(*(this->deltaRM)) */

void ClinregRM::sample_rho()
{
    /* save current value of deltaRM and rho */
    Cmat deltaRM_cur(this->m_sub, 1);
    deltaRM_cur.copy(*(this->deltaRM)); 
    double rho_cur = this->rho; 

    double loglik_old = this->compute_loglik_rho(this->deltaRM->sum()); 

    /* rho.new = iSample$rho + runif(1, -1, 1) * pro.pars$rho.delta;  */
    double rho_new = runif(this->rho - this->pro_rho_delta, 
                           this->rho + this->pro_rho_delta); 
    if(rho_new > 1.0) rho_new = 2.0 - rho_new; 
    if(rho_new < 0.0) rho_new = -rho_new;  

    this->rho = rho_new; 
    this->compute_deltaRM(); 

    double loglik_new = this->compute_loglik_rho(this->deltaRM->sum()); 

    if(log(unif_rand()) < (loglik_new - loglik_old))
    {
        /* acccept proposed rho */
        (this->rho_count) ++; 
    }
    else 
    {
        /* reject proposed rho */
        this->rho = rho_cur; 
        this->deltaRM->copy(deltaRM_cur); 
    }
}

/**********************************************************************
 * sample rho 
 *
    rho.loglik.old = (-0.5 * sum(iSample$tau * iSample$Delta) 
                      -0.5 * prob$r * sum(tenvlp2.compute.R.logdet(prob$Jvec, iSample$rho, prob$cor.type))); 

    rho.new = runif(1, iSample$rho - pro.pars$rho.delta, iSample$rho + pro.pars$rho.delta);
    if(rho.new < 0) rho.new = -rho.new; 
    if(rho.new > 0) rho.new = 2 - rho.new; 

    iSample.new = iSample; 
    iSample.new$rho = rho.new; 
    iSample.new$Delta = tenvlp2.compute.Delta(prob, iSample.new);  
    rho.loglik.new = (-0.5 * sum(iSample.new$tau * iSample.new$Delta)
                      -0.5 * prob$r * sum(tenvlp2.compute.R.logdet(prob$Jvec, iSample.new$rho, prob$cor.type)));

    rho.logratio = rho.loglik.new - rho.loglik.old; 
    if(log(runif(1)) < rho.logratio) 
    {
        iSample = iSample.new; 
        iSample$rho.count = iSample$rho.count + 1; 
    }
 **********************************************************************/

void ClinregRM::sample_rho_t(Cmat &tau)
{
    /* save current value of deltaRM and rho */
    Cmat deltaRM_cur(this->m_sub, 1);
    deltaRM_cur.copy(*(this->deltaRM)); 
    double rho_cur = this->rho; 

    double loglik_old = this->compute_loglik_rho(tau.dot(*(this->deltaRM))); 

    /* rho.new = iSample$rho + runif(1, -1, 1) * pro.pars$rho.delta;  */
    double rho_new = runif(this->rho - this->pro_rho_delta, 
                           this->rho + this->pro_rho_delta); 
    if(rho_new > 1.0) rho_new = 2.0 - rho_new; 
    if(rho_new < 0.0) rho_new = -rho_new;  

    this->rho = rho_new; 
    this->compute_deltaRM(); 

    double loglik_new = this->compute_loglik_rho(tau.dot(*(this->deltaRM))); 

    if(log(unif_rand()) < (loglik_new - loglik_old))
    {
        /* acccept proposed rho */
        (this->rho_count) ++; 
    }
    else 
    {
        /* reject proposed rho */
        this->rho = rho_cur; 
        this->deltaRM->copy(deltaRM_cur); 
    }
}

/**********************************************************************
 * sample log-likelihood for sampling rho 
 *
    (-0.5 * sum(iSample$tau * iSample$Delta) 
     -0.5 * prob$r * sum(tenvlp2.compute.R.logdet(prob$Jvec, iSample$rho, prob$cor.type))); 
 **********************************************************************/

/* when tau  = 1 (normal), sum_tau_delta = this->deltaRM->sum() */
/* when tau != 1 (t),      sum_tau_delta = this->tau->dot(*(this->deltaRM)) */

double ClinregRM::compute_loglik_rho(double sum_tau_delta)
{
    double ans = 0.0; 
    for(int i = 0; i < (this->m_sub); i++)
    {
        /* inverse of the correlation matrix */
        int Ji = this->Jvec->get_entry_vec(i); 
        Ccormat cor(Ji, this->ctype, this->rho); 
        /* ans += logR */
        ans += cor.logdet(); 
    } 

    /* ans = sum(logdet(R)) */
    return( (-0.5) * ((double)(this->r_resp) * ans + sum_tau_delta) ); 
} 

/**********************************************************************
 * sample alpha 
 *
    sc = 0.0; 
    mu.alpha = numeric(prob$r); 
    res.alpha = prob$y - prob$x %*% t(iSample$beta); 
    for(i in 1:prob$nsubject)
    {
        R.inv = cor.inv(prob$Jvec[i], iSample$rho, prob$cor.type); 
        sc = sc + sum(R.inv) * iSample$tau[i];
        mu.alpha = mu.alpha + iSample$tau[i] * rowSums(t(res.alpha[prob$subject == i, , drop = FALSE]) %*% R.inv);
    }

    iSample$alpha = MASS::mvrnorm(1, 
                    mu = mu.alpha / sc, 
                    Sigma = solve(iSample$Sigma.e.inv) / sc);
 **********************************************************************/
        
void ClinregRM::sample_alpha_t(Cmat &tau)
{
    /* compute res = y - b * x */
    this->res->copy(*(this->y)); 
    this->res->gemm("N", "N", -1.0, *(this->beta), *(this->x), 1.0); 

    double sc = 0.0; 
    Cmat mu(this->r_resp, 1);
    mu.set_zero(); 

    Cmat vec(this->r_resp, 1);

    for(int i = 0, pos_res = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        sc += tau.get_entry_vec(i) * Rinv.sum(); 

        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos_res); 
        Cmat mat(this->r_resp, Ji);
        mat.gemm("N", "N", 1.0, res_i, Rinv, 0.0);

        vec.rowSums(mat); 
        mu.axpy(tau.get_entry_vec(i), vec); 

        /* update position for res_i */
        pos_res += Ji * (this->r_resp); 
    }

    mu.scale(1.0 / sc); 

    Cmat Sinv(this->r_resp, this->r_resp);
    Sinv.copy(*(this->Sigma_inv));
    Sinv.scale(sc); 

    rnorm_vec_inv(*(this->alpha), mu, Sinv);
}

/**********************************************************************
 * THE END
 **********************************************************************/
