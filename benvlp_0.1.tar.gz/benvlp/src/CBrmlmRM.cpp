/**********************************************************************
 * Class for Bayesian inference for multivariate linear regression  
 * with repeated measures, t-distribution   
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-27 
 **********************************************************************/

#include <R.h> 
#include "CBrmlmRM.hpp" 
#undef beta 

/**********************************************************************
 * variables defined in Creg: (5)
 *     Cmat *x;                     predictor - p-by-n matrix 
 *     Cmat *y;                     response - r-by-n matrix 
 *     int n_obs;                   number of observations 
 *     int p_var;                   number of predictors 
 *     int r_resp;                  number of responses 
 *
 * variables defined in Clinreg: (4)  
 *     bool has_intercept;          true = with intercept, false = no intercept 
 *     Cmat *alpha;                 intercept - r-by-1 matrix 
 *     Cmat *beta;                  slope - r-by-p matrix 
 *     Cmat *res;                   residual - r-by-n matrix 
 * 
 * variables defined in ClinregRM: (9)
 *     int m_sub;                   number of subjects 
 *     int Jmax;                    max(Jvec) 
 *     Cimat *Jvec;                 number of observations for each subject, length = m_sub 
 *     Corr_Type ctype;             correlation structure 
 *     double rho;                  parameter in correlation 
 *     Cmat *Sigma_inv;             r-by-r matrix 
 *     Cmat *deltaRM;               msub-by-1 matrix 
 *     double pro_rho_delta;        scalar 
 *     int rho_count;               number of times a proposed rho is accepted       
 *
 * variables defined in Cmcmc: (13)
 *     int burn_in_mcmc;            number of samples to be discarded 
 *     int size_mcmc;               number of samples after burn-in period 
 *     int thinning_mcmc;           save every k-th samples 
 *     int info_mcmc;               display information every k samples 
 *     int count_mcmc;              total number of samples generated 
 *     int count_output_mcmc;       number of samples saved 
 *     int length_pars;             length of parameters, including latent variables 
 *     double *pars;                vector of parameters, length = length_pars 
 *     int max_saved_draws;         maximum number of saved samples 
 *     int length_saved_pars;       length of parameters to be saved 
 *     double *samples;             space to save samples = max_saved_draws * length_saved_pars 
 *     int length_hyperpars;        number of hyperparameters in prior distribution 
 *     int length_tuning;           number of tuning parameters in proposal distribution
 * 
 * variables defined in CBtGamma: (6)
 *
 *     Cmat *tau;                   latent variable 
 *     double nu;                   degrees of freedom 
 *     double hyper_nu_shape;       scalar - hyperparameter in Gamma distribution 
 *     double hyper_nu_rate;        scalar - hyperparameter in Gamma distribution 
 *     double pro_nu_delta;         tuning parameter in proposal distribution 
 *     int nu_count;                count the number of accepted nu 
 *
 * variables defined in CBrmlmRM: (5)
 *     bool assume_normal;          1 = normal, 0 = t-distribution 
 *     Cmat *hyper_beta_mean;       r-by-p matrix  --  hyper-parameter in prior  
 *     Cmat *hyper_beta_col_inv;    p-by-p matrix  --  hyper-parameter in prior
 *     double hyper_Sigma_df;       scalar         --  hyper-parameter in prior 
 *     Cmat *hyper_Sigma_scale;     r-by-r matrix  --  hyper-parameter in prior 
 **********************************************************************/

CBrmlmRM::CBrmlmRM()
{
    this->assume_normal = true;
    this->hyper_beta_mean = nullptr;
    this->hyper_beta_col_inv = nullptr;
    this->hyper_Sigma_df = 0.0; 
    this->hyper_Sigma_scale = nullptr; 
}

CBrmlmRM::CBrmlmRM(Cmat *x_pt, Cmat *y_pt, Cimat *Jvec_pt, Corr_Type cp, 
        bool normal, 
        int burn_in, int size, int thinning, int info, int length)
    : ClinregRMt(x_pt, y_pt, true, Jvec_pt, cp), 
      Cmcmc(burn_in, size, thinning, info, length) 
{
    /* parameters = (rho, nu, tau, alpha, beta, Sigma_inv)*/
    /* total number of parameters = 1 + 1 + msub + r + r * p + r * r */
    this->length_pars = 1                                /* rho */
                    + 1                                  /* nu */
                    + (this->m_sub)                      /* tau */
                    + (this->r_resp)                     /* alpha - r */
                    + (this->r_resp) * (this->p_var)     /* beta - r*p */
                    + (this->r_resp) * (this->r_resp);   /* Sigma_inv - r*r */
    if(length < (this->length_pars)) 
    {
        error("CBrmlmRM::CBrmlmRM(): incorrect number of parameters.\n"); 
    }

    this->assume_normal = normal; 

    /* link the parameters to the space allocated in Cmcmc */
    int offset = 2;                   /* the first two are rho, nu */ 
    this->tau->set_value_pt(this->pars + offset); 
    offset += (this->m_sub); 
    this->alpha->set_value_pt(this->pars + offset);
    offset += (this->r_resp); 
    this->beta->set_value_pt(this->pars + offset);
    offset += (this->r_resp) * (this->p_var);     
    this->Sigma_inv->set_value_pt(this->pars + offset); 

    /* length of all hyperparameters combined */ 
    this->length_hyperpars = (this->r_resp) * (this->p_var)         /* beta_mean (r-by-p) */
                             + (this->p_var) * (this->p_var)        /* best_col_inv (p-by-p) */
                             + 1                                    /* Sigma_df (1) */
                             + (this->r_resp) * (this->r_resp)      /* Sigma_scale (r-by-r) */
                             + 1                                    /* nu_shape */
                             + 1;                                   /* nu_rate */

    this->hyper_beta_mean = new Cmat(this->r_resp, this->p_var);  
    this->hyper_beta_col_inv = new Cmat(this->p_var, this->p_var);    
    this->hyper_Sigma_scale = new Cmat(this->r_resp, this->r_resp); 

    this->hyper_Sigma_df = 0.0; 
        
    this->length_tuning = 2;                 /* pro_rho_delta, nu_delta */
}

/**********************************************************************
 * destructor 
 **********************************************************************/

CBrmlmRM::~CBrmlmRM() 
{
    delete this->hyper_beta_mean;
    delete this->hyper_beta_col_inv;
    delete this->hyper_Sigma_scale;
} 

/**********************************************************************
 * set parameters  
 **********************************************************************/

void CBrmlmRM::set_ini_pars(int length, double *pt)
{
    if((this->length_pars) != length)
        error("CBrmlmRM::set_ini(): wrong size of pt.\n");

    int offset = 0; 

    this->rho = pt[offset];
    offset++; 

    this->nu = pt[offset];
    offset ++; 

    this->tau->copy(pt + offset); 
    offset += this->tau->get_length(); 

    this->alpha->copy(pt + offset); 
    offset += this->r_resp; 

    this->beta->copy(pt + offset); 
    offset += (this->r_resp) * (this->p_var);     
    
    this->Sigma_inv->copy(pt + offset); 
}

/**********************************************************************
 * set hyperparameters in prior distributions 
 **********************************************************************/

void CBrmlmRM::set_hyperpars(int length, double *pt)
{
    if((this->length_hyperpars) != length)
    {
        std::cout << "length_hyperpars = " << this->length_hyperpars << std::endl;
        std::cout << "length = " << length << std::endl;
        error("CBrmlmRM::set_hyperpars(): wrong size of pt.\n");
    }
    
    int offset = 0; 

    this->hyper_beta_mean->copy(pt + offset); 
    offset += (this->r_resp) * (this->p_var); 

    this->hyper_beta_col_inv->copy(pt + offset);
    offset += (this->p_var) * (this->p_var); 

    this->hyper_Sigma_df = pt[offset];
    offset ++;

    this->hyper_Sigma_scale->copy(pt + offset);
    offset += (this->r_resp) * (this->r_resp);

    this->hyper_nu_shape = pt[offset];
    offset ++;

    this->hyper_nu_rate = pt[offset];
}


void CBrmlmRM::set_tuning(int length, double *pt)
{
    if((this->length_tuning) != length)
    {
        error("CBrmlmRM::set_tuning(): wrong size of pt.\n");
    }

    this->pro_rho_delta = pt[0]; 
    this->pro_nu_delta = pt[1];     
}

/**********************************************************************
 * write information
 **********************************************************************/

void CBrmlmRM::write2stream(std::ostream &stream)
{
    ClinregRM::write2stream(stream); 

    stream << "\nSigma_inv =\n"; 
    this->Sigma_inv->write2stream(stream, false); 

    stream << "\nerror distribution = ";   
    if(this->assume_normal) stream << "1 = normal distribution\n";
    else stream << "0 = t-distribution\n";     

    stream << "\nnu = " << this->nu << std::endl;
    stream << "\ntau = (" << this->tau->get_entry_vec(0) << ", ..., " 
           << this->tau->get_entry_vec(this->m_sub - 1) << ")\n";

    Cmcmc::write2stream(stream); 

    stream << "\nhyper_beta_mean =\n";
    this->hyper_beta_mean->write2stream(stream, false);

    stream << "\nhyper_beta_col_inv =\n";
    this->hyper_beta_col_inv->write2stream(stream, false);

    stream << "\nhyper_Sigma_df = " << this->hyper_Sigma_df << std::endl;

    stream << "\nhyper_Sigma_scale =\n";
    this->hyper_Sigma_scale->write2stream(stream, false);

    stream << "\nhyper_nu_shape = " << this->hyper_nu_shape << std::endl;
    stream << "\nhyper_nu_rate = " << this->hyper_nu_rate << std::endl;

    stream << "\npro_rho_delta = " << this->pro_rho_delta << std::endl;
    stream << "\npro_nu_delta = " << this->pro_nu_delta << std::endl;
}  

/**********************************************************************
 * sample from posterior distributions 
 **********************************************************************/

/**********************************************************************
 * Hmat.new = hyper.pars$Hmat; 
 * xi.new = hyper.pars$xi %*% hyper.pars$Hmat; 
 * res.beta = sweep(y, 2, drop(iSample$alpha), "-"); 
 * for(i in 1:n_subject)
 * {
 *     index = which(subject == i); 
 *     Rinv = cor.inv(length(index), iSample$rho, cor.type);
 *     Hmat.new = Hmat.new + t(x[index, ]) %*% Rinv %*% x[index, ];
 *     xi.new = xi.new + t(res.beta[index, ]) %*% Rinv %*% x[index, ];
 * }
 * xi.new = xi.new %*% solve(Hmat.new); 
 *
 * iSample$beta = xi.new + 
 *             t(chol(iSample$Sigma)) %*%
 *             matrix(rnorm(r*p), nrow = r, ncol = p) %*%
 *             chol(solve(Hmat.new)); 
 **********************************************************************/

void CBrmlmRM::sample_beta()
{
    /* res = y - alpha * 1^T */
    this->res->copy(*(this->y)); 
    this->res->axpy_col(-1.0, *(this->alpha)); 

    /* Hmat_new = hyper.pars$Hmat */
    Cmat Hmat_new(this->p_var, this->p_var); 
    Hmat_new.copy(*(this->hyper_beta_col_inv));

    /* xi_new = hyper.pars$xi %*% hyper.pars$Hmat */
    Cmat xi_new(this->r_resp, this->p_var); 
    xi_new.gemm("N", "N", 1.0, *(this->hyper_beta_mean), *(this->hyper_beta_col_inv), 0.0); 

    for(int i = 0, pos_res = 0, pos_x = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        /* Rinvxi = Rinv %*% x[index, ]; */
        Cmat xi(this->p_var, Ji, this->x->get_value_pt() + pos_x); 
        Cmat Rinvxi(Ji, this->p_var); 
        Rinvxi.gemm("N", "T", 1.0, Rinv, xi, 0.0); 

        /* Hmat.new = Hmat.new + t(x[index, ]) %*% Rinv %*% x[index, ] */
        Hmat_new.gemm("N", "N", this->tau->get_entry_vec(i), xi, Rinvxi, 1.0);
                 
        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos_res); 
        /* xi_new = xi.new + t(res.beta[index, ]) %*% Rinv %*% x[index, ]; */
        xi_new.gemm("N", "N", this->tau->get_entry_vec(i), res_i, Rinvxi, 1.0);  

        /* update position for res_i */
        pos_x += Ji * (this->p_var); 
        pos_res += Ji * (this->r_resp); 
    }

    Hmat_new.chol();
    xi_new.solve_chol_right(Hmat_new, 1.0);

    this->Sigma_inv->chol(); 
    rnorm_mat_inv_chol(*(this->beta), xi_new, *(this->Sigma_inv), Hmat_new);
}

/**********************************************************************
 * Psi.new = hyper.pars$Psi + (iSample$beta - hyper.pars$xi) %*% 
 *                  hyper.pars$Hmat %*% 
 *                  t(iSample$beta - hyper.pars$xi); 
 * res = sweep(y, 2, iSample$alpha, "-") - x %*% t(iSample$beta); 
 * for(i in 1:n_subject)
 * {
 *      index = which(subject == i); 
 *      Rinv = cor.inv(length(index), iSample$rho, cor.type);
 *      Psi.new = Psi.new + t(res[index, ]) %*% Rinv %*% res[index, ];  
 * }
 *
 * Sigma.inv = drop(rWishart(1,  
 *                  df = hyper.pars$df + p + sumJ, 
 *                  Sigma = solve(Psi.new)));
 * iSample$Sigma = solve(Sigma.inv); 
 **********************************************************************/

void CBrmlmRM::sample_Sigma_inv()
{
    /* bxi = iSample$beta - hyper.pars$xi */
    Cmat bxi(this->r_resp, this->p_var); 
    bxi.copy(*(this->beta));
    bxi.axpy(-1.0, *(this->hyper_beta_mean));  

    /* Psi_new = hyper.pars$Psi + bxi %*% hyper.pars$Hmat %*% t(bxi) */
    Cmat Psi_new(this->r_resp, this->r_resp);
    Psi_new.copy(*(this->hyper_Sigma_scale));
    Psi_new.ABAt(1.0, bxi, *(this->hyper_beta_col_inv), 1.0); 

    for(int i = 0, pos = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        /* Psi.new = Psi.new + t(res[index, ]) %*% Rinv %*% res[index, ]; */
        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos); 
        Psi_new.ABAt(this->tau->get_entry_vec(i), res_i, Rinv, 1.0); 

        /* update position for res_i */
        pos += Ji * (this->r_resp); 
    }

    double df = this->hyper_Sigma_df + (double)(this->n_obs) + (double)(this->p_var);
    rwishart_inv(*(this->Sigma_inv), df, Psi_new);  
} 

/**********************************************************************
 * compute posterior means  
 **********************************************************************/

void CBrmlmRM::compute_posterior_mean(int length, double *pt)
{
    if((this->length_saved_pars) != length)
        error("CBrmlmRM::compute_posterior_mean(): wrong size of pt.\n"); 

    int length_rab = 1 + 1 + this->tau->get_length() + this->alpha->get_length() + this->beta->get_length();
    Cmat alpha_beta_r(length_rab, 1, pt);
    Cmat alpha_beta_r_samples(length_rab, this->count_output_mcmc, this->samples, this->length_saved_pars); 
    alpha_beta_r.rowMeans(alpha_beta_r_samples);
    
    Cmat Sigma_mean(this->r_resp, this->r_resp, pt + length_rab); 
    Sigma_mean.set_zero(); 

    double sc = 1.0 / (double)(this->count_output_mcmc); 
    Cmat iSigma(this->r_resp, this->r_resp);

    for(int i = 0; i < (this->count_output_mcmc); i++)
    {
        iSigma.copy((this->samples) + i * (this->length_saved_pars) + length_rab); 
        iSigma.inv(); 
        Sigma_mean.axpy(sc, iSigma); 
    }
}

/**********************************************************************
 * Markov Chain Monte Carlo 
 **********************************************************************/

void CBrmlmRM::mcmc_initialize()
{
    if(this->assume_normal)
    {
        this->tau->set_const(1.0); 
        this->nu = 1000; 
    }

    if(this->ctype == Corr_Type::iid)
    {
        this->rho = 0.0; 
    }
    
    this->count_mcmc = 0;
    this->count_output_mcmc = 0; 
    this->rho_count = 0; 
    this->nu_count = 0; 
} 

void CBrmlmRM::mcmc_one_pass()
{
    /* reset values after burn-in period */
    if((this->count_mcmc) == (this->burn_in_mcmc))
    {
        this->rho_count = 0; 
        this->nu_count = 0; 
    }

    this->sample_alpha(); 
    this->sample_beta(); 
    this->compute_residual(); 
    this->sample_Sigma_inv();  
    
    this->compute_deltaRM(); 

    if(this->ctype != Corr_Type::iid) 
        this->sample_rho(); 

    /* 0 = t-distribution, 1 = normal */
    if(this->assume_normal == 0)
    {
        this->sample_tauRM(*(this->Jvec), *(this->deltaRM), this->r_resp); 
        this->sample_nu(); 
    }
        
    this->pars[0] = this->rho; 
    this->pars[1] = this->nu; 
} 

/* count_mcmc, count_output_mcmc, rho_count, nu_count */

void CBrmlmRM::get_all_count(int count_length, int *count_pt)
{
    if(count_length < 4)
        error("CBrmlmRM::get_all_count(): incorrect length.\n"); 

    count_pt[0] = this->count_mcmc;
    count_pt[1] = this->count_output_mcmc; 
    count_pt[2] = this->rho_count; 
    count_pt[3] = this->nu_count;     
} 

/**********************************************************************
 * compute log-likelihood corresponding to each draw from posterior distribution
 * logf has count_output_mcmc rows and m_sub columns
 **********************************************************************/

void CBrmlmRM::compute_loglik_draws(Cmat &logf) 
{
    if(logf.get_ncol() != (this->m_sub))
        error("CBrmlmRM::compute_loglik_draws(): logf has incompatible number of columns.\n");

    /* compute log-density for each subject at each posterior draw */
    for(int s = 0; s < logf.get_nrow(); s++)
    {
        /* set parameters, avoid the first one */
        this->set_ini_pars(this->length_pars, 
                            this->samples + (this->length_saved_pars) * s); 

        /* compute beta, Sigma_inv, res, and deltaRM*/
        this->compute_residual(); 
        this->compute_deltaRM(); 

        double logdetS = - (this->Sigma_inv->logdet_chol()); 
        
        for(int i = 0; i < (this->m_sub); i++)
        {
            int Ji = this->Jvec->get_entry_vec(i); 

            Ccormat cor(Ji, this->ctype, this->rho); 
            double logdetR = cor.logdet(); 
            
            double logden = 0.0; 
            if(this->assume_normal)
            {
                logden = log_dMnorm0(this->r_resp, Ji, 
                            this->deltaRM->get_entry_vec(i), logdetS, logdetR); 
            }
            else 
            {
                logden = log_dMT0(this->r_resp, Ji, this->nu, 
                            this->deltaRM->get_entry_vec(i), logdetS, logdetR); 
            }

            logf.set_entry(s, i, logden); 
        }
    }
}

/**********************************************************************
 * THE END
 **********************************************************************/
