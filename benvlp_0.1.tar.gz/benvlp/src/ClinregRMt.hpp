/**********************************************************************
 * Class for linear regression with repeated measures  
 * t-distribution 
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-28 
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CLINREGRMT__HPP__ 
#define __ZP__CLINREGRMT__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "ClinregRM.hpp"
#include "CBtGamma.hpp"

class ClinregRMt : public ClinregRM, public CBtGamma {
    protected: 
        
    public: 
        ClinregRMt(); 
        ClinregRMt(Cmat *x_pt, Cmat *y_pt, bool intercept, Cimat *Jvec_pt, Corr_Type cp); 
        ~ClinregRMt(); 

        /**************************************************************
         * get or set class members     
         **************************************************************/

        /**************************************************************
         * more member functions     
         **************************************************************/

        void sample_alpha(); 
        void sample_rho();
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
