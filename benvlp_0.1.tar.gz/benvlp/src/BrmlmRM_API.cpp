/**********************************************************************
 * Bayesian inference for multivariate linear regression  
 * with repeated measures, t-distribution 
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-27
 **********************************************************************/

#include <R.h>
#include "CBrmlmRM.hpp"

extern "C" {
void BrmlmRM_API(
    const int *dims,               /* (n, r, p, msub), length = 4 */
    double *data,                  /* (y, x), length = r * n + p * n */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    const int *control,            /* (burn_in, size, thinning, info, assume_normal), length = 5 */
    int *length_ini,               /* length of ini = 1 + 1 + nsub + r + r * p + r * r */
    double *ini,                   /* (rho, nu, tau, alpha, beta, Sigma_inv) */
    int *length_hyper,             /* length of hyperparameters, = r * p + p * p + 1 + r * r + 2 */
    double *hyperpars,             /* (beta_mean, beta_col_inv, Sigma_df, Sigma_scale, nu_shape, nu_rate) */
    int *length_tuning,            /* length of tuning parameters, = 2 */
    double *tuning,                /* rho_delta, nu_delta */
    int *max_samples,              /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    const int *length_pmean,       /* length of pmean = 1 + 1 + msub + r + r * p + r * r */
    double *pmean,                 /* posterior mean (rho, nu, tau, alpha, beta, Sigma) */
    int *count)                    /* length = 4, count number of sample generated, number of saved samples, rho_count, nu_count */  
{
    const int n = dims[0];         /* number of observations */
    const int r = dims[1];         /* number of respones */
    const int p = dims[2];         /* number of predictors */
    const int msub = dims[3];      /* number of subjects */

    int pars_length = 1 + 1 + msub + r + r * p + r * r;

    const int burn_in = control[0];
    const int size = control[1];
    const int thinning = control[2];
    const int info = control[3];
    const bool assume_normal = control[4]; 

    /******************************************************************
     * define the problem to be solved  
     ******************************************************************/

    int type_int = int_data[0];
    Corr_Type ctype; 
    if(type_int == 0) ctype = Corr_Type::iid;
    else if(type_int == 1) ctype = Corr_Type::cs;
    else if (type_int == 2) ctype = Corr_Type::ar1; 
    else error("unsupported corelation type.\n"); 
 
    Cmat ymat(r, n, data); 
    Cmat xmat(p, n, data + r * n); 
    Cimat Jmat(msub, 1, int_data + 1); 
    CBrmlmRM prob(&xmat, &ymat, &Jmat, ctype, assume_normal,
                burn_in, size, thinning, info, pars_length);

    /******************************************************************
     * set the hyper-parameters 
     ******************************************************************/

    prob.set_hyperpars(*length_hyper, hyperpars); 
    prob.set_tuning(*length_tuning, tuning); 

    /******************************************************************
     * set the initial sample 
     ******************************************************************/

    prob.set_ini_pars(*length_ini, ini); 
    
    /******************************************************************
     * set the output space 
     ******************************************************************/
    
    prob.set_output_space(*max_samples, pars_length, saved_samples); 

    /******************************************************************
     * start sampling from posterior
     ******************************************************************/

    // std::ofstream file("BrmlmRM_problem.txt", std::ios::app);
    // prob.write2stream(file);
    // file.close(); 

    prob.mcmc_run(); 

    /******************************************************************
     * output counts 
     ******************************************************************/

    prob.compute_posterior_mean(pars_length, pmean);

    prob.get_all_count(4, count);
    /* count_mcmc, count_mcmc_saved, rho_count, nu_count */  
}
}

/**********************************************************************
 * THE END
 **********************************************************************/
