/**********************************************************************
 * Class for linear regression with repeated measures  
 * t-distribution 
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-28  
 **********************************************************************/

#include <R.h> 
#include "ClinregRMt.hpp"
#undef beta 

/**********************************************************************
 * variables defined in Creg: (5)
 *     Cmat *x;                     predictor - p-by-n matrix 
 *     Cmat *y;                     response - r-by-n matrix 
 *     int n_obs;                   number of observations 
 *     int p_var;                   number of predictors 
 *     int r_resp;                  number of responses 
 *
 * variables defined in Clinreg: (4)  
 *     bool has_intercept;          true = with intercept, false = no intercept 
 *     Cmat *alpha;                 intercept - r-by-1 matrix 
 *     Cmat *beta;                  slope - r-by-p matrix 
 *     Cmat *res;                   residual - r-by-n matrix 
 * 
 * variables defined in ClinregRM: (9)
 *     int m_sub;                   number of subjects 
 *     int Jmax;                    max(Jvec) 
 *     Cimat *Jvec;                 number of observations for each subject, length = n_sub 
 *     Corr_Type ctype;             correlation structure 
 *     double rho;                  parameter in correlation 
 *     Cmat *Sigma_inv;             r-by-r matrix 
 *     Cmat *deltaRM;               msub-by-1 matrix 
 *     double pro_rho_delta;        scalar - tuning parameter 
 *     int rho_count;               count the number of accepted rho 
 **********************************************************************/

ClinregRMt::ClinregRMt()
{
}
        
ClinregRMt::ClinregRMt(Cmat *x_pt, Cmat *y_pt, bool intercept, Cimat *Jvec_pt, Corr_Type cp)
    : ClinregRM(x_pt, y_pt, intercept, Jvec_pt, cp), 
      CBtGamma(Jvec_pt->get_vec_length())
{
}  

/**********************************************************************
 * destructor 
 **********************************************************************/

ClinregRMt::~ClinregRMt()
{
}

/**********************************************************************
 * sample rho 
 *
    rho.loglik.old = (-0.5 * sum(iSample$tau * iSample$Delta) 
                      -0.5 * prob$r * sum(tenvlp2.compute.R.logdet(prob$Jvec, iSample$rho, prob$cor.type))); 

    rho.new = runif(1, iSample$rho - pro.pars$rho.delta, iSample$rho + pro.pars$rho.delta);
    if(rho.new < 0) rho.new = -rho.new; 
    if(rho.new > 0) rho.new = 2 - rho.new; 

    iSample.new = iSample; 
    iSample.new$rho = rho.new; 
    iSample.new$Delta = tenvlp2.compute.Delta(prob, iSample.new);  
    rho.loglik.new = (-0.5 * sum(iSample.new$tau * iSample.new$Delta)
                      -0.5 * prob$r * sum(tenvlp2.compute.R.logdet(prob$Jvec, iSample.new$rho, prob$cor.type)));

    rho.logratio = rho.loglik.new - rho.loglik.old; 
    if(log(runif(1)) < rho.logratio) 
    {
        iSample = iSample.new; 
        iSample$rho.count = iSample$rho.count + 1; 
    }
 **********************************************************************/

void ClinregRMt::sample_rho()
{
    /* save current value of deltaRM and rho */
    Cmat deltaRM_cur(this->m_sub, 1);
    deltaRM_cur.copy(*(this->deltaRM)); 
    double rho_cur = this->rho; 

    double loglik_old = this->compute_loglik_rho(this->tau->dot(*(this->deltaRM))); 

    /* rho.new = iSample$rho + runif(1, -1, 1) * pro.pars$rho.delta;  */
    double rho_new = runif(this->rho - this->pro_rho_delta, 
                           this->rho + this->pro_rho_delta); 
    if(rho_new > 1.0) rho_new = 2.0 - rho_new; 
    if(rho_new < 0.0) rho_new = -rho_new;  

    this->rho = rho_new; 
    this->compute_deltaRM(); 

    double loglik_new = this->compute_loglik_rho(this->tau->dot(*(this->deltaRM))); 

    if(log(unif_rand()) < (loglik_new - loglik_old))
    {
        /* acccept proposed rho */
        (this->rho_count) ++; 
    }
    else 
    {
        /* reject proposed rho */
        this->rho = rho_cur; 
        this->deltaRM->copy(deltaRM_cur); 
    }
}

/**********************************************************************
 * sample alpha 
 *
    sc = 0.0; 
    mu.alpha = numeric(prob$r); 
    res.alpha = prob$y - prob$x %*% t(iSample$beta); 
    for(i in 1:prob$nsubject)
    {
        R.inv = cor.inv(prob$Jvec[i], iSample$rho, prob$cor.type); 
        sc = sc + sum(R.inv) * iSample$tau[i];
        mu.alpha = mu.alpha + iSample$tau[i] * rowSums(t(res.alpha[prob$subject == i, , drop = FALSE]) %*% R.inv);
    }

    iSample$alpha = MASS::mvrnorm(1, 
                    mu = mu.alpha / sc, 
                    Sigma = solve(iSample$Sigma.e.inv) / sc);
 **********************************************************************/
        
void ClinregRMt::sample_alpha()
{
    /* compute res = y - b * x */
    this->res->copy(*(this->y)); 
    this->res->gemm("N", "N", -1.0, *(this->beta), *(this->x), 1.0); 

    double sc = 0.0; 
    Cmat mu(this->r_resp, 1);
    mu.set_zero(); 

    Cmat vec(this->r_resp, 1);

    for(int i = 0, pos_res = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        sc += this->tau->get_entry_vec(i) * Rinv.sum(); 

        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos_res); 
        Cmat mat(this->r_resp, Ji);
        mat.gemm("N", "N", 1.0, res_i, Rinv, 0.0);

        vec.rowSums(mat); 
        mu.axpy(this->tau->get_entry_vec(i), vec); 

        /* update position for res_i */
        pos_res += Ji * (this->r_resp); 
    }

    mu.scale(1.0 / sc); 

    Cmat Sinv(this->r_resp, this->r_resp);
    Sinv.copy(*(this->Sigma_inv));
    Sinv.scale(sc); 

    rnorm_vec_inv(*(this->alpha), mu, Sinv);
}

/**********************************************************************
 * THE END
 **********************************************************************/
