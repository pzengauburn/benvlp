/**********************************************************************
 * Class for Bayesian inference for multivariate linear regression  
 * with repeated measures and envelope structure, t-distribution  
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-24  
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CRBMLMRMENVLP__HPP__ 
#define __ZP__CRBMLMRMENVLP__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "ClinregRMt.hpp"
#include "Cenvlp.hpp"
#include "Cmcmc.hpp"
#include "CBtGamma.hpp"

class CBrmlmRM_envlp : public ClinregRMt, public Cmcmc, public Cenvlp {
    protected: 
        Cmat *eta;                   /* u-by-p matrix */
        Cmat *Omega_inv;             /* u-by-u matrix */
        Cmat *Omega0_inv;            /* (r-u)-by-(r-u) matrix */

        bool assume_normal;          /* 1 = normal, 0 = t-distribution */

        /* hyper-parameters in prior distributions */
        Cmat *hyper_eta_mean;        /* r-by-p matrix */
        Cmat *hyper_eta_col_inv;     /* p-by-p matrix */
        double hyper_Omega_df;       /* scalar */
        Cmat *hyper_Omega_scale;     /* u-by-u matrix */
        double hyper_Omega0_df;      /* scalar */
        Cmat *hyper_Omega0_scale;    /* (r-u)-by-(r-u) matrix */

        Cmat *hyper_eta_mean_inv;    /* r-by-p matrix = eta_mean %*% eta_col_inv */

        /* hyper-parameters in proposal distributions */

    public: 
        CBrmlmRM_envlp(); 
        CBrmlmRM_envlp(Cmat *x_pt, Cmat *y_pt, int u, Cimat *Jvec_pt, Corr_Type cp,
                bool normal, int burn_in, int size, int thinning, int info, int length, 
                Cmat *Umat = nullptr); 
        ~CBrmlmRM_envlp(); 

        /* set initial values */
        void set_ini_pars(int length, double *pt);   
        
        /* set hyper-parameters in prior distributions */
        void set_hyperpars(int length, double *pt);

        /* set hyper-parameters in proposal distributions */
        void set_tuning(int length, double *pt); 

        /* write information to a file */
        void write2stream(std::ostream &stream);             

        /* sample from posterior distributions */     
        void sample_eta(); 
        void sample_Omegas(); 
        void sample_Amat(); 

        double compute_loglik();     
        double compute_loglik_Amat(); 
        void compute_posterior_mean(int length, double *pt);

        /* compute log-likelihood corresponding to each draw from posterior distribution */
        /* logf has count_output_mcmc rows and m_sub columns */
        void compute_loglik_draws(Cmat &logf);  
        /* compute WAIC */
        double compute_WAIC(); 

        /* Markov Chain Monte Carlo */
        void mcmc_initialize(); 
        void mcmc_one_pass(); 

        /* count_mcmc, count_output_mcmc, rho_count, A_count */
        void get_all_count(int count_length, int *count_pt); 
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
