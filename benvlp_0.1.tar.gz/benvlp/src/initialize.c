/**************************************************************************
 * package initialization 
 **************************************************************************/

#include <R.h>
#include <Rmath.h>

#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Visibility.h>

#include "APIs.h" 
#include "log-density.h" 

static
R_NativePrimitiveArgType reg_API_type[] = {
    INTSXP,     /* dims,            1 */
    REALSXP,    /* data,            2 */
    INTSXP,     /* control,         3 */
    INTSXP,     /* length_ini,      4 */
    REALSXP,    /* ini,             5 */
    INTSXP,     /* length_hyper,    6 */
    REALSXP,    /* hyperpars,       7 */
    INTSXP,     /* max_samples,     8 */
    REALSXP,    /* saved_samples,   9 */
    INTSXP,     /* length_pmean,   10 */
    REALSXP,    /* pmean,          11 */
    INTSXP      /* count           12 */  
}; 

static
R_NativePrimitiveArgType reg_API_type2[] = {
    INTSXP,     /*  dims,            1 */
    REALSXP,    /*  data,            2 */
    INTSXP,     /*  control,         3 */
    INTSXP,     /*  length_ini,      4 */
    REALSXP,    /*  ini,             5 */
    INTSXP,     /*  length_hyper,    6 */
    REALSXP,    /*  hyperpars,       7 */
    INTSXP,     /*  length_tuning,   8 */
    REALSXP,    /*  tuning,          9 */
    INTSXP,     /*  max_samples,    10 */
    REALSXP,    /*  saved_samples,  11 */
    INTSXP,     /*  length_pmean,   12 */
    REALSXP,    /*  pmean,          13 */
    INTSXP      /*  count           14 */      
};

static
R_NativePrimitiveArgType regRM_API_type[] = {
    INTSXP,     /*  dims,             1 */
    REALSXP,    /*  data,             2 */
    INTSXP,     /*  int_data,         3 */
    INTSXP,     /*  control,          4 */
    INTSXP,     /*  length_ini,       5 */
    REALSXP,    /*  ini,              6 */
    INTSXP,     /*  length_hyper,     7 */
    REALSXP,    /*  hyperpars,        8 */
    INTSXP,     /*  length_tuning,    9 */
    REALSXP,    /*  tuning,          10 */
    INTSXP,     /*  max_samples,     11 */
    REALSXP,    /*  saved_samples,   12 */
    INTSXP,     /*  length_pmean,    13 */
    REALSXP,    /*  pmean,           14 */
    INTSXP      /*  count            15 */  
}; 

static
R_NativePrimitiveArgType log_dt_mat_API_type[] = {
    INTSXP,     /* const int *m,          1 */
    INTSXP,     /* const int *n,          2 */
    REALSXP,    /* const double *x,       3 */ 
    REALSXP,    /* const double *nu,      4 */ 
    REALSXP,    /* const double *mu,      5 */ 
    REALSXP,    /* const double *Sigma1,  6 */ 
    REALSXP,    /* const double *Sigma2,  7 */
    REALSXP     /* double *ans            8 */    
};

static
R_NativePrimitiveArgType log_dnorm_mat_API_type[] = {
    INTSXP,     /* const int *m,          1 */
    INTSXP,     /* const int *n,          2 */
    REALSXP,    /* const double *x,       3 */ 
    REALSXP,    /* const double *mu,      4 */ 
    REALSXP,    /* const double *Sigma1,  5 */ 
    REALSXP,    /* const double *Sigma2,  6 */
    REALSXP     /* double *ans            7 */    
};

static
R_NativePrimitiveArgType logf_type1[] = {
    INTSXP,     /* dims,              1  */
    REALSXP,    /* data,              2  */
    INTSXP,     /* int_data,          3  */
    INTSXP,     /* control,           4  */
    INTSXP,     /* length_samples,    5  */
    REALSXP,    /* saved_samples,     6  */
    REALSXP     /* logf               7  */  
};

static
R_NativePrimitiveArgType logf_type2[] = {
    INTSXP,     /* dims,              1  */
    REALSXP,    /* data,              2  */
    INTSXP,     /* int_data / control 3  */
    INTSXP,     /* length_samples,    4  */
    REALSXP,    /* saved_samples,     5  */
    REALSXP     /* logf               6  */  
};

R_CMethodDef cMethods[] = {
    // {"Bmlm_API",           (DL_FUNC) &Bmlm_API,           12, reg_API_type},
    // {"Bmlm_envlp_API",     (DL_FUNC) &Bmlm_envlp_API,     14, reg_API_type2},
    // {"BmlmRM_API",         (DL_FUNC) &BmlmRM_API,         15, regRM_API_type},
    {"BrmlmRM_API",        (DL_FUNC) &BrmlmRM_API,        15, regRM_API_type},
    {"BmlmRM_envlp_API",   (DL_FUNC) &BmlmRM_envlp_API,   15, regRM_API_type},
    {"BrmlmRM_envlp_API",  (DL_FUNC) &BrmlmRM_envlp_API,  15, regRM_API_type},
    // {"BrmlmRM_envlp0_API", (DL_FUNC) &BrmlmRM_envlp0_API, 14, reg_API_type2},
    {"log_dt_mat_API",     (DL_FUNC) &log_dt_mat_API,      8, log_dt_mat_API_type},
    {"log_dnorm_mat_API",  (DL_FUNC) &log_dnorm_mat_API,   7, log_dnorm_mat_API_type},

    // {"BrmlmRM_envlp_det_API",  (DL_FUNC) &BrmlmRM_envlp_det_API,  15, regRM_API_type},
    // {"BrmlmRM_envlp_det0_API", (DL_FUNC) &BrmlmRM_envlp_det0_API, 14, reg_API_type2},

    // {"BrmlmRM_envlp_norm0_API", (DL_FUNC) &BrmlmRM_envlp_norm0_API, 14, reg_API_type2},

    // {"Brmlm_envlp_API",     (DL_FUNC) &Brmlm_envlp_API,     14, reg_API_type2},
 
    {"BrmlmRM_loglik",        (DL_FUNC) &BrmlmRM_loglik,        7, logf_type1},
    {"BmlmRM_envlp_loglik",   (DL_FUNC) &BmlmRM_envlp_loglik,   6, logf_type2},
    {"BrmlmRM_envlp_loglik",  (DL_FUNC) &BrmlmRM_envlp_loglik,  7, logf_type1},
    // {"BrmlmRM_envlp0_loglik", (DL_FUNC) &BrmlmRM_envlp0_loglik, 6, logf_type2},

    // {"BrmlmRM2_envlp_API",  (DL_FUNC) &BrmlmRM2_envlp_API,  15, regRM_API_type},

    {NULL, NULL, 0}
};

void attribute_visible
R_init_benvlp(DllInfo *info)
{
    R_registerRoutines(info, cMethods, NULL, NULL, NULL);
    R_useDynamicSymbols(info, FALSE);
}

/**************************************************************************
 * THE END
 **************************************************************************/
