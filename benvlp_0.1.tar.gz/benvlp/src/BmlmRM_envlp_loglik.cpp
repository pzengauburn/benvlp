/**********************************************************************
 * Bayesian inference for multivariate linear regression  
 * with repeated measures and envelope structure
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-22 
 **********************************************************************/

#include <R.h>
#include "CBmlmRM_envlp.hpp"

extern "C" {
void BmlmRM_envlp_loglik(
    const int *dims,               /* (n, r, p, msub, u), length = 5 */
    double *data,                  /* (y, x, Umat), length = r * n + p * n + r * r */
    int *int_data,                 /* (type, Jvec), length = 1 + msub, 0 = IID, 1 = CS, 2 = AR1 */
    int *length_samples,           /* maximum number of samples saved */
    double *saved_samples,         /* saved samples, length = max_samples * length_saved_pars */
    double *logf)                  /* length_sample by msub matrix */  
{
    const int n = dims[0];         /* number of observations */
    const int r = dims[1];         /* number of respones */
    const int p = dims[2];         /* number of predictors */
    const int msub = dims[3];      /* number of subjects */
    const int u = dims[4];         /* dim of envelope */

    int pars_length = 1 + r + u * p + (r-u) * u + u * u + (r-u) * (r-u);

    /******************************************************************
     * define the problem to be solved  
     ******************************************************************/

    int type_int = int_data[0];  
    Corr_Type ctype; 
    if(type_int == 0) ctype = Corr_Type::iid;
    else if(type_int == 1) ctype = Corr_Type::cs;
    else if (type_int == 2) ctype = Corr_Type::ar1; 
    else error("unsupported corelation type.\n"); 

    Cmat ymat(r, n, data); 
    Cmat xmat(p, n, data + r * n); 
    
    Cmat Umatrix(r, r, data + r * n + p * n); 
    Cmat *Umat_pt = nullptr;  
    if(! Umatrix.is_identity())  Umat_pt = &Umatrix; 

    Cimat Jmat(msub, 1, int_data + 1); 
    CBmlmRM_envlp prob(&xmat, &ymat, u, &Jmat, ctype, 0, 0, 0, 0, pars_length, Umat_pt);
    
    /******************************************************************
     * set the output space 
     ******************************************************************/
    
    prob.set_output_space(*length_samples, pars_length, saved_samples); 

    /******************************************************************
     * compute log likelihood  
     ******************************************************************/

    Cmat logf_mat(*length_samples, msub, logf); 
    prob.compute_loglik_draws(logf_mat);
}
}

/**********************************************************************
 * THE END
 **********************************************************************/
