/**********************************************************************
 * Class for Bayesian inference for multivariate linear regression  
 * with repeated measures and envelope structure 
 * Peng Zeng @ Auburn University  
 * updated: 2025-04-19 
 * updated: 2025-10-22  
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CBMLMRMENVLP__HPP__ 
#define __ZP__CBMLMRMENVLP__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "ClinregRM.hpp"
#include "Cmcmc.hpp"
#include "Cenvlp.hpp"

class CBmlmRM_envlp : public ClinregRM, public Cmcmc, public Cenvlp {
    protected: 
        Cmat *eta;                   /* u-by-p matrix */
        Cmat *Omega_inv;             /* u-by-u matrix */
        Cmat *Omega0_inv;            /* (r-u)-by-(r-u) matrix */

        /* hyper-parameters in prior distributions */
        Cmat *hyper_eta_mean;        /* r-by-p matrix */
        Cmat *hyper_eta_col_inv;     /* p-by-p matrix */
        double hyper_Omega_df;       /* scalar */
        Cmat *hyper_Omega_scale;     /* u-by-u matrix */
        double hyper_Omega0_df;      /* scalar */
        Cmat *hyper_Omega0_scale;    /* (r-u)-by-(r-u) matrix */

        /* hyper-parameters in prior distributions */

    public: 
        CBmlmRM_envlp(); 
        CBmlmRM_envlp(Cmat *x_pt, Cmat *y_pt, int u, Cimat *Jvec_pt, Corr_Type cp,
                int burn_in, int size, int thinning, int info, int length, 
                Cmat *Umat = nullptr); 
        ~CBmlmRM_envlp(); 

        /* set initial values */
        void set_ini_pars(int length, double *pt);
        
        /* set hyper-parameters in prior distributions */
        void set_hyperpars(int length, double *pt);

        /* set hyper-parameters in proposal distributions */
        void set_tuning(int length, double *pt); 

        /* write information to a file */
        void write2stream(std::ostream &stream);             

        /* sample from posterior distributions */        
        void sample_eta(); 
        void sample_Omegas(); 
        void sample_Amat(); 

        double compute_loglik_Amat(); 
        void compute_posterior_mean(int length, double *pt);

        /* compute log-likelihood corresponding to each draw from posterior distribution */
        /* logf has count_output_mcmc rows and m_sub columns */
        void compute_loglik_draws(Cmat &logf);  

        /* Markov Chain Monte Carlo */
        void mcmc_initialize(); 
        void mcmc_one_pass(); 

        /* count_mcmc, count_output_mcmc, rho_count, A_count */
        void get_all_count(int count_length, int *count_pt); 
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
