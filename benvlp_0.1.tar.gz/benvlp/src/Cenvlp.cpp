/**********************************************************************
 * Class for envelope model   
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 * updated: 2024-04-14 (propose_Amat)
 **********************************************************************/

#include <R.h> 

#include "Cenvlp.hpp"

/**********************************************************************
 * variables defined in Cenvlp: (8)
 *     int u_dim;                   dimension u 
 *     Cmat *A;                     (r-u)-by-u matrix 
 *     Cmat *U;                     r-by-r matrix 
 *     Cmat *Gamma;                 r-by-u matrix 
 *     Cmat *Gamma0;                r-by-(r-u) matrix 
 *     Cmat *hyper_Amat_Mmat;       r-by-r matrix  --  hyperparameter in prior  
 *     double pro_Amat_sigma2;      scalar -- hyperparameter in proposal distribution 
 *     int A_count;                 count the number of accepted Amat 
 **********************************************************************/

Cenvlp::Cenvlp()
{
    this->u_dim = 1; 
    this->A = nullptr;
    this->U = nullptr;
    this->Gamma = nullptr; 
    this->Gamma0 = nullptr; 

    this->hyper_Amat_Mmat = nullptr;
    this->pro_Amat_sigma2 = 0.0; 
    this->A_count = 0; 
} 

Cenvlp::Cenvlp(int r, int u, Cmat *Umat) 
{
    if(Umat != nullptr)
    {
        if((Umat->get_nrow() != r) || (Umat->get_ncol() != r))
            error("Cenvlp::Cenvlp(): incompatible dimensions.\n"); 
    }     

    this->u_dim = u;              
    this->A = new Cmat(r-u, u);                
    this->U = Umat;        
    this->Gamma = new Cmat(r, u);          
    this->Gamma0 = new Cmat(r, r-u);  

    this->hyper_Amat_Mmat = new Cmat(r, r);
    this->pro_Amat_sigma2 = 0.0; 
    this->A_count = 0; 
}

/**********************************************************************
 * destructor 
 **********************************************************************/

Cenvlp::~Cenvlp()
{
    delete this->A;
    delete this->Gamma; 
    delete this->Gamma0; 
    delete this->hyper_Amat_Mmat; 
}

/**********************************************************************
 * compute A corresponding to the column space of Z 
 * Z is destroyed on exit 
 * denote U = (U1, U2)
 *    1. compute G as the Q-matrix of the QR-factorizatin of Z  
 *    2. compute A = (U2' G)(U1' G)^{-1} 
 *
 * equivalent R codes: 
 * Z2Amat = function(Zmat, Umat)
 * {
 *    u = ncol(Zmat)
 *    Q = qr.Q(qr(Zmat))
 *    (t(Umat[, -(1:u)]) %*% Q) %*% solve(t(Umat[, 1:u]) %*% Q) 
 * }
 **********************************************************************/

void Cenvlp::compute_Amat(Cmat &Z)   
{
    const int r = Z.get_nrow(); 
    const int u = Z.get_ncol(); 
    const int ru = r - u; 

    if((this->A->get_nrow() != ru) || (this->A->get_ncol() != u))
        error("Cenvlp::compute_Amat(): incompatible dimensions.\n"); 

    Cmat tau(u, 1); 
    Z.qr(tau);                              /* find the QR-factorization of Z */

    Cmat UT(r, r);                          /* UT = U' */
    Cmat UTG(r, u, UT.get_value_pt());     /* UTG = U' * G */
    if(this->U == nullptr) 
    {
        /* When U = identity, UTG = G the Q-matrix of QR-factorization */
        UTG.copy(Z); 
        UTG.qr_Q(tau);  
    }
    else 
    {
        /* When U <> identity, UTG = U' * G */
        UT.copy_T((*this->U));              /* copy UT as the transpose of U */
        UT.qr_Q_mul("R", "N", Z, tau);      /* UT = U' * Q */
    } 
    /* the first u columns of UT becomes U' * G */

    Cmat U1G(u, u, UT.get_value_pt(), r);          /* U1G = U1' * G */ 
    Cmat U2G(r - u, u, UT.get_value_pt() + u, r);  /* U2G = U2' * G */

    U1G.inv();                                     /* U1G = inv(U1G) */
    this->A->gemm("N", "N", 1.0, U2G, U1G, 0.0);   /* compute U2G * inv(U1G) */
}

/**********************************************************************
 * compute Gamma and Gamma0 from A 
 * Gamma =  (U1 + U2 * A) * (I_u + A'A)^{-1/2}
 * Gamma0 = (-U1 * A' + U2) * (I_{r-u} + AA')^{-1/2}
 * 
 *    1. apply svd to A to get u, v, d, make sure to use svda() 
 *    2. update d as (1 + d^2)^{-1/2}
 *    3. top block of Gamma is v * d * vt = (I_u + A'A)^{-1/2}
 *    4. bottom block of Gamma is A * (top block) = A * (I_u + A'A)^{-1/2}
 *    5. bottom block of Gamma0 is u * d * ut = (I_{r-u} + AA')^{-1/2}
 *    6. top block of Gamma0 is -A' * (bottom block) = -A' * (I_{r-u} + AA')^{-1/2}
 *    7. update Gamma by Gamma := U * Gamma 
 *    8. update Gamma0 by Gamma0 := U * Gamma0 
 *
 * equivalent R code: 
 * A2Gammax = function(Amat, Umat) 
 * {
 *    u = ncol(Amat)
 *    Ainfo = eigen(t(Amat) %*% Amat)
 *    Bmat = Ainfo$vectors %*% 
 *                diag(1/sqrt(Ainfo$values + 1), nrow = u, ncol = u) %*%
 *                t(Ainfo$vectors)
 *    (Umat[, 1:u] + Umat[, -(1:u)] %*% Amat) %*% Bmat
 * }
 * 
 * A2Gamma0x = function(Amat, Umat)
 * {
 *    ru = nrow(Amat)
 *    u = ncol(Amat)
 *    Ainfo = eigen(Amat %*% t(Amat))
 *    Bmat = Ainfo$vectors %*% 
 *                diag(1/sqrt(Ainfo$values + 1), nrow = ru, ncol = ru) %*%
 *                t(Ainfo$vectors)
 *    (-Umat[, 1:u] %*% t(Amat) + Umat[, -(1:u)]) %*% Bmat
 * }
 **********************************************************************/

void Cenvlp::compute_Gammas()
{
    const int ru = this->A->get_nrow(); 
    const int u  = this->A->get_ncol(); 
    const int r  = ru + u; 
    const int s  = (ru < u) ? ru : u;     /* mx = min(nrow, ncol) */
    const int mx = (ru > u) ? ru : u;     /* mx = max(nrow, ncol) */

    /* apply svd to A to get u, v, d */
    Cmat A_u(ru, ru); 
    Cmat A_d(mx, 1);                /* entries after rank(A) are 0 */
    Cmat A_vt(u, u); 
    this->A->svda(A_d, A_u, A_vt); 

    /* same as A_d, but 0 after s-th components are ignored */
    Cmat A_d_short(s, 1, A_d.get_value_pt()); 

    /* update d to be 1/sqrt(1 + d*d) */
    for(int i = 0; i < s; i++) 
        A_d.set_entry_vec(i, 1.0 / sqrt(1.0 + A_d.get_entry_vec(i) * A_d.get_entry_vec(i)));
    for(int i = s; i < mx; i++) 
        A_d.set_entry_vec(i, 1.0);

    this->Gamma->set_zero(); 

    /* top block of Gamma is v * d * vt = (I_u + A'A)^{-1/2} */
    Cmat Gamma_top(u, u, this->Gamma->get_value_pt(), r);
    if(ru > u) Gamma_top.syr_row("L", A_d_short, A_vt);  
    else Gamma_top.syr_row("L", A_d, A_vt); 
    Gamma_top.complete_tri_upper(); 

    /* bottom block of Gamma is A * (top block) = A * (I_u + A'A)^{-1/2} */
    Cmat Gamma_bottom(ru, u, this->Gamma->get_value_pt() + u, r);  
    Gamma_bottom.gemm("N", "N", 1.0, *(this->A), Gamma_top, 0.0); 

    this->Gamma0->set_zero(); 

    /* bottom block of Gamma0 is u * d * ut = (I_{r-u} + AA')^{-1/2} */
    Cmat Gamma0_bottom(ru, ru, this->Gamma0->get_value_pt() + u, r);
    if(ru > u) Gamma0_bottom.syr_col("L", A_d, A_u);  
    else Gamma0_bottom.syr_col("L", A_d_short, A_u); 
    Gamma0_bottom.complete_tri_upper(); 
    
    /* top block of Gamma0 is -A' * (bottom block) = -A' * (I_{r-u} + AA')^{-1/2} */
    Cmat Gamma0_top(u, ru, this->Gamma0->get_value_pt(), r);  
    Gamma0_top.gemm("T", "N", -1.0, *(this->A), Gamma0_bottom, 0.0); 

    if(this->U != nullptr)
    {
        Cmat tilGamma(r, u); 
        Cmat tilGamma0(r, r-u); 
        tilGamma.copy(*(this->Gamma)); 
        tilGamma0.copy(*(this->Gamma0)); 

        /* (Gamma, Gama0) =  U * (tilGamma, tilGamma0) */
        this->Gamma->gemm("N", "N", 1.0, *(this->U), tilGamma, 0.0); 
        this->Gamma0->gemm("N", "N", 1.0, *(this->U), tilGamma0, 0.0); 
    }
}

/* compute Sigma = Gamma * Omega * Gamma' + Gamma0 * Omega0 * Gamma0' */

void Cenvlp::Sigma_restore(Cmat &Sigma, Cmat &Omega, Cmat &Omega0)
{
    Sigma.ABAt(1.0, *(this->Gamma),  Omega,  0.0);
    Sigma.ABAt(1.0, *(this->Gamma0), Omega0, 1.0);   
}    

/* compute beta = Gamma * eta */

void Cenvlp::beta_restore(Cmat &beta, Cmat &eta)
{
    beta.gemm("N", "N", 1.0, *(this->Gamma), eta, 0.0); 
} 

/**********************************************************************
 * # M = sigma2 * I_r +  Gamma * Gamma'
 * Mmat = Gamma %*% t(Gamma); 
 * diag(Mmat) = diag(Mmat) + sigma2; 
 *
 * # simulate Z from matrix-variate normal(0, Mmat, I_u)
 * Zmat = t(chol(Mmat)) %*% matrix(rnorm(r * u), nrow = r, ncol = u); 
 * 
 * Z2Amat(Zmat, Umat); 
 **********************************************************************/

/* propose a new Amat */

void Cenvlp::propose_Amat()
{
    const int r = this->A->get_nrow() + this->u_dim; 

    /* Mmat = sigma2 * diag(rep(1, r)) + Gamma %*% t(Gamma); */
    Cmat Mmat(r, r); 
    Mmat.set_identity(this->pro_Amat_sigma2); 
    Mmat.syrk("L", "N", 1.0, *(this->Gamma), 1.0); 
    Mmat.chol(); 
    /* Mmat becomes chol(Mmat) */
 
    /* Zmat = t(chol(Mmat)) %*% matrix(rnorm(r * u), nrow = r, ncol = u); */
    Cmat Zmat(r, this->u_dim); 
    rnorm_std(Zmat);
    Zmat.trmm("L", "L", "N", "N", 1.0, Mmat); 
 
    this->compute_Amat(Zmat); 
}


/* propose a new Amat from multivariate normal distribution */
        
void Cenvlp::propose_Amat_normal() 
{
    for(int i = 0; i < (this->A->get_nrow()); i++)
    for(int j = 0; j < (this->A->get_ncol()); j++)
        this->A->inc_entry(i, j, (this->pro_Amat_sigma2) * norm_rand()); 

    /* updated in mcmc_initialize() */
    /* this->pro_Amat_sigma2 = sqrt(this->pro_Amat_sigma2); */
}

/**********************************************************************
 * THE END
 **********************************************************************/
