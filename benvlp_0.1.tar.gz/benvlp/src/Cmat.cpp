/**********************************************************************
 * Class for matrices and vectors 
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 * updated: 2024-11-29 (is_identity, copy_T, qr_Q_mul)
 * updated: 2025-04-12 (as_row, as_col, as_block, kron, value_pt_shift)
 * updated: 2025-04-12 (rowScale, colScale, colCenter)
 * updated: 2025-04-14 (sum, trace, as_diag)
 * updated: 2025-04-16 (Rversion, R_Calloc and R_Free)
 * updated: 2025-04-19 (as_reshape, copy_diag, as_diag)
 * updated: 2025-05-09 (inv_chol) 
 * updated: 2025-05-21 (prod, sumlog, entry_square, entry_sqrt, entry_reciprocal)
 * updated: 2025-05-22 (var2cor, cor2var, var2cor_inv)
 * updated: 2025-10-16 (inc_entry, inc_entry_vec, scale_entry, scale_entry_vec,
 *                      rowSums_w, rowMeans_w, colSums_w, colMeans_w)
 * updated: 2025-10-22 
 * updated: 2025-10-29 (mean, var, sd)
 * updated: 2025-11-09 (ger, ger_col, ger_row)
 * updated: 2025-11-25 (svdn0, svdn, logdet_IAtA_chol, logdet_IAtA_svd)
 **********************************************************************/

#include <R.h> 
#include "Cmat.hpp" 

/**********************************************************************
 * constructor 
 *
 * list of variables: 
 *       int nrow;               number of rows 
 *       int ncol;               number of columns 
 *       int ld;                 leading dimension 
 *       int length;             length = ld * ncol - (ld - nrow) 
 *       double *value;          values 
 *       bool is_allocated;      true = allocated, false = assigned 
 *
 *       int inc;                increment when it is a vector 
 *       int vec_length;         length as a vector 
 **********************************************************************/

Cmat::Cmat() 
{
    this->nrow = 0; 
    this->ncol = 0; 
    this->ld = 0; 
    this->length = 0; 
    this->value = nullptr;
    this->is_allocated = false;  

    this->inc = 0; 
    this->vec_length = 0; 
}

Cmat::Cmat(int n_row, int n_col) 
{
    this->nrow = n_row; 
    this->ncol = n_col; 
    this->ld = n_row; 
    this->set_derived(); 

    this->value = new double[this->length]();
    this->is_allocated = true;  
}

Cmat::Cmat(int n_row, int n_col, double *pt_values) 
{
    this->nrow = n_row; 
    this->ncol = n_col; 
    this->ld = n_row; 
    this->set_derived(); 

    this->value = pt_values;
    this->is_allocated = false;  
}

Cmat::Cmat(int n_row, int n_col, int n_ld) 
{
    this->nrow = n_row; 
    this->ncol = n_col; 
    this->ld = n_ld; 
    this->set_derived(); 

    this->value = new double[this->length]();
    this->is_allocated = true;  
}

Cmat::Cmat(int n_row, int n_col, double *pt_values, int n_ld) 
{
    this->nrow = n_row; 
    this->ncol = n_col; 
    this->ld = n_ld; 
    this->set_derived(); 

    this->value = pt_values;
    this->is_allocated = false;  
}

/* set derived variables in the constructor */

void Cmat::set_derived()
{
    if((this->ld) < (this->nrow))
    {
        std::cerr << "ld = " << this->ld << ", nrow = " << this->nrow << std::endl;
        error("Cmat::set_derive(): ld < nrow is not allowed.\n"); 
    }

    this->length = (this->ld) * (this->ncol) - (this->ld - this->nrow); 

    if(this->is_vector()) 
    {
        this->inc = (this->ncol == 1) ? (1) : (this->ld);
        this->vec_length = (this->ncol == 1) ? (this->nrow) : (this->ncol); 
    }
    else 
    {
        this->inc = 0; 
        this->vec_length = 0; 
    }
} 

/**********************************************************************
 * destructor 
 **********************************************************************/

Cmat::~Cmat() 
{
    if(this->is_allocated) delete[] this->value;  
} 

/**********************************************************************
 * get or set values 
 **********************************************************************/

int Cmat::get_nrow()
{
    return(this->nrow); 
}

int Cmat::get_ncol() 
{
    return(this->ncol); 
}

int Cmat::get_ld() 
{
    return(this->ld); 
}

int Cmat::get_length()
{
    return(this->length); 
}

int Cmat::get_inc()
{
    if(!(this->is_vector()))
        warning("Cmat::get_inc(): try to get inc for a matrix.\n"); 

    return(this->inc); 
}

int Cmat::get_vec_length()
{
    if(!(this->is_vector()))
        warning("Cmat::get_vec_length(): try to get vec_length for a matrix.\n"); 

    return(this->vec_length); 
}

double Cmat::get_entry(int row, int col)
{
    return(this->value[row + col * (this->ld)]); 
}

double Cmat::get_entry_vec(int i)
{
    return(this->value[i * (this->inc)]); 
}

double *Cmat::get_value_pt() 
{
    return(this->value); 
}

void Cmat::set_entry(int row, int col, double a)
{
    this->value[row + col * (this->ld)] = a; 
}

void Cmat::set_entry_vec(int i, double a)
{
    this->value[i * (this->inc)] = a; 
} 

void Cmat::set_value_pt(double *pt_values)
{
    /* release the memory if it is allocated */
    if(this->is_allocated) delete[] this->value;

    this->is_allocated = false; 
    this->value = pt_values; 
}

void Cmat::inc_entry(int row, int col, double a)
{
    this->value[row + col * (this->ld)] += a; 
}

void Cmat::scale_entry(int row, int col, double a)
{
    this->value[row + col * (this->ld)] *= a; 
}

void Cmat::inc_entry_vec(int i, double a) 
{
    this->value[i * (this->inc)] += a; 
}         
        
void Cmat::scale_entry_vec(int i, double a)
{
    this->value[i * (this->inc)] *= a; 
} 

/**********************************************************************
 * write matrix to file  
 **********************************************************************/

void Cmat::write2stream(std::ostream &stream, bool details)
{    
    if(details)
    {
        stream << "----------========== matrix ==========----------\n"; 
        stream << "nrow = " << this->nrow 
                << ", ncol = " << this->ncol 
                << ", ld = " << this->ld << std::endl;
        stream << "----------========== values ==========----------\n"; 
    }

    /* set overall precision */
    stream << std::setprecision(7);  

    /* write matrix to the text file */
    for(int i = 0; i < this->nrow; i++)
    {
        for(int j = 0; j < this->ncol; j++)
        {
            stream<< this->value[i + j * (this->ld)] << "   "; 
        }
        stream << std::endl; 
    }

    if(details)
    {
        stream << "----------========== end of values ==========----------\n\n" << std::endl;
    }
}

/* write to a file */

void Cmat::write2file(const char *filename)
{
    std::ofstream file(filename);
    if(!file.is_open())
        error("Cmat::write2file(): Failed to open the file to write.\n"); 

    this->write2stream(file); 
    file.close(); 
}

/* append to an existing file */

void Cmat::write2file_app(const char *filename)
{
    std::ofstream file(filename, std::ios::app);
    if(!file.is_open())
        error("Cmat::write2file_app(): Failed to open the file to write.\n"); 

    this->write2stream(file); 
    file.close(); 
}

/**********************************************************************
 * matrix operations 
 **********************************************************************/

/* values are saved in a contiguous memory block */

void Cmat::copy(const double *pt_values)
{
    if(this->nrow == this->ld)
    {
        this->copy_mem(pt_values); 
    }
    else 
    {
        int count = 0; 
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
        {
            this->value[i + j * (this->ld)] = pt_values[count]; 
            count++; 
        }
    }
}

/* directly copy a contiguous memory block without checking */

void Cmat::copy_mem(const double *pt_values)
{
    memcpy(this->value, pt_values, (this->length) * sizeof(double)); 
}

/* copy values from an existing matrix */

void Cmat::copy(Cmat &A)
{
    if((this->nrow != A.nrow) || (this->ncol != A.ncol))
        error("Cmat::copy(): incompatible dimensions.\n"); 

    if((this->ld == this->nrow) && (A.ld == A.nrow))
        this->copy_mem(A.get_value_pt());
    else if(A.ld == A.nrow)
        this->copy(A.get_value_pt()); 
    else 
    {
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
            this->value[i + j * (this->ld)] = A.get_entry(i, j); 
    } 
}

/* get transpose A' */

void Cmat::copy_T(Cmat &A)
{
    if((this->nrow != A.get_ncol()) || (this->ncol != A.get_nrow()))
        error("Cmat::copy_T(): incompatible dimensions.\n"); 

    for(int i = 0; i < this->nrow; i++)
    for(int j = 0; j < this->ncol; j++)
        this->value[i + j * (this->ld)] = A.get_entry(j, i); 
}                   

/* copy the diagonal of A */ 
void Cmat::copy_diag(Cmat &A)
{
    const int u = (A.get_nrow() < A.get_ncol()) ? (A.get_nrow()) : (A.get_ncol());
    if(! this->is_vector())
        error("Cmat::copy_diag(): it must be a vector.\n");
    if(this->vec_length != u)
        error("Cmat:copy_diag(): wrong dimension.\n"); 

    for(int i = 0; i < u; i++)
        this->value[i * (this->inc)] = A.get_entry(i, i); 
} 

/* write matrix to a contiguous memory block of length size */
void Cmat::write(double *pt_values, int size)
{
    if(size < (this->nrow) * (this->ncol))
        error("Cmat::write(): the size of the memory block is too small.\n"); 

    if(this->nrow == this->ld)
    {
        this->write_mem(pt_values, size); 
    }
    else 
    {
        int count = 0; 
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
        {
            pt_values[count] = this->value[i + j * (this->ld)]; 
            count++; 
        }
    }
}      

/* directly write matrix to a contiguous memory block of length size without checking*/

void Cmat::write_mem(double *pt_values, int size) 
{
    if(size < this->length)
        error("Cmat::write_mem(): the size of the memory block is too small.\n"); 

    memcpy(pt_values, this->value, (this->length) * sizeof(double));
}

/* complete the upper-triangular by symmetry */

void Cmat::complete_tri_upper()    
{
    if(! this->is_square())
        error("Cmat::complete_tri_upper(): it should be a square matrix.\n"); 

    for(int i = 0; i < (this->nrow); i++) 
    for(int j = i + 1; j < (this->nrow); j++)
        this->value[i + j * (this->ld)] = this->value[j + i * (this->ld)];
}

/* complete the lower-triangular by symmetry */

void Cmat::complete_tri_lower()    
{
    if(! this->is_square())
        error("Cmat::complete_tri_lower(): it should be a square matrix.\n"); 

    for(int i = 0; i < (this->nrow); i++) 
    for(int j = 0; j < i; j++)
        this->value[i + j * (this->ld)] = this->value[j + i * (this->ld)];
}

/* set all values as zero */ 

void Cmat::set_zero()
{
    if((this->nrow) == (this->ld))
    {
        memset(this->value, 0, (this->length) * sizeof(double)); 
    }
    else 
    {
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
        {
            this->value[i + j * (this->ld)] = 0.0; 
        }
    }
} 

/* set all values to be a constant */

void Cmat::set_const(double a)
{
    for(int i = 0; i < this->nrow; i++)
    for(int j = 0; j < this->ncol; j++)
        this->value[i + j * (this->ld)] = a; 
}                           

/* set identity matrix */

void Cmat::set_identity(double a)
{
    this->set_zero();

    const int mn = (this->nrow < this->ncol) ? (this->nrow) : (this->ncol);  
    for(int i = 0; i < mn; i++)
        this->value[i + i * (this->ld)] = a; 
}                       

/* set on-diag = on and off-diag = off */

void Cmat::set_cs(double on, double off)
{
    /* set all values to be off */
    this->set_const(off);

    /* set diagonal elements to be on */
    const int mn = (this->nrow < this->ncol) ? (this->nrow) : (this->ncol);  
    for(int i = 0; i < mn; i++)
        this->value[i + i * (this->ld)] = on;     
}   

/* check whether it is a scalar */

bool Cmat::is_scalar()
{
    return((this->nrow == 1) && (this->ncol == 1)); 
} 

/* check whether it is a vector */

bool Cmat::is_vector()
{
    return((this->nrow == 1) || (this->ncol == 1)); 
} 

/* check whether it is a square matrix */

bool Cmat::is_square()
{
    return(this->nrow == this->ncol); 
} 

/* check whether it is a identity matrix */

bool Cmat::is_identity(double tol)
{
    bool yes = (this->nrow == this->ncol); 

    for(int i = 0; i < this->nrow; i++)
    {
        if(! yes) break;
        for(int j = 0; j < this->ncol; j++)
        {
            if(! yes) break; 
            if(i == j) 
                yes = yes && (abs(this->value[i + j * (this->ld)] - 1.0) < tol); 
            else 
                yes = yes && (abs(this->value[i + j * (this->ld)]) < tol); 
        }
    }

    return(yes); 
}

/* set it as the i-th row of A */
void Cmat::as_row(Cmat &A, int i)        
{
    if(this->is_allocated)
    {
        delete[] this->value; 
        this->is_allocated = false; 
    }

    if(this->nrow != 1) 
        error("Cmat::as_row(): it is not a row vector.\n"); 
    if(this->ld != A.get_ld())
        error("Cmat::as_row(): its leading dimension differs from that of A.\n");
    if(this->ncol != A.get_ncol())
        error("Cmat::as_row(): its number of columns differs from that of A.\n");

    this->value = A.get_value_pt() + i;
}

/* set it as the j-th col of A */
void Cmat::as_col(Cmat &A, int j)          
{
    if(this->is_allocated)
    {
        delete[] this->value; 
        this->is_allocated = false; 
    }

    if(this->ncol != 1) 
        error("Cmat::as_col(): it is not a row vector.\n"); 
    if(this->nrow != A.get_nrow())
        error("Cmat::as_col(): its number of rows differs from that of A.\n");

    this->value = A.get_value_pt() + j * A.get_ld();
}

/* set it as the block matrix starting at (i, j) */
void Cmat::as_block(Cmat &A, int i, int j) 
{
    if(this->is_allocated)
    {
        delete[] this->value; 
        this->is_allocated = false; 
    }

    if(this->ld != A.get_ld())
        error("Cmat::as_block(): its leading dimension differs from that of A.\n");
    if((this->nrow) + i > A.get_nrow())
        error("Cmat::as_block(): beyond the number of rows of A.\n");
    if((this->ncol) + j > A.get_ncol())
        error("Cmat::as_block(): beyond the number of cols of A.\n");

    this->value = A.get_value_pt() + i + j * A.get_ld(); 
}

/* set it as the vector containing diagonal entries of A */ 
void Cmat::as_diag(Cmat &A)
{
    if(this->is_allocated)
    {
        delete[] this->value; 
        this->is_allocated = false; 
    }

    const int u = (A.get_nrow() < A.get_ncol()) ? (A.get_nrow()) : (A.get_ncol());
    if(! this->is_vector())
        error("Cmat::as_diag(): it must be a vector.\n");
    if(this->vec_length != u)
        error("Cmat::as_diag(): wrong dimension.\n"); 
    if(this->inc != A.get_ld() + 1)
        error("Cmat::as_diag(): wrong dimension.\n"); 

    this->value = A.get_value_pt(); 
} 

/* set it as the reshaped matrix A */

void Cmat::as_reshape(Cmat &A)
{
    if(this->is_allocated)
    {
        delete[] this->value; 
        this->is_allocated = false; 
    }

    if((this->length) != A.get_length())
        error("Cmat::as_reshape(): incompatible dimensions.\n");
    if((this->ld) != (this->nrow))
        error("Cmat::as_reshape(): cannot be reshaped.\n");

    this->value = A.get_value_pt(); 
}             

/* shift the pointer to value by offset */
void Cmat::value_pt_shift(int offset)      
{
    if(this->is_allocated)
        error("Cmat::value_pt_shift(): it is not allowed when the memory is allocated.\n"); 

    (this->value) += offset;  
}

/**********************************************************************
 * selected BLAS functions 
 **********************************************************************/

/* compute dot-product: x' * y or sum(x * y) */
/* interface to ddot */

double Cmat::dot(Cmat &x)
{
    double ans = 0.0; 
    if(this->is_vector())
    {
        /* if this is a vector, x must be a vector */ 
        if(! x.is_vector())
            error("Cmat::dot(): both should be vectors.\n"); 
        if(this->vec_length != x.get_vec_length())
            error("Cmat::dot(): incompatible dimensions.\n"); 

        const int incx = x.get_inc(); 
        ans = F77_CALL(ddot)(&(this->vec_length),
                        x.get_value_pt(), &incx,
                        this->value, &(this->inc)); 
    }
    else 
    {
        /* if this is a matrix, x must a matrix of the same dimension */
        if((this->nrow != x.get_nrow()) || (this->ncol != x.get_ncol()))
            error("Cmat::dot(): incompatible dimensions.\n"); 

        if((this->ld == this->nrow) && (x.get_ld() == x.get_nrow()))
        {
            const int ONE = 1; 
            ans = F77_CALL(ddot)(&(this->length),
                        x.get_value_pt(), &ONE,
                        this->value, &ONE); 
        }
        else 
        {
            for(int i = 0; i < (this->nrow); i++)
            for(int j = 0; j < (this->ncol); j++)
                ans += this->get_entry(i, j) * x.get_entry(i, j);
        }
    }

    return(ans); 
} 

/* compute sum of squared entries: x' * x or sum(x * x) */
/* interface to ddot with extension */
/* works for both vectors and matrices */

double Cmat::sum_sq()
{
    double ans = 0.0; 
    if(this->is_vector())  
    {
        ans = F77_CALL(ddot)(&(this->vec_length),
                        this->value, &(this->inc),
                        this->value, &(this->inc)); 
    }
    else if(this->nrow == this->ld)
    {
        /* not a vector, but values saved in a contiguous memory block */
        const int ONE = 1; 
        const int ab = (this->nrow) * (this->ncol); 
        ans = F77_CALL(ddot)(&ab,
                        this->value, &ONE,
                        this->value, &ONE);
    }
    else 
    {
        ans = 0.0; 
        for(int i = 0; i < this->nrow; i++)
        for(int j = 0; j < this->ncol; j++)
        {
            double tmp = this->value[i + j * (this->ld)];
            ans += tmp * tmp; 
        }
    }
    
    return(ans); 
} 

/* compute Euclidean norm */
/* interface to dnrm2 */

double Cmat::nrm2() 
{
    if(! this->is_vector() )
        error("Cmat::nrm2(): it should be a vector.\n"); 

    return( F77_CALL(dnrm2)(&(this->vec_length), this->value, &(this->inc)) ); 
}

/* compute sum of absolute values sum(abs(x)) */
/* interface to dasum */

double Cmat::asum()
{
    if(! this->is_vector() )
        error("Cmat::asum(): it should be a vector.\n"); 

    return( F77_CALL(dasum)(&(this->vec_length), this->value, &(this->inc)) ); 
}

/* y := a * x + y */
/* interface to daxpy with extension */
/* works for both vectors and matrices */

void Cmat::axpy(double a, Cmat &x) 
{
    if(this->is_vector())
    {
        if(! x.is_vector())
            error("Cmat::axpy(): both should be vectors.\n"); 
        if(this->vec_length != x.get_vec_length())
            error("Cmat::axpy(): incompatible dimensions.\n"); 

        const int incx = x.get_inc(); 
        F77_CALL(daxpy)(&(this->vec_length),
                    &a, x.get_value_pt(), &incx,
                        this->value, &(this->inc)); 
    }
    else /* not a vector */
    {
        if((this->nrow != x.get_nrow()) || (this->ncol != x.get_ncol()))
            error("Cmat::axpy(): incompatible dimensions.\n"); 

        if((this->nrow == this->ld) && (x.get_nrow() == x.get_ld()))
        {
            /* not a vector, but values in contiguous memory blocks */
            const int mn = (this->nrow) * (this->ncol); 
            const int ONE = 1; 
            F77_CALL(daxpy)(&mn,
                    &a, x.get_value_pt(), &ONE,
                        this->value, &ONE); 
        }
        else 
        {
            for(int i = 0; i < this->nrow; i++)
            for(int j = 0; j < this->ncol; j++)
                this->value[i + j * (this->ld)] += a * x.get_entry(i, j);
        }
    }
}

/**********************************************************************
 * add a * x to each row of the matrix: apply axpy to each row
 *    A --- m-by-n matrix 
 *    x --- length n 
 * row(A) = a * x + row(A)
 **********************************************************************/

void Cmat::axpy_row(double a, Cmat &x)
{
    if(! x.is_vector())
        error("Cmat::axpy_row(): x must be a vector.\n");
    if( x.get_vec_length() != this->ncol)
        error("Cmat::axpy_row(): incompatible dimensions.\n");  

    const int incx = x.get_inc(); 
    for(int i = 0; i < (this->nrow); i++)
        F77_CALL(daxpy)(&(this->ncol), 
                    &a, x.get_value_pt(), &incx, 
                        this->value + i, &(this->ld)); 
}

/**********************************************************************
 * add a * x to each column of the matrix: apply axpy to each column
 *    A --- m-by-n matrix 
 *    x --- length m 
 * col(A) = a * x + col(A)
 **********************************************************************/

void Cmat::axpy_col(double a, Cmat &x)
{
    if(! x.is_vector())
        error("Cmat::axpy_col(): x must be a vector.\n");
    if( x.get_vec_length() != this->nrow)
        error("Cmat::axpy_col(): incompatible dimensions.\n");  

    const int ONE = 1; 
    const int incx = x.get_inc(); 
    for(int i = 0; i < (this->ncol); i++)
        F77_CALL(daxpy)(&(this->nrow), 
                    &a, x.get_value_pt(), &incx, 
                        this->value + i * (this->ld), &ONE); 
}

/* y = a * A * x + b * y, y := a * A^T * x + b * y */
/* interface to dgemv for matrix-vector multiplication */

void Cmat::gemv(const char *trans, double a, Cmat &A, Cmat &x, double b)
{
    const int nrowA = A.get_nrow(); 
    const int ncolA = A.get_ncol(); 

    if((! x.is_vector()) || (! this->is_vector()))
        error("Cmat::gemv(): x and result must be vectors.\n"); 
    else if((trans[0] == 'N') && (this->vec_length != nrowA) && (x.get_vec_length() != ncolA))
        error("Cmat::gemv(): incompatible dimensions.\n"); 
    else if((trans[0] == 'T') && (this->vec_length != ncolA) && (x.get_vec_length() != nrowA))
        error("Cmat::gemv(): incompatible dimensions.\n");
    else if((trans[0] != 'N') && (trans[0] != 'T'))
        error("Cmat::gemv(): unsupported trans.\n"); 

    const int ldA = A.get_ld(); 
    const int incx = x.get_inc(); 
    F77_CALL(dgemv)(trans, 
                &nrowA, &ncolA, 
                &a, A.get_value_pt(), &ldA, 
                    x.get_value_pt(), &incx,
                &b, this->value, &(this->inc) FCONE); 
}

/* x = A * x, x = A^T * x */
/* interface to dtrmv for matrix-vector multiplication */
        
void Cmat::trmv(const char *uplo, const char *trans, const char *diag, Cmat &A) 
{
    if(! this->is_vector())
        error("Cmat::trmv(): it should be a vector.\n"); 
    if(! A.is_square())
        error("Cmat::trmv(): A should be a square matrix.\n"); 
    if( this->vec_length != A.get_ncol())
        error("Cmat::trmv(): incompatible dimensions.\n"); 

    const int ldA = A.get_ld(); 
    F77_CALL(dtrmv)(uplo, trans, diag, 
                &(this->vec_length), A.get_value_pt(), &ldA, 
                                     this->value, &(this->inc) FCONE FCONE FCONE); 
} 

/* x = A^{-1} * x, x = A^{-T} * x */
/* interface to dtrsv for triangular matrix A */

void Cmat::trsv(const char *uplo, const char *trans, const char *diag, Cmat &A)
{
    if(! this->is_vector())
        error("Cmat::trsv(): it should be a vector.\n"); 
    if(! A.is_square())
        error("Cmat::trsv(): A should be a square matrix.\n"); 
    if( this->vec_length != A.get_ncol())
        error("Cmat::trsv(): incompatible dimensions.\n"); 

    const int ldA = A.get_ld(); 
    F77_CALL(dtrsv)(uplo, trans, diag, 
                &(this->vec_length), A.get_value_pt(), &ldA, 
                                     this->value, &(this->inc) FCONE FCONE FCONE); 
} 

/* A = a * x * t(y) */
/* interface to dger */
        
void Cmat::ger(double a, Cmat &x, Cmat &y)
{
    if(! x.is_vector())
        error("Cmat::ger(): x must be a vector.\n");
    if(this->nrow != x.get_vec_length())    
        error("Cmat::ger(): incompatible dimension for x.\n"); 

    if(! y.is_vector())
        error("Cmat::ger(): y must be a vector.\n");
    if(this->ncol != y.get_vec_length())    
        error("Cmat::ger(): incompatible dimension for y.\n"); 

    int xinc = x.get_vec_length(); 
    int yinc = y.get_vec_length(); 
    F77_CALL(dger)(&(this->nrow), &(this->ncol), &a, 
                x.get_value_pt(), &xinc, 
                y.get_value_pt(), &yinc,
                this->value, &(this->ld)); 
}

/* apply dger to columns of x and y */
        
void Cmat::ger_col(Cmat &s, Cmat &x, Cmat &y)
{
    int n = x.get_ncol(); 

    if(this->nrow != x.get_nrow())    
        error("Cmat::ger_col(): incompatible rows for x.\n"); 
    if(this->ncol != y.get_nrow())    
        error("Cmat::ger_col(): incompatible rows for y.\n"); 
    if(n != y.get_ncol())  
        error("Cmat::ger_col(): incompatible columns for y.\n"); 

    if(! s.is_vector())
        error("Cmat::ger_col(): s must be a vector.\n");
    if(n != s.get_vec_length())
        error("Cmat::ger_col(): incompatible dimension for s\n"); 

    double *svalue = s.get_value_pt(); 
    const int sinc = s.get_inc();

    double *xvalue = x.get_value_pt(); 
    double *yvalue = y.get_value_pt(); 
    const int xld = x.get_ld(); 
    const int yld = y.get_ld(); 
    const int ONE = 1; 

    for(int i = 0; i < n; i++)
    {
        F77_CALL(dger)(&(this->nrow), &(this->ncol), 
                    svalue + i * sinc, 
                    xvalue + i * xld, &ONE, 
                    yvalue + i * yld, &ONE, 
                    this->value, &(this->ld));          
    }
}


/* apply dger to rows of x and y */
        
void Cmat::ger_row(Cmat &s, Cmat &x, Cmat &y)  
{
    int n = x.get_nrow(); 

    if(this->nrow != x.get_ncol())    
        error("Cmat::ger_row(): incompatible columns for x.\n"); 
    if(this->ncol != y.get_ncol())    
        error("Cmat::ger_row(): incompatible columns for y.\n"); 
    if(n != y.get_nrow())  
        error("Cmat::ger_row(): incompatible rows for y.\n"); 

    if(! s.is_vector())
        error("Cmat::ger_row(): s must be a vector.\n");
    if(n != s.get_vec_length())
        error("Cmat::ger_row(): incompatible dimension for s\n"); 

    double *svalue = s.get_value_pt(); 
    const int sinc = s.get_inc();

    double *xvalue = x.get_value_pt(); 
    double *yvalue = y.get_value_pt(); 
    const int xld = x.get_ld(); 
    const int yld = y.get_ld(); 

    for(int i = 0; i < n; i++)
    {
        F77_CALL(dger)(&(this->nrow), &(this->ncol), 
                    svalue + i * sinc, 
                    xvalue + i, &xld, 
                    yvalue + i, &yld, 
                    this->value, &(this->ld));          
    }
}

/* A = a * x * x^T + A */
/* interface to dsyr for symmetric matrix */
        
void Cmat::syr(const char *uplo, double a, Cmat &x)
{
    if(! this->is_square())
        error("Cmat::syr(): it must be a square matrix.\n");
    if(! x.is_vector())
        error("Cmat::syr(): x must be a vector.\n"); 
    if(this->nrow != x.get_vec_length())
        error("Cmat::syr(): incompatible dimensions.\n"); 

    const int incx = x.get_inc(); 
    F77_CALL(dsyr)(uplo, &(this->nrow), 
                &a, x.get_value_pt(), &incx, 
                    this->value, &(this->ld) FCONE); 
}

/*****************************************************************
 * x = x + U * Lambda * U' 
 * Lambda = diag(s) is a diagonal matrix  
 * apply dsyr to columns of U
 * Notice that x should be symmetric on entry 
 *    x = x + U * Lambda * U'    n-by-n matrix 
 *    s --- length d, Lambda = diag(s) 
 *    U --- n-by-d               save vectors column-wise        
 *****************************************************************/

void Cmat::syr_col(const char *uplo, Cmat &s, Cmat &U)
{
    if(! s.is_vector())
        error("Cmat::syr_col(): s should be a vector.\n"); 
    if(s.get_vec_length() != U.get_ncol())
    {
        std::cout << "s.get_vec_length() = " << s.get_vec_length() 
                  << ", U.get_ncol() = " << U.get_ncol() 
                  << std::endl;
        error("Cmat::syr_col(): incompatible dimensions - s.\n"); 
    }

    if(! this->is_square())
        error("Cmat::syr_col(): it should be a square matrix.\n"); 
    if(this->nrow != U.get_nrow())
        error("Cmat::syr_col(): incompatible dimensions - U.\n"); 

    const int d = s.get_vec_length(); 
    const int incs = s.get_inc(); 
    const int ldU = U.get_ld(); 
    const int ONE = 1.0; 
    const double *sptr = s.get_value_pt(); 
    const double *Uptr = U.get_value_pt(); 
    for(int i = 0; i < d; i++)
    {
        F77_CALL(dsyr)(uplo, &(this->nrow), 
                    sptr + i * incs, Uptr + i * ldU, &ONE, 
                    this->value, &(this->ld) FCONE);
    }
}

/*****************************************************************
 * x = x + U' * Lambda * U
 * Lambda = diag(s) is a diagonal matrix
 * apply dsyr to rows of U
 *    x = x + U' * Lambda * U    n-by-n matrix 
 *    s --- length d, Lambda = diag(s) 
 *    U --- d-by-n               save vectors row-wise 
 * Notice that x should be symmetric on entry 
 *****************************************************************/

void Cmat::syr_row(const char *uplo, Cmat &s, Cmat &U) 
{
    if(! s.is_vector())
        error("Cmat::syr_row(): s should be a vector.\n"); 
    if(s.get_vec_length() != U.get_nrow())
        error("Cmat::syr_row(): incompatible dimensions - s.\n"); 

    if(! this->is_square())
        error("Cmat::syr_row(): it should be a square matrix.\n"); 
    if(this->nrow != U.get_ncol())
        error("Cmat::syr_row(): incompatible dimensions - U.\n"); 

    const int d = s.get_vec_length(); 
    const int incs = s.get_inc(); 
    const int ldU = U.get_ld(); 
    const double *sptr = s.get_value_pt(); 
    const double *Uptr = U.get_value_pt(); 
    for(int i = 0; i < d; i++)
    {
        F77_CALL(dsyr)(uplo, &(this->nrow), 
                    sptr + i * incs, Uptr + i, &ldU, 
                    this->value, &(this->ld) FCONE);
    }
}

/* C := a * op(A) * op(B) + b * C, op(X) = X or X^T */
/* interface to dgemm for matrix-matrix multiplication */

void Cmat::gemm(const char *transA, const char *transB, double a, Cmat &A, Cmat &B, double b)
{
    int k; 

    if((transA[0] == 'N') && (transB[0] == 'N'))
    {
        k = A.get_ncol(); 
        if((this->nrow != A.get_nrow()) || 
           (this->ncol != B.get_ncol()) ||
           (A.get_ncol() != B.get_nrow()))
            error("Cmat::gemm(): (N, N) - incompatible dimensions.\n"); 
    }
    else if((transA[0] == 'N') && (transB[0] == 'T'))
    {
        k = A.get_ncol(); 
        if((this->nrow != A.get_nrow()) || 
           (this->ncol != B.get_nrow()) ||
           (A.get_ncol() != B.get_ncol()))
            error("Cmat::gemm(): (N, T) - incompatible dimensions.\n"); 
    }
    else if((transA[0] == 'T') && (transB[0] == 'N'))
    {
        k = A.get_nrow(); 
        if((this->nrow != A.get_ncol()) || 
           (this->ncol != B.get_ncol()) ||
           (A.get_nrow() != B.get_nrow()))
            error("Cmat::gemm(): (T, N) - incompatible dimensions.\n"); 
    }
    else if((transA[0] == 'T') && (transB[0] == 'T'))
    {
        k = A.get_nrow(); 
        if((this->nrow != A.get_ncol()) || 
           (this->ncol != B.get_nrow()) ||
           (A.get_nrow() != B.get_ncol()))
            error("Cmat::gemm(): (T, T) - incompatible dimensions.\n"); 
    }
    else 
        error("Cmat::gemm(): unsupported transA or transB.\n"); 
    
    const int ldA = A.get_ld(); 
    const int ldB = B.get_ld(); 
    F77_CALL(dgemm)(transA, transB, 
                &(this->nrow), &(this->ncol), &k, 
                &a, A.get_value_pt(), &ldA, 
                    B.get_value_pt(), &ldB, 
                &b, this->value, &(this->ld) FCONE FCONE); 
} 

/* C := a * A * A^T + b * C, C := a * A^T * A + b * C */
/* interface to dsyrk */

void Cmat::syrk(const char *uplo, const char *trans, double a, Cmat &A, double b)
{
    int k; 
    if(trans[0] == 'N') k = A.get_ncol(); 
    else if(trans[0] == 'T') k = A.get_nrow();
    else error("Cmat::syrk(): unsupported trans.\n"); 

    const int ldA = A.get_ld(); 
    F77_CALL(dsyrk)(uplo, trans,
                &(this->nrow), &k, 
                &a, A.get_value_pt(), &ldA, 
                &b, this->value, &(this->ld) FCONE FCONE); 
}

/* B := a * op(A) * B, B := a * B * op(A), op(A) = A or A^T */
/* interface to dtrmm for triangular matrix A */
        
void Cmat::trmm(const char *side, const char *uplo, const char *trans, const char *diag, double a, Cmat &A) 
{
    if(! A.is_square())
        error("Cmat::trmm(): A must be a square matrix.\n"); 

    if(side[0] == 'L')
    {
        if(A.get_ncol() != this->nrow) 
            error("Cmat::trmm(): L - incompatible dimensions.\n"); 
    }
    else if(side[0] == 'R') 
    {
        if(A.get_ncol() != this->ncol) 
            error("Cmat::trmm(): R - incompatible dimensions.\n"); 
    }
    else 
        error("Cmat::trmm(): unspported side.\n"); 

    const int ldA = A.get_ld(); 
    F77_CALL(dtrmm)(side, uplo, trans, diag,
                &(this->nrow), &(this->ncol), 
                &a, A.get_value_pt(), &ldA, 
                    this->value, &(this->ld) FCONE FCONE FCONE FCONE); 
}

/* B := a * op(A^{-1}) * B, B := a * B * op(A^{-1}), op(A) = A or A^T */
/* interface to dtrsm for triangular matrix A */

void Cmat::trsm(const char *side, const char *uplo, const char *trans, const char *diag, double a, Cmat &A)
{
    if(! A.is_square())
        error("Cmat::trsm(): A must be a square matrix.\n"); 

    if(side[0] == 'L')
    {
        if(A.get_ncol() != this->nrow) 
            error("Cmat::trsm(): L - incompatible dimensions.\n"); 
    }
    else if(side[0] == 'R') 
    {
        if(A.get_ncol() != this->ncol) 
            error("Cmat::trsm(): R - incompatible dimensions.\n"); 
    }
    else 
        error("Cmat::trsm(): unspported side.\n"); 

    const int ldA = A.get_ld(); 
    F77_CALL(dtrsm)(side, uplo, trans, diag,
                &(this->nrow), &(this->ncol), 
                &a, A.get_value_pt(), &ldA, 
                    this->value, &(this->ld) FCONE FCONE FCONE FCONE); 
}

/**********************************************************************
 * more matrix operations 
 **********************************************************************/

/* add a constant to each entry */  

void Cmat::add(double a)       
{
    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        this->value[i + j * (this->ld)] += a; 
}

/* multiply each entry by a constant */

void Cmat::scale(double a)
{
    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        this->value[i + j * (this->ld)] *= a; 
}

/* square each entry */

void Cmat::entry_square()          
{
    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        this->value[i + j * (this->ld)] *= this->value[i + j * (this->ld)]; 
}

/* square root each entry */

void Cmat::entry_sqrt()              
{
    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        this->value[i + j * (this->ld)] = sqrt(this->value[i + j * (this->ld)]); 
}

/* reciprocal of each entry */

void Cmat::entry_reciprocal()        
{
    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        this->value[i + j * (this->ld)] = 1.0 / this->value[i + j * (this->ld)]; 
}

/* compute sum of all values sum(x) */

double Cmat::sum()             
{
    double ans = 0.0; 

    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        ans += this->value[i + j * (this->ld)]; 

    return(ans); 
}

/* compute mean of all values: mean(x) */        

double Cmat::mean()  
{
    int row_col = (this->nrow) * (this->ncol); 
    return(this->sum() / (double)(row_col));
}

/* compute var of all values: var(x) */

double Cmat::var()             
{
    double xmean = this->mean(); 
    double ans = 0.0; 

    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
    {
        double xij = this->value[i + j * (this->ld)] - xmean;
        ans += xij * xij; 
    }

    int df = (this->nrow) * (this->ncol) - 1;
    return(ans / (double)(df)); 
}

/* compute sd of all values: sd(x) */

double Cmat::sd()
{
    return(sqrt(this->var())); 
}              

/* compute trace of a matrix, sum(diag(x)) */

double Cmat::trace()           
{
    double ans = 0.0; 
    const int u = ((this->nrow) < (this->ncol)) ? (this->nrow) : (this->ncol); 

    for(int i = 0; i < u; i++)
        ans += this->value[i + i * (this->ld)];

    return(ans); 
}

/* compute product of all values: prod(x) */ 

double Cmat::prod()   
{
    double ans = 1.0; 

    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        ans *= this->value[i + j * (this->ld)]; 

    return(ans); 
}

/* compute log sum of all values: sum(log(x)) */
        
double Cmat::sumlog()          
{
    double ans = 0.0; 

    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++)
        ans += log(this->value[i + j * (this->ld)]); 

    return(ans); 
}

/* compute sum for each row of A */

void Cmat::rowSums(Cmat &A)
{
    if(! this->is_vector())
        error("Cmat::rowSums(): it must be a vector.\n"); 
    else if((this->ncol == 1) && (this->nrow != A.get_nrow()))
        error("Cmat::rowSums(): incompatible dimensions.\n"); 
    else if((this->nrow == 1) && (this->ncol != A.get_nrow()))
        error("Cmat::rowSums(): incompatible dimensions.\n"); 

    const int ncolA = A.get_ncol(); 
    const int nrowA = A.get_nrow(); 
    const int ldA = A.get_ld(); 
    const double *Apt = A.get_value_pt(); 
    for(int i = 0; i < nrowA; i++)
    {
        double sum = 0.0; 
        for(int j = 0; j < ncolA; j++) sum += Apt[i + j * ldA];
        this->value[i * (this->inc)] = sum; 
    }
}

/* compute mean for each row of A*/

void Cmat::rowMeans(Cmat &A)
{
    this->rowSums(A);
    this->scale(1.0 / (double)(A.get_ncol()));
}

/* compute sum for each column of A */

void Cmat::colSums(Cmat &A)
{
    if(! this->is_vector())
        error("Cmat::colSums(): it must be a vector.\n"); 
    else if((this->ncol == 1) && (this->nrow != A.get_ncol()))
        error("Cmat::colSums(): incompatible dimensions.\n"); 
    else if((this->nrow == 1) && (this->ncol != A.get_ncol()))
        error("Cmat::colSums(): incompatible dimensions.\n"); 

    const int ncolA = A.get_ncol(); 
    const int nrowA = A.get_nrow(); 
    const int ldA = A.get_ld(); 
    const double *Apt = A.get_value_pt(); 
    for(int i = 0; i < ncolA; i++)
    {
        double sum = 0.0; 
        for(int j = 0; j < nrowA; j++) sum += Apt[i + j * ldA];
        this->value[i * (this->inc)] = sum; 
    }
}

/* compute mean for each column of A*/

void Cmat::colMeans(Cmat &A)
{
    this->colSums(A);
    this->scale(1.0 / (double)(A.get_nrow()));
}

/* compute weighted sum for each row of A */

void Cmat::rowSums_w(Cmat &A, Cmat &w)    
{
    const int ncolA = A.get_ncol(); 
    const int nrowA = A.get_nrow(); 
    const int ldA = A.get_ld(); 

    if(! this->is_vector())
        error("Cmat::rowSums_w(): it must be a vector.\n"); 
    else if((this->ncol == 1) && (this->nrow != nrowA))
        error("Cmat::rowSums_w(): incompatible dimensions.\n"); 
    else if((this->nrow == 1) && (this->ncol != nrowA))
        error("Cmat::rowSums_w(): incompatible dimensions.\n"); 

    if(! w.is_vector())
        error("Cmat::rowSums_w(): w must be a vector.\n");
    else if(w.get_vec_length() != ncolA)
        error("Cmat::rowSums_w(): A and w have incompatible dimensions.\n"); 

    Cmat rowAi(1, ncolA, nullptr, ldA); 
    for(int i = 0; i < nrowA; i++)
    {
        rowAi.as_row(A, i); 
        this->value[i * (this->inc)] = w.dot(rowAi); 
    }
}

/* compute weighted mean for each row of A */

void Cmat::rowMeans_w(Cmat &A, Cmat &w)   
{
    this->rowSums_w(A, w);
    this->scale(1.0 / (double)(A.get_ncol()));
}

/* compute weighted sum for each column of A */

void Cmat::colSums_w(Cmat &A, Cmat &w)    
{
    const int ncolA = A.get_ncol(); 
    const int nrowA = A.get_nrow(); 

    if(! this->is_vector())
        error("Cmat::colSums_w(): it must be a vector.\n"); 
    else if((this->ncol == 1) && (this->nrow != ncolA))
        error("Cmat::colSums_w(): incompatible dimensions.\n"); 
    else if((this->nrow == 1) && (this->ncol != ncolA))
        error("Cmat::colSums_w(): incompatible dimensions.\n"); 

    if(! w.is_vector())
        error("Cmat::colSums_w(): w must be a vector.\n");
    else if(w.get_vec_length() != nrowA)
        error("Cmat::colSums_w(): A and w have incompatible dimensions.\n"); 

    Cmat colAi(nrowA, 1, nullptr); 
    for(int i = 0; i < ncolA; i++)
    {
        colAi.as_col(A, i); 
        this->value[i * (this->inc)] = w.dot(colAi); 
    }
}

/* compute weighted mean for each column of A */

void Cmat::colMeans_w(Cmat &A, Cmat &w)   
{
    this->colSums_w(A, w);
    this->scale(1.0 / (double)(A.get_nrow()));
}

/* center each row by subtracting mean */

void Cmat::rowCenter(Cmat &mean)
{
    const int mean_nrow = mean.get_nrow(); 
    const int mean_ncol = mean.get_ncol(); 

    if(! mean.is_vector())
        error("Cmat::rowCenter(): it must be a vector.\n"); 
    else if((mean_ncol == 1) && (mean_nrow != this->nrow))
        error("Cmat::rowCenter(): incompatible dimensions.\n"); 
    else if((mean_nrow == 1) && (mean_ncol != this->nrow))
        error("Cmat::rowCenter(): incompatible dimensions.\n"); 

    const int inc = mean.get_inc();
    const double *mpt = mean.get_value_pt();
    for(int i = 0; i < this->nrow; i++)
    for(int j = 0; j < this->ncol; j++)
        this->value[i + j * (this->ld)] -= mpt[i * inc];
}

/* center each col by subtracting mean */
void Cmat::colCenter(Cmat &mean)  
{
    const int mean_nrow = mean.get_nrow(); 
    const int mean_ncol = mean.get_ncol(); 

    if(! mean.is_vector())
        error("Cmat::colCenter(): it must be a vector.\n"); 
    else if((mean_ncol == 1) && (mean_nrow != this->ncol))
        error("Cmat::colCenter(): incompatible dimensions.\n"); 
    else if((mean_nrow == 1) && (mean_ncol != this->ncol))
        error("Cmat::colCenter(): incompatible dimensions.\n"); 

    const int inc = mean.get_inc();
    const double *mpt = mean.get_value_pt();
    for(int i = 0; i < this->nrow; i++)
    for(int j = 0; j < this->ncol; j++)
        this->value[i + j * (this->ld)] -= mpt[j * inc];
}

/* scale each row by dividing sd */

void Cmat::rowScale(Cmat &sd)     
{
    const int sd_nrow = sd.get_nrow(); 
    const int sd_ncol = sd.get_ncol(); 

    if(! sd.is_vector())
        error("Cmat::rowScale(): it must be a vector.\n"); 
    else if((sd_ncol == 1) && (sd_nrow != this->nrow))
        error("Cmat::rowScale(): incompatible dimensions.\n"); 
    else if((sd_nrow == 1) && (sd_ncol != this->nrow))
        error("Cmat::rowScale(): incompatible dimensions.\n"); 

    const int inc = sd.get_inc();
    const double *mpt = sd.get_value_pt();
    for(int i = 0; i < this->nrow; i++)
    for(int j = 0; j < this->ncol; j++)
        this->value[i + j * (this->ld)] /= mpt[i * inc];
}

/* scale each col by dividing sc */

void Cmat::colScale(Cmat &sd)     
{
    const int sd_nrow = sd.get_nrow(); 
    const int sd_ncol = sd.get_ncol(); 

    if(! sd.is_vector())
        error("Cmat::colScale(): it must be a vector.\n"); 
    else if((sd_ncol == 1) && (sd_nrow != this->ncol))
        error("Cmat::colScale(): incompatible dimensions.\n"); 
    else if((sd_nrow == 1) && (sd_ncol != this->ncol))
        error("Cmat::colScale(): incompatible dimensions.\n"); 

    const int inc = sd.get_inc();
    const double *mpt = sd.get_value_pt();
    for(int i = 0; i < this->nrow; i++)
    for(int j = 0; j < this->ncol; j++)
        this->value[i + j * (this->ld)] /= mpt[j * inc];
}

/* convert variance matrix to correlation, extract SDs */

void Cmat::var2cor(Cmat &dvec)
{
    if(! this->is_square())
        error("Cmat::var2cor(): this matrix must be a square matrix.\n");  
    if(! dvec.is_vector())
        error("Cmat::var2cor(): dvec must be a vector.\n");
    if(dvec.get_vec_length() != this->nrow)
        error("Cmat::var2cor(): incompatible dimensions.\n"); 

    for(int k = 0; k < this->nrow; k++)
    {
        double sd = sqrt(this->value[k + k * (this->ld)]); 
        dvec.set_entry_vec(k, sd);

        this->value[k + k * (this->ld)] = 1.0; 
        for(int i = 0; i < k; i++)
            this->value[k + i * (this->ld)] /= sd; 
        for(int i = k + 1; i < this->nrow; i++)
            this->value[i + k * (this->ld)] /= sd; 
    }

    this->complete_tri_upper(); 
}    
        
/* compute variance from correlation */

void Cmat::cor2var(Cmat &dvec)
{
    if(! this->is_square())
        error("Cmat::cor2var(): this matrix must be a square matrix.\n");  
    if(! dvec.is_vector())
        error("Cmat::cor2var(): dvec must be a vector.\n");
    if(dvec.get_vec_length() != this->nrow)
        error("Cmat::cor2var(): incompatible dimensions.\n"); 

    for(int k = 0; k < this->nrow; k++) 
    {
        double sd = dvec.get_entry_vec(k); 
        this->value[k + k * (this->ld)] *= (sd * sd); 
        for(int i = 0; i < k; i++)
            this->value[k + i * (this->ld)] *= sd; 
        for(int i = k + 1; i < this->nrow; i++)
            this->value[i + k * (this->ld)] *= sd; 
    }

    this->complete_tri_upper(); 
}    

/* var_inv instead of var and dinv = 1/dvec */ 

void Cmat::var2cor_inv(Cmat &dinv)
{
    if(! this->is_square())
        error("Cmat::var2cor_inv(): this matrix must be a square matrix.\n");  
    if(! dinv.is_vector())
        error("Cmat::var2cor_inv(): dinv must be a vector.\n");
    if(dinv.get_vec_length() != this->nrow)
        error("Cmat::var2cor_inv(): incompatible dimensions.\n"); 

    Cmat var(this->nrow, this->ncol); 
    var.copy(*this); 
    var.inv(); 

    for(int k = 0; k < this->nrow; k++)
    {
        double sd = sqrt(var.get_entry(k, k));  
        dinv.set_entry_vec(k, 1.0 / sd);

        this->value[k + k * (this->ld)] *= (sd * sd); 
        for(int i = 0; i < k; i++)
            this->value[k + i * (this->ld)] *= sd; 
        for(int i = k + 1; i < this->nrow; i++)
            this->value[i + k * (this->ld)] *= sd; 
    }

    this->complete_tri_upper(); 
} 

/* kronecker product of A and B */

void Cmat::kron(Cmat &A, Cmat &B)
{
    const int A_nrow = A.get_nrow(); 
    const int A_ncol = A.get_ncol(); 
    const int B_nrow = B.get_nrow(); 
    const int B_ncol = B.get_ncol(); 
    
    if((this->nrow != A_nrow * B_nrow) || (this->ncol != A_ncol * B_ncol))
        error("Cmat::kron(): incompatible dimensions.\n");
    
    /* set all entries as 0 */
    this->set_zero();

    Cmat block(B_nrow, B_ncol, nullptr, this->ld); 
    for(int i = 0; i < A_nrow; i++)
    for(int j = 0; j < A_ncol; j++)
    {
        block.as_block(*(this), i * B_nrow, j * B_ncol);
        block.axpy(A.get_entry(i, j), B);  
    }
} 

/**********************************************************************
 * compute x' * A * x
 * A is a symmetric matrix, and only the lower-triangular is used
 *    A --- n-by-n matrix 
 *    x --- length n 
 **********************************************************************/

double Cmat::quadr(Cmat &x)
{
    if(! this->is_square())
        error("Cmat::quadr(): it must be a square matrix.\n"); 

    if(! x.is_vector())
        error("Cmat::quadr(): x must be a vector");
    if(x.get_vec_length() != this->nrow)
        error("Cmat::quadr(): incompatible dimensions.\n"); 

    double xAx = 0.0; 
    for(int i = 0; i < (this->nrow); i++)
    {
        xAx += x.get_entry_vec(i) * x.get_entry_vec(i) * this->get_entry(i, i); 
        for(int j = 0; j < i; j++) 
            xAx += 2.0 * x.get_entry_vec(i) * x.get_entry_vec(j) * this->get_entry(i, j);   
    }

    return(xAx); 
}

/**********************************************************************
 * compute x' * A * y 
 *    A --- n-by-m matrix 
 *    x --- length n 
 *    y --- length m
 **********************************************************************/

double Cmat::quadr2(Cmat &x, Cmat &y)
{
    if(! x.is_vector())
        error("Cmat::quadr(): x must be a vector");
    if(x.get_vec_length() != this->nrow)
        error("Cmat::quadr(): incompatible dimensions - x.\n"); 

    if(! y.is_vector())
        error("Cmat::quadr(): y must be a vector");
    if(y.get_vec_length() != this->ncol)
        error("Cmat::quadr(): incompatible dimensions - y.\n"); 

    double xAy = 0.0; 
    for(int i = 0; i < (this->nrow); i++)
    for(int j = 0; j < (this->ncol); j++) 
        xAy += x.get_entry_vec(i) * y.get_entry_vec(j) * this->get_entry(i, j); 

    return(xAy); 
}

/**********************************************************************
 * update C as a * A * B * A' + b * C 
 *    A --- m-by-n 
 *    B --- n-by-n 
 *    C --- m-by-m 
 **********************************************************************/

void Cmat::ABAt(double a, Cmat &A, Cmat &B, double b)  
{
    if(! this->is_square())
        error("Cmat::ABAt(): it must be a square matrix.\n"); 
    if(! B.is_square())
        error("Cmat::ABAt(): B must be a square matrix.\n"); 
    if((this->nrow != A.get_nrow()) || (A.get_ncol() != B.get_nrow()))
        error("Cmat::ABAt(): incompatible dimensions.\n"); 

    Cmat AB(this->nrow, B.get_nrow()); 
    AB.gemm("N", "N", 1.0, A, B, 0.0);   /* AB = A * B */
    this->gemm("N", "T", a, AB, A, b);   /* this = a * A * B * A' + b * C */
}

/**********************************************************************
 * update C as a * A' * B * A + b * C 
 *    A --- m-by-n 
 *    B --- m-by-m 
 *    C --- n-by-n  
 **********************************************************************/

void Cmat::AtBA(double a, Cmat &A, Cmat &B, double b)
{
    if(! this->is_square())
        error("Cmat::AtBA(): it must be a square matrix.\n"); 
    if(! B.is_square())
        error("Cmat::AtBA(): B must be a square matrix.\n"); 
    if((this->nrow != A.get_ncol()) || (A.get_nrow() != B.get_nrow()))
        error("Cmat::AtBA(): incompatible dimensions.\n"); 

    Cmat AtB(this->nrow, B.get_nrow());
    AtB.gemm("T", "N", 1.0, A, B, 0.0);  /* AtB = A' * B */
    this->gemm("N", "N", a, AtB, A, b);  /* this = a * A' * B * A + b * C */
}

/* B := a * A^{-1} * B, B := a * B * A^{-1} */
/* input Achol is the chol of A (low-triangular) */

void Cmat::solve_chol_left(Cmat &Achol, double a)
{
    this->trsm("L", "L", "N", "N", 1.0, Achol); 
    this->trsm("L", "L", "T", "N", a, Achol); 
}

void Cmat::solve_chol_right(Cmat &Achol, double a)
{
    this->trsm("R", "L", "T", "N", 1.0, Achol); 
    this->trsm("R", "L", "N", "N", a, Achol); 
} 

/* compute log-determinant of a positive definite matrix by Cholesky factorization */

double Cmat::logdet_chol()
{
    if(! this->is_square())
        error("Cmat::logdet_chol(): must be a square matrix.\n"); 

    Cmat Achol(this->nrow, this->ncol); 
    Achol.copy(*this); 
    Achol.chol(); 

    double ans = 0.0; 
    for(int i = 0; i < this->nrow; i++) 
        ans += log(Achol.get_entry(i, i)); 

    return(2.0 * ans); 
}


/* compute log-determinant of (I + A' * A) by Cholesky factorization */
        
double Cmat::logdet_IAtA_chol()
{
    int AA_dim = this->ncol; 
    char trans[] = "T";
    
    if((this->nrow) < (this->ncol)) 
    {
        /* compute log(det(I + A * A')) */ 
        AA_dim = this->nrow; 
        trans[0] = 'N'; 
    }

    Cmat AA(AA_dim, AA_dim); 
    AA.syrk("L", trans, 1.0, *(this), 0.0);
    for(int i = 0; i < AA_dim; i++) AA.inc_entry(i, i, 1.0); 
    AA.chol(); 

    double ans = 0.0; 
    for(int i = 0; i < AA_dim; i++) ans += log(AA.get_entry(i, i));

    return(2.0 * ans); 
} 

/* compute log-determinant of (I + A' * A) by SVD */
        
double Cmat::logdet_IAtA_svd()
{
    const int rank = ((this->nrow) < (this->ncol)) ? (this->nrow) : (this->ncol); 
    Cmat dvec(rank, 1); 
    this->svdn(dvec); 

    double ans = 0.0; 
    for(int i = 0; i < rank; i++)
    {
        double di = dvec.get_entry_vec(i); 
        ans += log(1.0 + di * di); 
    }

    return(ans); 
} 

/**********************************************************************
 * linear algebra 
 **********************************************************************/

/* compute Cholesky factorization: x = L * L' */
/* L is a lower-triangular matrix */
/* interface to dpotrf */

int Cmat::chol()
{
    if(this->nrow != this->ncol)
        error("Cmat::chol(): the matrix must be a square.\n"); 

    int info; 
    F77_CALL(dpotrf)("L", &(this->nrow), this->value, &(this->ld), &info FCONE); 
    return(info); 
}


/* restore the matrix from its Cholesky factorization */
/* update the upper-triangular components */
/* then complete the matrix by symmetry */
        
void Cmat::chol_restore()
{
    if(this->nrow != this->ncol)
        error("Cmat::chol_restore(): the matrix must be a square.\n"); 

    for(int i = 0, len = 1; i < (this->nrow); i++, len++)
    {
        for(int j = i + 1; j < (this->nrow); j++)
        {
            this->value[i + j * (this->ld)] = 
                F77_CALL(ddot)(&len, this->value + i, &(this->ld), 
                                     this->value + j, &(this->ld)); 
        }

        this->value[i + i * (this->ld)] = 
                F77_CALL(ddot)(&len, this->value + i, &(this->ld), 
                                     this->value + i, &(this->ld)); 
    }

    this->complete_tri_lower(); 
}   

/**********************************************************************
 * compute the LU factorization of m-by-n matrix A 
 * ipiv --- integer array of size min(m, n) 
 **********************************************************************/

int Cmat::lu(int *ipiv)
{
    int info; 
    F77_CALL(dgetrf)(&(this->nrow), &(this->ncol), this->value, &(this->ld), 
                    ipiv, &info);
    return(info);  
}

/**********************************************************************
 * compute the inverse of a general square matrix 
 **********************************************************************/

int Cmat::inv()
{
    if(! this->is_square())
        error("Cmat::inv(): it must be a square matrix.\n"); 

    int *ipiv = new int[this->nrow](); 
    this->lu(ipiv); 

    /* workspace query */
    int info, lwork = -1; 
    double tmp; 
    F77_CALL(dgetri)(&(this->nrow), this->value, &(this->ld), 
                    ipiv, &tmp, &lwork, &info); 
    lwork = (int)tmp; 

    /* compute the inverse of the matrix */
    double *work = new double[lwork](); 
    F77_CALL(dgetri)(&(this->nrow), this->value, &(this->ld), 
                    ipiv, work, &lwork, &info); 

    delete[] work; 
    delete[] ipiv; 
    return(info); 
}

/**********************************************************************
 * compute the inverse of a square matrix by Cholesky factorization
 * the current matrix is already the result of chol()
 * it is an interface to dpotri()
 **********************************************************************/

int Cmat::inv_chol() 
{
    int info; 
    F77_CALL(dpotri)("L", &(this->nrow), this->value, &(this->ld), &info FCONE);
    
    this->complete_tri_upper(); 
    return(info);  
}    

/**********************************************************************
 * compute QR-factorization of A (n-by-p matrix) 
 * A will be replaced by the QR-factorization 
 * tau is a vector of p (= min(n, p)) 
 **********************************************************************/

int Cmat::qr(Cmat &tau)
{
    const int rank = ((this->nrow) < (this->ncol)) ? (this->nrow) : (this->ncol); 

    if(! tau.is_vector())
        error("Cmat::qr(): tau must be a vector.\n");
    else if(tau.get_vec_length() != rank)
        error("Cmat::qr(): incompatible dimensions.\n"); 

    int info, lwork = -1;
    double tmp; 
    /* calculate the optimal size of the work array */ 
    F77_CALL(dgeqrf)(&(this->nrow), &(this->ncol), 
            this->value, &(this->ld), tau.get_value_pt(), 
            &tmp, &lwork, &info); 
    lwork = (int)(tmp); 
    double *work = new double[lwork](); 

    F77_CALL(dgeqrf)(&(this->nrow), &(this->ncol), 
            this->value, &(this->ld), tau.get_value_pt(), 
            work, &lwork, &info); 
    delete[] work; 
    return(info); 
}

/**********************************************************************
 * compute a QR factorization with column pivoting
 * x -- (n-by-p matrix, n > p), replaced by the QR-factorization 
 * jpvt -- (p-by-1 vector of integers) = 0 
 * tau -- (p-by-1 vector) output (= min(n, p))
 * 
 * output:
 *   x: the upper triangle of the array contains the p-by-p upper 
 *      trapezoidal matrix R; the elements below the diagonal, 
 *      together with the array TAU, represent the orthogonal
 *      matrix Q as a product of p elementary reflectors.
 *   jpvt: if JPVT(J)=K, then the J-th column of A*P was the the K-th 
 *         column of A.
 *   tau: the scalar factors of the elementary reflectors.
 *
 * return: 
 *   =  0: successful exit.
 *   = -i: the i-th argument had an illegal value.
 **********************************************************************/

int Cmat::qr_pivot(Cmat &tau, int *jpvt)
{
    const int rank = ((this->nrow) < (this->ncol)) ? (this->nrow) : (this->ncol); 

    if(! tau.is_vector())
        error("Cmat::qr(): tau must be a vector.\n");
    else if(tau.get_vec_length() != rank)
        error("Cmat::qr(): incompatible dimensions.\n"); 

    /* workspace query */
    int info, lwork = -1; 
    double tmp; 
    F77_CALL(dgeqp3)(&(this->nrow), &(this->ncol), 
            this->value, &(this->ld), jpvt, tau.get_value_pt(), 
            &tmp, &lwork, &info);
    lwork = (int)(tmp); 
    double *work = new double[lwork](); 

    for(int i = 0; i < this->ncol; i++) jpvt[i] = 0;
    F77_CALL(dgeqp3)(&(this->nrow), &(this->ncol), 
            this->value, &(this->ld), jpvt, tau.get_value_pt(), 
            work, &lwork, &info);
    delete[] work; 
    return(info);
}

/**********************************************************************
 * compute the Q-matrix in the QR-factorization of A (n-by-p matrix) 
 * Notice that it usually not necessary to compute Q explicitly 
 * we may use dormqr to multyply Q by an arbitray matrix 
 **********************************************************************/

int Cmat::qr_Q(Cmat &tau)
{
    const int rank = ((this->nrow) < (this->ncol)) ? (this->nrow) : (this->ncol); 

    if(! tau.is_vector())
        error("Cmat::qr_Q(): tau must be a vector.\n");
    else if(tau.get_vec_length() != rank)
        error("Cmat::qr_Q(): incompatible dimensions.\n"); 

    /* workspace query */
    int info, lwork = -1; 
    double tmp; 
    F77_CALL(dorgqr)(&(this->nrow), &(this->ncol), &(this->ncol), 
            this->value, &(this->ld), tau.get_value_pt(), 
            &tmp, &lwork, &info); 
    lwork = (int)(tmp); 
    double *work = new double[lwork](); 

    F77_CALL(dorgqr)(&(this->nrow), &(this->ncol), &(this->ncol), 
            this->value, &(this->ld), tau.get_value_pt(), 
            work, &lwork, &info); 
    delete[] work; 
    return(info); 
}


/* matrix C is replaced by Q * C, C * Q, Q' * C, C * Q' */
/* where Q is an orthogonal matrix */
/* interface to dormqr */
/* the input (qrm, tau) is the results of qr() */
        
int Cmat::qr_Q_mul(const char *side, const char *trans, Cmat &qrm, Cmat &tau) 
{
    if(! tau.is_vector())
        error("qr_Q_mul(): tau must be a vector.\n"); 
    if(qrm.get_ncol() != tau.get_vec_length())
        error("qr_Q_mul(): incompatible dimensions.\n"); 

    const int k = qrm.get_ncol(); 
    const int ld_qrm = qrm.get_ld(); 
    /* workspace query */
    int info, lwork = -1; 
    double tmp; 
    F77_CALL(dormqr)(side, trans, &(this->nrow), &(this->ncol), &k, 
                    qrm.get_value_pt(), &ld_qrm, tau.get_value_pt(), 
                    this->value, &(this->ld), 
                    &tmp, &lwork, &info FCONE FCONE); 
    lwork = (int)(tmp); 

    /* replace UT by UT * Q */ 
    double *work = new double[lwork](); 
    F77_CALL(dormqr)(side, trans, &(this->nrow), &(this->ncol), &k, 
                    qrm.get_value_pt(), &ld_qrm, tau.get_value_pt(), 
                    this->value, &(this->ld), 
                    work, &lwork, &info FCONE FCONE); 

    delete[] work; 
    return(info); 
}

/**********************************************************************
 * compute x = u * diag(d) * vt 
 * notice that it returns vt, not v 
 * 
 * x  ---  m-by-n matrix, contents will be destroyed during computing 
 * d  ---  min(m, n) array, singular values in descending order 
 * u  ---  m-by-min(m, n) matrix, min(m, n) columns of u
 * vt ---  min(m, n)-by-n matrix, min(m, n) rows of vt 
 * ldx, ldu, ldvt --- leading dimensions of x, u, and vt 
 * 
 * return info 
 *    <  0:  if INFO = -i, the i-th argument had an illegal value 
 *    = -4:  if A had a NAN entry 
 *    >  0:  DBDSDC did not converge, updating process failed 
 *    =  0:  successful exit 
 **********************************************************************/

int Cmat::svd0(Cmat &d, Cmat &u, Cmat &vt)
{
    const int mn = (((this->nrow) < (this->ncol))?(this->nrow):(this->ncol)); 

    if(! d.is_vector()) 
        error("Cmat::svd0(): d must be a vector.\n"); 
    else if(d.get_inc() != 1)
        error("Cmat::svd0(): d must be saved in continuous momery block.\n"); 
    else if(d.get_vec_length() != mn)
        error("Cmat::svd0(): incompatible dimensions - d.\n"); 

    if((u.get_nrow() != this->nrow) || (u.get_ncol() != mn))
        error("Cmat::svd0(): incompatible dimensions - u.\n"); 

    if((vt.get_nrow() != mn) || (vt.get_ncol() != this->ncol))
        error("Cmat::svd0(): incompatible dimensions - vt.\n"); 

    /* workspace query, use tmp to save the optimal lwork */
    int info; 
    int lwork = -1; 
    int *iwork = new int[8 * mn](); 
    double tmp; 
    const int ldu = u.get_ld();
    const int ldvt = vt.get_ld(); 
    F77_CALL(dgesdd)("S", 
                    &(this->nrow), &(this->ncol), 
                    this->value, &(this->ld), 
                    d.get_value_pt(), 
                    u.get_value_pt(), &ldu, 
                    vt.get_value_pt(), &ldvt, 
                    &tmp, &lwork, iwork, &info FCONE); 

    lwork = (int)(tmp); 
    double *work = new double[lwork](); 

    F77_CALL(dgesdd)("S", 
                    &(this->nrow), &(this->ncol), 
                    this->value, &(this->ld), 
                    d.get_value_pt(), 
                    u.get_value_pt(), &ldu, 
                    vt.get_value_pt(), &ldvt, 
                    work, &lwork, iwork, &info FCONE); 

    delete[] work; delete[] iwork; 
    return(info); 
}

int Cmat::svd(Cmat &d, Cmat &u, Cmat &vt)
{
    Cmat xcp(this->nrow, this->ncol); 
    xcp.copy(*this); 
    return( xcp.svd0(d, u, vt) ); 
}

/**********************************************************************
 * compute x = u * diag(d) * vt 
 * notice that it returns vt, not v 
 * similar to svd0(), but 
 *    1. compute all columns of u and all rows of vt
 *    2. the length of d can be either min(m, n) or max(m, n), append 0 
 * 
 * x  ---  m-by-n matrix, contents will be destroyed during computing 
 * d  ---  min(m, n) array, singular values in descending order 
 * u  ---  m-by-m matrix, all columns of u
 * vt ---  n-by-n matrix, all rows of vt 
 * ldx, ldu, ldvt --- leading dimensions of x, u, and vt 
 * 
 * return info 
 *    <  0:  if INFO = -i, the i-th argument had an illegal value 
 *    = -4:  if A had a NAN entry 
 *    >  0:  DBDSDC did not converge, updating process failed 
 *    =  0:  successful exit 
 **********************************************************************/


int Cmat::svda0(Cmat &d, Cmat &u, Cmat &vt)
{
    const int mn  = (((this->nrow) < (this->ncol)) ? (this->nrow) : (this->ncol)); 
    const int mnx = (((this->nrow) > (this->ncol)) ? (this->nrow) : (this->ncol)); 

    if(! d.is_vector()) 
        error("Cmat::svda0(): d must be a vector.\n"); 
    else if(d.get_inc() != 1)
        error("Cmat::svda0(): d must be saved in continuous momery block.\n"); 
    else if((d.get_vec_length() != mn) && (d.get_vec_length() != mnx))
        error("Cmat::svda0(): incompatible dimensions - d.\n"); 

    if((u.get_nrow() != this->nrow) || (u.get_ncol() != this->nrow))
        error("Cmat::svda0(): incompatible dimensions - u.\n"); 

    if((vt.get_nrow() != this->ncol) || (vt.get_ncol() != this->ncol))
        error("Cmat::svda0(): incompatible dimensions - vt.\n"); 

    /* set all values of d to be zero */
    d.set_zero(); 

    /* workspace query, use tmp to save the optimal lwork */
    int info; 
    int lwork = -1; 
    int *iwork = new int[8 * mn](); 
    double tmp; 
    const int ldu = u.get_ld();
    const int ldvt = vt.get_ld(); 
    F77_CALL(dgesdd)("A", 
                    &(this->nrow), &(this->ncol), 
                    this->value, &(this->ld), 
                    d.get_value_pt(), 
                    u.get_value_pt(), &ldu, 
                    vt.get_value_pt(), &ldvt, 
                    &tmp, &lwork, iwork, &info FCONE); 

    lwork = (int)(tmp); 
    double *work = new double[lwork](); 

    F77_CALL(dgesdd)("A", 
                    &(this->nrow), &(this->ncol), 
                    this->value, &(this->ld), 
                    d.get_value_pt(), 
                    u.get_value_pt(), &ldu, 
                    vt.get_value_pt(), &ldvt, 
                    work, &lwork, iwork, &info FCONE); 

    delete[] work; delete[] iwork; 
    return(info); 
}

int Cmat::svda(Cmat &d, Cmat &u, Cmat &vt)
{
    Cmat xcp(this->nrow, this->ncol); 
    xcp.copy(*this); 
    return( xcp.svda0(d, u, vt) ); 
}

/**********************************************************************
 * compute x = u * diag(d) * vt 
 * similar to svd0(), but only compute d
 * 
 * x  ---  m-by-n matrix, contents will be destroyed during computing 
 * d  ---  min(m, n) array, singular values in descending order 
 * ldx --- leading dimensions of x, u, and vt 
 * 
 * return info 
 *    <  0:  if INFO = -i, the i-th argument had an illegal value 
 *    = -4:  if A had a NAN entry 
 *    >  0:  DBDSDC did not converge, updating process failed 
 *    =  0:  successful exit 
 **********************************************************************/

int Cmat::svdn0(Cmat &d)  
{
    const int mn = (((this->nrow) < (this->ncol))?(this->nrow):(this->ncol)); 

    if(! d.is_vector()) 
        error("Cmat::svdn0(): d must be a vector.\n"); 
    else if(d.get_inc() != 1)
        error("Cmat::svdn0(): d must be saved in continuous momery block.\n"); 
    else if(d.get_vec_length() != mn)
        error("Cmat::svdn0(): incompatible dimensions - d.\n"); 

    /* workspace query, use tmp to save the optimal lwork */
    int info; 
    int lwork = -1; 
    int *iwork = new int[8 * mn](); 
    double tmp; 
    F77_CALL(dgesdd)("N", 
                    &(this->nrow), &(this->ncol), 
                    this->value, &(this->ld), 
                    d.get_value_pt(), 
                    nullptr, &(this->nrow), 
                    nullptr, &mn, 
                    &tmp, &lwork, iwork, &info FCONE); 

    lwork = (int)(tmp); 
    double *work = new double[lwork](); 

    F77_CALL(dgesdd)("N", 
                    &(this->nrow), &(this->ncol), 
                    this->value, &(this->ld), 
                    d.get_value_pt(), 
                    nullptr, &(this->nrow), 
                    nullptr, &mn, 
                    work, &lwork, iwork, &info FCONE); 

    delete[] work; delete[] iwork; 
    return(info); 
}

int Cmat::svdn(Cmat &d)                       
{
    Cmat xcp(this->nrow, this->ncol); 
    xcp.copy(*this); 
    return( xcp.svdn0(d) ); 
}

/**********************************************************************
 * calculate the 1st and kth eigenvalue and eigenvector of a symmetric matrix
 * interface to DSYEVR
 *
 * input:  x       --- n-by-n symmetric matrix
 * output: values  --- d-by-1 vectors, eigenvalues (ascending order)
 *         vectors --- n-by-d matrix, eigenvectors
 *         d       --- number of eigenvalues/eigenvectors identified 
 * 
 * return:
 *   =  0: successful exit
 *   = -i: the i-th argument had an illegal value
 *   >  0: internal error
 *
 * note: only lower triangle is used in calculation
 **********************************************************************/

int Cmat::eig0(Cmat &evalues, Cmat &evectors, int k, double tol)
{
    if(! this->is_square())
        error("Cmat::eig0(): must be a square matrix.\n"); 

    if(k > this->nrow)
        error("Cmat::eig0(): k cannot be larger than the order of the matrix.\n"); 

    if(! evalues.is_vector())
        error("Cmat::eig0(): evalues must be a vector.\n");
    else if(evalues.get_inc() != 1)
        error("Cmat::eig0(): evalues must be saved in a continuous memory block.\n"); 
    else if(evalues.get_vec_length() < k)
        error("Cmat::eig0(): the length of evalues is too small.\n"); 

    if(evectors.get_nrow() != this->nrow)
        error("Cmat::eig0(): incompatible dimensions.\n");
    else if(evectors.get_ncol() < k)
        error("Cmat::eig0(): the ncol of evectors is too small.\n");

    int d;   /* number of eigenvalues identified, should be k */

    const int ldA = evectors.get_ld();
    /* IL = the index of the smallest eigenvalue to be returned.*/ 
    const int il = (this->nrow) + 1 - (((this->nrow) > (k)) ? (k) : (this->nrow));  
    const int liwork = 10 * (this->nrow);
    int *isuppz = new int[2 * (this->nrow)]();
    int *iwork  = new int[10 * (this->nrow)]();

    double dd; /* for IL and IU, which are not needed when range = "V" */

    /* workspace query */
    int info;
    int lwork = -1; 
    F77_CALL(dsyevr)("V", "I", "L", 
            &(this->nrow), this->value, &(this->ld), 
            &dd, &dd, &il, &(this->nrow), &tol, 
            &d, evalues.get_value_pt(), evectors.get_value_pt(), &ldA, 
            isuppz, &dd, &lwork, iwork, &liwork, &info FCONE FCONE FCONE);

    lwork = (int)dd;
    double *work = new double[lwork]();

    F77_CALL(dsyevr)("V", "I", "L", 
            &(this->nrow), this->value, &(this->ld), 
            &dd, &dd, &il, &(this->nrow), &tol, 
            &d, evalues.get_value_pt(), evectors.get_value_pt(), &ldA, 
            isuppz, work, &lwork, iwork, &liwork, &info FCONE FCONE FCONE);

    if(d != k)
        warning("Cmat::eig0(): d != k.\n"); 

    delete[] isuppz; delete[] iwork; delete[] work;  
    return(info);
}

/* compute the first k eigenvalues/eigenvectors without destroying the matrix */

int Cmat::eig(Cmat &evalues, Cmat &evectors, int k, double tol)
{
    Cmat xcp(this->nrow, this->ncol); 
    xcp.copy(*this); 
    return( xcp.eig0(evalues, evectors, k, tol) );
}

/* compute all eigenvalues/eigenvectors */

int Cmat::eig(Cmat &evalues, Cmat &evectors, double tol)
{
    return( this->eig(evalues, evectors, this->nrow, tol) );
}

/**********************************************************************
 * THE END
 **********************************************************************/
