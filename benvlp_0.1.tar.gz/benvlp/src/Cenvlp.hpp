/**********************************************************************
 * Class for envelope model   
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 * updated: 2024-04-14 (propose_Amat)
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CENVLP__HPP__ 
#define __ZP__CENVLP__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "Cmat.hpp"
#include "distribution.hpp"

class Cenvlp {
    public: 
        int u_dim;             /* dimension u */
        Cmat *A;               /* (r-u)-by-u matrix */
        Cmat *U;               /* r-by-r matrix */
        Cmat *Gamma;           /* r-by-u matrix */
        Cmat *Gamma0;          /* r-by-(r-u) matrix */

        Cmat *hyper_Amat_Mmat;       /* r-by-r matrix  --  hyperparameter in prior */ 
        double pro_Amat_sigma2;      /* scalar -- hyperparameter in proposal distribution */
        int A_count;                 /* count the number of accepted Amat */

        Cenvlp(); 
        Cenvlp(int r, int u, Cmat *Umat = nullptr); 
        ~Cenvlp(); 

        /**************************************************************
         * get or set values   
         **************************************************************/

        /* compute A corresponding to the column space of Z */
        /* Z is destroyed on exit */
        void compute_Amat(Cmat &Z);   
        /* compute Gamma and Gamma0 from A */
        void compute_Gammas();              
        /* compute Sigma = Gamma * Omega * Gamma' + Gamma0 * Omega0 * Gamma0' */
        void Sigma_restore(Cmat &Sigma, Cmat &Omega, Cmat &Omega0);    
        /* compute beta = Gamma * eta */
        void beta_restore(Cmat &beta, Cmat &eta); 

        /* propose a new Amat */
        void propose_Amat(); 

        /* propose a new Amat from multivariate normal distribution */
        void propose_Amat_normal(); 
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
