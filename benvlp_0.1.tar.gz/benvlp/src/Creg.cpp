/**********************************************************************
 * Class for regression  
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 **********************************************************************/

#include <R.h> 

#include "Creg.hpp" 

/**********************************************************************
 * variables defined in Creg: (5)
 *     Cmat *x;                     predictor - p-by-n matrix 
 *     Cmat *y;                     response - r-by-n matrix 
 *     int n_obs;                   number of observations 
 *     int p_var;                   number of predictors 
 *     int r_resp;                  number of responses 
 **********************************************************************/

Creg::Creg()
{
    this->x = nullptr; 
    this->y = nullptr; 
    this->n_obs  = 0; 
    this->p_var  = 0; 
    this->r_resp = 0; 
} 
        
Creg::Creg(Cmat *x_pt, Cmat *y_pt)
{
    this->x = x_pt; 
    this->y = y_pt; 
    this->n_obs  = y_pt->get_ncol(); 
    this->p_var  = x_pt->get_nrow(); 
    this->r_resp = y_pt->get_nrow(); 

    if((this->n_obs) != x_pt->get_ncol())
        error("Creg(): x and y have different number of columns.\n"); 
} 

/**********************************************************************
 * destructor 
 **********************************************************************/

Creg::~Creg() 
{
} 

/**********************************************************************
 * write the information of this regression problem 
 **********************************************************************/

void Creg::write2stream(std::ostream &stream)  
{
    stream << "\nnumber of observations = " << this->n_obs << std::endl; 
    stream << "number of responses = " << this->r_resp << std::endl; 
    stream << "number of predictors = " << this->p_var << std::endl; 

    stream << "\nThe first observation is:\n";
    stream << "y = (" << this->y->get_entry(0, 0); 
    for(int k = 1; k < (this->r_resp); k++) stream << ", " << this->y->get_entry(k, 0);
    stream << ")\n";
    stream << "x = (" << this->x->get_entry(0, 0); 
    for(int j = 1; j < (this->p_var); j++) stream << ", " << this->x->get_entry(j, 0);
    stream << ")\n";

    stream << "\nThe last observation is:\n";
    stream << "y = (" << this->y->get_entry(0, this->n_obs - 1); 
    for(int k = 1; k < (this->r_resp); k++) stream << ", " << this->y->get_entry(k, this->n_obs - 1);
    stream << ")\n";
    stream << "x = (" << this->x->get_entry(0, this->n_obs - 1); 
    for(int j = 1; j < (this->p_var); j++) stream << ", " << this->x->get_entry(j, this->n_obs - 1);
    stream << ")\n";
}

/**********************************************************************
 * THE END
 **********************************************************************/
