/**********************************************************************
 * compute log-density 
 * updated: 2025-10-26
 **********************************************************************/

#include <R.h>

/**********************************************************************
 * log-density -- normal distribution      
 **********************************************************************/

void log_dnorm_API(const double *x, const double *mu, const double *sd, double *ans);
void log_dnorm_vec_API(const int *p, double *x, double *mu, double *Sigma, double *ans);
void log_dnorm_mat_API(const int *m, const int *n, double *x, double *mu, 
    double *Sigma1, double *Sigma2, double *ans);

/**********************************************************************
 * log-density -- t distribution  
 **********************************************************************/

void log_dt_API(const double *x, const double *nu, const double *mu, const double *sd, double *ans);
void log_dt_vec_API(const int *p, double *x, double *nu, double *mu, double *Sigma, double *ans);
void log_dt_mat_API(const int *m, const int *n, double *x, double *nu, double *mu, 
    double *Sigma1, double *Sigma2, double *ans);

/**********************************************************************
 * THE END
 **********************************************************************/

