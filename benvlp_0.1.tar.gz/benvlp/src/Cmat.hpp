/**********************************************************************
 * Class for matrices and vectors 
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28
 * updated: 2024-11-29 (is_identity, copy_T, qr_Q_mul)
 * updated: 2025-04-12 (as_row, as_col, as_block, kron, value_pt_shift)
 * updated: 2025-04-12 (rowScale, colScale, colCenter)
 * updated: 2025-04-14 (sum, trace, as_diag)
 * updated: 2025-04-16 (Rversion, R_Calloc and R_Free)
 * updated: 2025-04-19 (as_reshape, copy_diag, as_diag)
 * updated: 2025-05-09 (inv_chol) 
 * updated: 2025-05-21 (prod, sumlog, entry_square, entry_sqrt, entry_reciprocal)
 * updated: 2025-05-22 (var2cor, cor2var, var2cor_inv)
 * updated: 2025-10-16 (inc_entry, inc_entry_vec, scale_entry, scale_entry_vec,
 *                      rowSums_w, rowMeans_w, colSums_w, colMeans_w)
 * updated: 2025-10-22  
 * updated: 2025-10-29 (mean, var, sd)
 * updated: 2025-11-09 (ger, ger_col, ger_row)
 * updated: 2025-11-25 (svdn0, svdn, logdet_IAtA_chol, logdet_IAtA_svd)
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CMAT__HPP__ 
#define __ZP__CMAT__HPP__ 

#include <R.h> 
#include <Rversion.h>
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include <fstream>
#include <iostream>
#include <iomanip>

#if R_VERSION >= R_Version(4, 5, 0)
#define Calloc R_Calloc 
#define Free R_Free 
#endif 

class Cmat {
    protected: 
        int nrow;              /* number of rows */
        int ncol;              /* number of columns */
        int ld;                /* leading dimension */
        int length;            /* length = ld * ncol - (ld - nrow) */
        double *value;         /* values */
        bool is_allocated;     /* true = allocated, false = assigned */

        int inc;               /* increment when it is a vector */
        int vec_length;        /* length as a vector */

    public: 
        Cmat(); 
        Cmat(int n_row, int n_col); 
        Cmat(int n_row, int n_col, int n_ld); 
        Cmat(int n_row, int n_col, double *pt_values); 
        Cmat(int n_row, int n_col, double *pt_values, int n_ld); 
        ~Cmat(); 

        void set_derived();    /* set derived variables in the constructor */

        /**************************************************************
         * get or set values   
         **************************************************************/

        int get_nrow();
        int get_ncol(); 
        int get_ld(); 
        int get_length(); 
        int get_inc(); 
        int get_vec_length(); 

        double get_entry(int row, int col); 
        double get_entry_vec(int i); 
        double *get_value_pt(); 

        void set_entry(int row, int col, double a); 
        void set_entry_vec(int i, double a); 
        void set_value_pt(double *pt_values); 

        void inc_entry(int row, int col, double a); 
        void scale_entry(int row, int col, double a); 
        void inc_entry_vec(int i, double a); 
        void scale_entry_vec(int i, double a); 

        /**************************************************************
         * write matrix to a text file  
         **************************************************************/

        void write2stream(std::ostream &stream, bool details = true); 
        void write2file(const char *filename);     /* write to a new file */
        void write2file_app(const char *filename); /* append to an existing file */

        /**************************************************************
         * basic matrix operations  
         **************************************************************/

        void copy(const double *pt_values);     /* values are saved in a contiguous memory block */
        void copy_mem(const double *pt_values); /* directly copy a contiguous memory block without checking */        
        void copy(Cmat &A);                     /* copy values from an existing matrix */
        void copy_T(Cmat &A);                   /* get transpose A' */
        void copy_diag(Cmat &A);                /* copy the diagonal of A */
        
        /* write matrix to a contiguous memory block of length size */
        void write(double *pt_values, int size);      
        /* directly write matrix to a contiguous memory block of length size without checking*/
        void write_mem(double *pt_values, int size);  

        void complete_tri_upper();    /* complete the upper-triangular by symmetry */
        void complete_tri_lower();    /* complete the lower-triangular by symmetry */

        void set_zero();                            /* set all values as zero */ 
        void set_const(double a);                   /* set all values to be a constant */
        void set_identity(double a = 1.0);          /* set identity matrix */
        void set_cs(double on, double off);         /* set on-diag = on and off-diag = off */

        bool is_scalar();   /* check whether it is a scalar */
        bool is_vector();   /* check whether it is a vector */
        bool is_square();   /* check whether it is a square matrix */
        bool is_identity(double tol = 1e-7); /* check whether it is a identity matrix */

        void as_row(Cmat &A, int i);          /* set it as the i-th row of A */
        void as_col(Cmat &A, int j);          /* set it as the j-th col of A */
        void as_block(Cmat &A, int i, int j); /* set it as the block matrix starting at (i, j) */
        void as_diag(Cmat &A);                /* set it as the vector containing diagonal entries of A */ 
        void as_reshape(Cmat &A);             /* set it as the reshaped matrix A */
        void value_pt_shift(int offset);      /* shift the pointer to value by offset */

        /**************************************************************
         * selected BLAS functions  
         *
         * matrix types:  
         *    GE - GEneral matrix 
         *    SY - SYmmetric matrix 
         *    TR - TRiangular matrix 
         *
         * character arguments 
         *    trans - N (no transpose), T (transpose)
         *    uplo  - U (upper triangular), L (lower triangular)
         *    diag  - N (non-unit triangular), U (unit triangular)
         *    side  - L (left), R (right) 
         **************************************************************/

        /* compute dot-product: x' * y or sum(x * y) */
        /* interface to ddot */
        double dot(Cmat &x); 

        /* compute sum of squared entries: x' * x or sum(x * x) */
        /* interface to ddot with extension */
        /* works for both vectors and matrices */
        double sum_sq(); 

        /* compute Euclidean norm */
        /* interface to dnrm2 */
        double nrm2(); 

        /* compute sum of absolute values sum(abs(x)) */
        /* interface to dasum */
        double asum(); 

        /* y := a * x + y */
        /* interface to daxpy with extension */
        /* works for both vectors and matrices */
        void axpy(double a, Cmat &x); 

        void axpy_row(double a, Cmat &x);   /* apply axpy to each row of the matrix */
        void axpy_col(double a, Cmat &x);   /* apply axpy to each column of the matrix */

        /* y = a * A * x + b * y, y := a * A^T * x + b * y */
        /* interface to dgemv for matrix-vector multiplication */
        void gemv(const char *trans, double a, Cmat &A, Cmat &x, double b); 
        void symv(); 

        /* x = A * x, x = A^T * x */
        /* interface to dtrmv for matrix-vector multiplication */
        void trmv(const char *uplo, const char *trans, const char *diag, Cmat &A); 

        /* x = A^{-1} * x, x = A^{-T} * x */
        /* interface to dtrsv for triangular matrix A */
        void trsv(const char *uplo, const char *trans, const char *diag, Cmat &A); 

        /* A = a * x * t(y) */
        /* interface to dger */
        void ger(double a, Cmat &x, Cmat &y);
        /* apply dger to columns of x and y */
        void ger_col(Cmat &s, Cmat &x, Cmat &y);
        /* apply dger to rows of x and y */
        void ger_row(Cmat &s, Cmat &x, Cmat &y);  

        /* A = a * x * x^T + A */
        /* interface to dsyr for symmetric matrix */
        void syr(const char *uplo, double a, Cmat &x); 

        /* x = x + U * Lambda * U' */ 
        /* Lambda = diag(s) is a diagonal matrix  */
        /* apply dsyr to columns of U */
        void syr_col(const char *uplo, Cmat &s, Cmat &U);

        /* x = x + U' * Lambda * U */
        /* Lambda = diag(s) is a diagonal matrix  */
        /* apply dsyr to rows of U */
        void syr_row(const char *uplo, Cmat &s, Cmat &U); 

        void syr2(); 

        /* C := a * op(A) * op(B) + b * C, op(X) = X or X^T */
        /* interface to dgemm for matrix-matrix multiplication */
        void gemm(const char *transA, const char *transB, double a, Cmat &A, Cmat &B, double b); 
        void symm(); 

        /* C := a * A * A^T + b * C, C := a * A^T * A + b * C */
        /* interface to dsyrk */
        void syrk(const char *uplo, const char *trans, double a, Cmat &A, double b); 
        
        void syr2k(); 

        /* B := a * op(A) * B, B := a * B * op(A), op(A) = A or A^T */
        /* interface to dtrmm for triangular matrix A */
        void trmm(const char *side, const char *uplo, const char *trans, const char *diag, double a, Cmat &A); 

        /* B := a * op(A^{-1}) * B, B := a * B * op(A^{-1}), op(A) = A or A^T */
        /* interface to dtrsm for triangular matrix A */
        void trsm(const char *side, const char *uplo, const char *trans, const char *diag, double a, Cmat &A);  

        /**************************************************************
         * more matrix operations  
         **************************************************************/

        void add(double a);       /* add a constant to each entry */     
        void scale(double a);     /* multiply each entry by a constant */
        void entry_square();      /* square each entry */
        void entry_sqrt();        /* square root each entry */
        void entry_reciprocal();  /* reciprocal of each entry */

        double sum();             /* compute sum of all values: sum(x) */
        double mean();            /* compute mean of all values: mean(x) */
        double var();             /* compute var of all values: var(x) */
        double sd();              /* compute sd of all values: sd(x) */
        double trace();           /* compute trace of a matrix: sum(diag(x)) */
        double prod();            /* compute product of all values: prod(x) */ 
        double sumlog();          /* compute log sum of all values: sum(log(x)) */
        
        void rowSums(Cmat &A);    /* compute sum for each row of A */
        void rowMeans(Cmat &A);   /* compute mean for each row of A */
        void colSums(Cmat &A);    /* compute sum for each column of A */
        void colMeans(Cmat &A);   /* compute mean for each column of A */

        void rowSums_w(Cmat &A, Cmat &w);    /* compute weighted sum for each row of A */
        void rowMeans_w(Cmat &A, Cmat &w);   /* compute weighted mean for each row of A */
        void colSums_w(Cmat &A, Cmat &w);    /* compute weighted sum for each column of A */
        void colMeans_w(Cmat &A, Cmat &w);   /* compute weighted mean for each column of A */

        void rowCenter(Cmat &mean);  /* center each row by subtracting mean */
        void colCenter(Cmat &mean);  /* center each col by subtracting mean */
        void rowScale(Cmat &sd);     /* scale each row by dividing sd */
        void colScale(Cmat &sd);     /* scale each col by dividing sc */

        void var2cor(Cmat &dvec);    /* convert variance matrix to correlation, extract SDs */
        void cor2var(Cmat &dvec);    /* compute variance from correlation */
        void var2cor_inv(Cmat &dinv); /* var_inv instead of var and dinv = 1/dvec */ 

        void kron(Cmat &A, Cmat &B); /* kronecker product of A and B */

        /* compute x' * A * x */
        /* A is a symmetric matrix and only the lower-triangular is used */
        double quadr(Cmat &x);             
        /* compute x' * A * y */
        double quadr2(Cmat &x, Cmat &y);   

        /* C := a * A * B * A' + b * C  */
        void ABAt(double a, Cmat &A, Cmat &B, double b);  
        /* C := a * A' * B * A + b * C */
        void AtBA(double a, Cmat &A, Cmat &B, double b); 

        /* B := a * A^{-1} * B, B := a * B * A^{-1} */
        /* input Achol is the chol of A (low-triangular) */
        void solve_chol_left (Cmat &Achol, double a = 1.0); 
        void solve_chol_right(Cmat &Achol, double a = 1.0); 

        /* compute log-determinant of a positive definite matrix by Cholesky factorization */
        double logdet_chol(); 
        /* compute log-determinant of (I + A' * A) by Cholesky factorization */
        double logdet_IAtA_chol(); 
        /* compute log-determinant of (I + A' * A) by SVD */
        double logdet_IAtA_svd(); 

        /**************************************************************
         * linear algebra 
         **************************************************************/

        /* compute Cholesky factorization: x = L * L' */
        /* L is a lower-triangular matrix */
        /* interface to dpotrf */
        int chol(); 

        /* restore the matrix from its Cholesky factorization */
        /* update the upper-triangular components */
        /* then complete the matrix by symmetry */
        void chol_restore();   

        /* compute the LU factorization of m-by-n matrix A */
        /* interface to dgetrf */
        /* ipiv --- integer array of size min(m, n) */
        int lu(int *ipiv);

        /* compute the inverse of a general square matrix by LU-factorization */
        int inv(); 

        /* compute the inverse of a square matrix by Cholesky factorization */
        /* the current matrix is already the result of chol() */
        /* it is an interface to dpotri() */
        int inv_chol(); 

        /* compute QR factorization: x = QR */
        /* interface to dgeqrf for qr() */
        /* interface to  dgeqp3 for qr_pivot() */
        int qr(Cmat &tau);        
        int qr_pivot(Cmat &tau, int *jpvt);  /* length(jpvt) == ncol */

        /* compute the Q-matrix from a QR-factorization */
        /* interface to dorgqr */
        int qr_Q(Cmat &tau);     

        /* matrix C is replaced by Q * C, C * Q, Q' * C, C * Q' */
        /* where Q is an orthogonal matrix */
        /* interface to dormqr */
        /* the input (qrm, tau) is the results of qr() */
        int qr_Q_mul(const char *side, const char *trans, Cmat &qrm, Cmat &tau); 

        /* compute singular value decomposition: x = u * diag(d) * vt */
        /* interface to dgesdd */
        /* svd0() will destroy the current matrix */
        /* svd() create a copy of the current matrix and then call svd0() */
        int svd0(Cmat &d, Cmat &u, Cmat &vt);    
        int svd(Cmat &d, Cmat &u, Cmat &vt);    /* call svd0() */

        /* compute singular value decomposition: x = u * diag(d) * vt */
        /* interface to dgesdd */
        /* similar to svd0(), but */
        /*    1. compute all columns of u and all rows of vt */
        /*    2. the length of d can be either min(m, n) or max(m, n), append 0  */
        /* svda0() will destroy the current matrix */
        /* svda() create a copy of the current matrix and then call svda0() */
        int svda0(Cmat &d, Cmat &u, Cmat &vt);    
        int svda(Cmat &d, Cmat &u, Cmat &vt);    /* call svda0() */

        /* compute singular value decomposition: x = u * diag(d) * vt */
        /* interface to dgesdd */
        /* similar to svd0(), but only compute d */
        /* svdn0() will destroy the current matrix */
        /* svdn() create a copy of the current matrix and then call svdn0() */
        int svdn0(Cmat &d);    
        int svdn(Cmat &d);                       /* call svdn0() */

        /* compute spectral decomposition for eigenvalues/eigenvectors */
        /* interface to dsyevr */
        /* compute the 1st to the k-th largest eigenvalues/eigenvectors */
        /* the values are sorted in ascending order, so the last one is the largest */
        /* note: dsyevr actually compute the (n+1-k)th to the n-th smallest eigenvalues */
        /* eig0() will destroy the current matrix */
        /* eig() create a copy of the current matrix and then call eig0() */
        /* eig() without the argument k will compute all eigenvalues */
        int eig0(Cmat &evalues, Cmat &evectors, int k, double tol = 1e-7);
        int eig(Cmat &evalues, Cmat &evectors, int k, double tol = 1e-7);  
        int eig(Cmat &evalues, Cmat &evectors, double tol = 1e-7);    
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
