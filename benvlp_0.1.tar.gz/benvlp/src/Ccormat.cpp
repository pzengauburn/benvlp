/**********************************************************************
 * Class for correlation matrix   
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 **********************************************************************/

#include <R.h> 

#include <string.h>
#include "Ccormat.hpp"

/**********************************************************************
 * constructor  
 *
 * list of variables: (3)
 *       int order;                 order of the matrix 
 *       Corr_Type type;            type of correlation matrix 
 *       double rho;                parameter 
 **********************************************************************/

Ccormat::Ccormat()
{
    this->order = 5; 
    this->type = Corr_Type::iid; 
    this->rho = 0.0; 
}

Ccormat::Ccormat(int p, Corr_Type ctype, double param)
{
    this->order = p; 
    this->type = ctype; 
    this->rho = param; 
}

/**********************************************************************
 * destructor  
 **********************************************************************/

Ccormat::~Ccormat()
{
}

/**********************************************************************
 * get or set values 
 **********************************************************************/

int Ccormat::get_order()
{
    return(this->order); 
} 

Corr_Type Ccormat::get_type()
{
    return(this->type);
} 

double Ccormat::get_rho()
{
    return(this->rho); 
} 

/**********************************************************************
 * more functions
 **********************************************************************/

/* determinant of the correlation matrix */

double Ccormat::det()
{
    return(this->logdet()); 
}     

/* log-determinant of the correlation matrix */

double Ccormat::logdet()
{
    double ans = 0.0; 

    if(this->type == Corr_Type::iid)
    {
        ans = 0.0; 
    }
    else if(this->type == Corr_Type::cs)
    {
        /**************************************************************
         * log determinant of a correlation matrix: CS(rho)
         *    (p - 1) * log(1 - rho) + log(1 - rho + p * rho)
         **************************************************************/

        const double p = (double)(this->order); 
        ans = ((p - 1.0) * log(1.0 - (this->rho)) 
                + log(1.0 - (this->rho) + (this->rho) * p));
    }
    else if(this->type == Corr_Type::ar1)
    {
        /**************************************************************
         * log determinant of a correlation matrix: AR1(rho)
         *    (p - 1) * log(1 - rho * rho)
         **************************************************************/

        const double p = (double)(this->order);
        ans = ((p - 1.0) * log(1.0 - (this->rho) * (this->rho)));
    }
    else 
        error("Ccormat::logdet(): unsupported correlation type.\n"); 
    
    return(ans); 
}

/* create the correlation matrix */

void Ccormat::set_mat(Cmat &Rmat) 
{
    const int p = (this->order); 
    if((Rmat.get_nrow() != p) || (Rmat.get_ncol() != p))
        error("Ccormat::set_mat(): incompatible dimension.\n"); 

    if(this->type == Corr_Type::iid)
    {
        Rmat.set_identity(); 
    }
    else if(this->type == Corr_Type::cs)
    {
        Rmat.set_cs(1.0, this->rho);  /* set 1.0 on diagonal and rho off diagonal */
    }
    else if(this->type == Corr_Type::ar1)
    {
        double *values = Rmat.get_value_pt(); 
        const int ldR = Rmat.get_ld(); 

        /* on diagonal */
        for(int i = 0; i < p; i++) values[i + i * ldR] = 1.0; 

        /* off-diagonal */
        double value = 1.0; 
        for(int i = 1; i < p; i++)
        {
            value *= rho; 
            for(int j = i, count = 0; count < p - i; j+=(ldR+1), count++)
            {
                values[j] = value; 
                values[j + i * (ldR-1)] = value; 
            } 
        }
    }
    else 
        error("Ccormat::set_mat(): unsupported correlation type.\n"); 
}     

/* create the inverse of the correlation matrix */

void Ccormat::set_mat_inv(Cmat &Rinv)  
{
    const int p = this->order; 
    if((Rinv.get_nrow() != p) || (Rinv.get_ncol() != p))
        error("Ccormat::set_mat_inv(): incompatible dimension.\n"); 

    if(this->type == Corr_Type::iid)
    {
        Rinv.set_identity(); 
    }
    else if(this->type == Corr_Type::cs)
    {
        double b = -(this->rho) / (1.0 - (this->rho)) / (1.0 + ((double)(p) - 1.0) * (this->rho));
        double a = b + 1.0 / (1.0 - (this->rho));

        Rinv.set_cs(a, b);    /* set a on diagonal and b off diagonal */
    }
    else if(this->type == Corr_Type::ar1)
    {
        double b = (this->rho) / ((this->rho) * (this->rho) - 1.0);   /* tri-diagonal */
        double a = 1.0 - (this->rho) * b;            /* Rmat[0, 0] and Rinv[p-1, p-1] */
        double c = 1.0 - 2.0 * (this->rho) * b;      /* on diagonal */

        double *values = Rinv.get_value_pt(); 
        const int ldR = Rinv.get_ld(); 

        Rinv.set_zero();                     /* set all values as zero */
        values[0] = a;                       /* first column: Rinv[1, 1] = a */
        values[1] = b;                       /* first column: Rinv[2, 1] = b */
        values[p - 2 + (p - 1) * ldR] = b;   /* last column:  Rinv[p-1, p] = b */
        values[p - 1 + (p - 1) * ldR] = a;   /* last column:  Rinv[p, p] = a */
    
        /* remaining columns */
        for(int i = 1; i < p-1; i++)
        {
            values[i + i * ldR] = c; 
            values[i - 1 + i * ldR] = b; 
            values[i + 1 + i * ldR] = b; 
        }
    }
    else 
        error("Ccormat::set_mat_inv(): unsupported correlation type.\n"); 
}  

/**********************************************************************
 * THE END
 **********************************************************************/
