/**********************************************************************
 * Class for Bayesian inference for multivariate linear regression  
 * with repeated measures and envelope structure 
 * Peng Zeng @ Auburn University  
 * updtaed: 2025-04-19
 * updated: 2025-10-22  
 **********************************************************************/

#include <R.h> 
#include "CBmlmRM_envlp.hpp" 
#undef beta 

/**********************************************************************
 * variables defined in Creg: (5) 
 *     Cmat *x;                     predictor - p-by-n matrix 
 *     Cmat *y;                     response - r-by-n matrix 
 *     int n_obs;                   number of observations 
 *     int p_var;                   number of predictors 
 *     int r_resp;                  number of responses 
 *
 * variables defined in Clinreg: (4) 
 *     bool has_intercept;          true = with intercept, false = no intercept 
 *     Cmat *alpha;                 intercept - r-by-1 matrix 
 *     Cmat *beta;                  slope - r-by-p matrix 
 *     Cmat *res;                   residual - r-by-n matrix 
 * 
 * variables defined in ClinregRM: (9)
 *     int m_sub;                   number of subjects 
 *     int Jmax;                    max(Jvec) 
 *     Cimat *Jvec;                 number of observations for each subject, length = m_sub 
 *     Corr_Type ctype;             correlation structure 
 *     double rho;                  parameter in correlation 
 *     Cmat *Sigma_inv;             r-by-r matrix 
 *     Cmat *deltaRM;               msub-by-1 matrix 
 *     double pro_rho_delta;        scalar - tuning parameter 
 *     int rho_count;               count the number of accepted rho 
 *
 * variables defined in Cmcmc: (13) 
 *     int burn_in_mcmc;            number of samples to be discarded 
 *     int size_mcmc;               number of samples after burn-in period 
 *     int thinning_mcmc;           save every k-th samples 
 *     int info_mcmc;               display information every k samples 
 *     int count_mcmc;              total number of samples generated 
 *     int count_output_mcmc;       number of samples saved 
 *     int length_pars;             length of parameters, including latent variables 
 *     double *pars;                vector of parameters, length = length_pars 
 *     int max_saved_draws;         maximum number of saved samples 
 *     int length_saved_pars;       length of parameters to be saved 
 *     double *samples;             space to save samples = max_saved_draws * length_saved_pars 
 *     int length_hyperpars;        number of hyperparameters in prior distribution 
 *     int length_tuning;           number of tuning parameters in proposal distribution
 *
 * variables defined in Cenvlp: (8)
 *     int u_dim;                   dimension u 
 *     Cmat *A;                     (r-u)-by-u matrix 
 *     Cmat *U;                     r-by-r matrix 
 *     Cmat *Gamma;                 r-by-u matrix 
 *     Cmat *Gamma0;                r-by-(r-u) matrix 
 *     Cmat *hyper_Amat_Mmat;       r-by-r matrix  --  hyperparameter in prior  
 *     double pro_Amat_sigma2;      scalar -- hyperparameter in proposal distribution 
 *     int A_count;                 count the number of accepted Amat 
 *
 * variables defined in CBmlmRM_envlp: (9)
 *     Cmat *eta;                   u-by-p matrix 
 *     Cmat *Omega_inv;             u-by-u matrix 
 *     Cmat *Omega0_inv;            (r-u)-by-(r-u) matrix 
 *     Cmat *hyper_eta_mean;        r-by-p matrix  --  hyper-parameter in prior  
 *     Cmat *hyper_eta_col_inv;     p-by-p matrix  --  hyper-parameter in prior
 *     double hyper_Omega_df;       scalar  --  hyperparameter in prior 
 *     Cmat *hyper_Omega_scale;     u-by-u matrix  --  hyperparameter in prior  
 *     double hyper_Omega0_df;      scalar  --  hyperparameter in prior  
 *     Cmat *hyper_Omega0_scale;    (r-u)-by-(r-u) matrix  --  hyperparameter in prior  
 **********************************************************************/

CBmlmRM_envlp::CBmlmRM_envlp()
{
    this->eta = nullptr;
    this->Omega_inv = nullptr;
    this->Omega0_inv = nullptr; 
    this->hyper_eta_mean = nullptr;
    this->hyper_eta_col_inv = nullptr;
    this->hyper_Omega_df = 0.0;
    this->hyper_Omega_scale = nullptr;
    this->hyper_Omega0_df = 0.0;
    this->hyper_Omega0_scale = nullptr;
}

CBmlmRM_envlp::CBmlmRM_envlp(Cmat *x_pt, Cmat *y_pt, int u, Cimat *Jvec_pt, Corr_Type cp,
                int burn_in, int size, int thinning, int info, int length,
                Cmat *Umat)
    : ClinregRM(x_pt, y_pt, true, Jvec_pt, cp),
      Cmcmc(burn_in, size, thinning, info, length), 
      Cenvlp(y_pt->get_nrow(), u, Umat)   
{
    /* parameters = (rho, alpha, eta, A, Omega_inv, Omega0_inv) */
    /* length = 1 + r + u * p + (r-u) * u + u * u + (r - u) * (r - u) */
    this->length_pars =  1                                                                       /* rho (1) */
                        + (this->r_resp)                                                         /* alpha (r-by-1) */
                        + (this->u_dim) * (this->p_var)                                          /* eta (u-by-p) */                                    
                        + ((this->r_resp) - (this->u_dim)) * (this->u_dim)                       /* Amat ((r-u)-by-u) */
                        + (this->u_dim) * (this->u_dim)                                          /* Omega_inv (u-by-u) */
                        + ((this->r_resp) - (this->u_dim)) * ((this->r_resp) - (this->u_dim));   /* Omega0_inv ((r-u)-by-(r-u)) */

    if(length < (this->length_pars)) 
    {
        std::cout << "length = " << length << std::endl;
        std::cout << "length_pars = " << this->length_pars << std::endl; 
        error("CBmlmRM_envlp::CBmlmRM_envlp(): incorrect number of parameters.\n"); 
    }

    this->eta = new Cmat(this->u_dim, this->p_var, nullptr); 
    this->Omega_inv = new Cmat(this->u_dim, this->u_dim, nullptr);
    this->Omega0_inv = new Cmat((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim), nullptr);

    /* link the parameters to the space allocated in Cmcmc */    
    int offset = 1;                                       /* the first one is rho */          
    this->alpha->set_value_pt(this->pars + offset);
    offset += (this->r_resp); 
    this->eta->set_value_pt(this->pars + offset);
    offset += (this->u_dim) * (this->p_var); 
    this->A->set_value_pt(this->pars + offset); 
    offset += ((this->r_resp) - (this->u_dim)) * (this->u_dim); 
    this->Omega_inv->set_value_pt(this->pars + offset); 
    offset += (this->u_dim) * (this->u_dim); 
    this->Omega0_inv->set_value_pt(this->pars + offset); 

    /* cache calculation results */
    delete this->beta;  /* release the current memory */
    this->beta = new Cmat(this->r_resp, this->p_var); 

    delete this->Sigma_inv; /* release the current memory */
    this->Sigma_inv = new Cmat(this->r_resp, this->r_resp);

    this->hyper_eta_mean = new Cmat(this->r_resp, this->p_var);
    this->hyper_eta_col_inv = new Cmat(this->p_var, this->p_var);
    this->hyper_Omega_scale = new Cmat(this->u_dim, this->u_dim);     
    this->hyper_Omega0_scale = new Cmat((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim));   

    this->hyper_Omega_df = 0.0;
    this->hyper_Omega0_df = 0.0;

    /* length of all hyper-parameters in prior distributions combined */ 
    this->length_hyperpars = ((this->hyper_eta_mean->get_length())         /* beta_mean (r-by-p) */
                            + (this->hyper_eta_col_inv->get_length())      /* best_col_inv (p-by-p) */
                            + 1                                            /* Omega_df (1) */
                            + (this->hyper_Omega_scale->get_length())      /* Omega_scale (u-by-u) */
                            + 1                                            /* Omega0_df (1) */
                            + (this->hyper_Omega0_scale->get_length())     /* Omega0_scale ((r-u)-by-(r-u)) */
                            + (this->hyper_Amat_Mmat->get_length()));      /* Mat (r-by-r) */

    /* length of all hyper-parameters in proposal distributions combined */ 
    this->length_tuning = 2;                                               /* rho.delta and Pmat.sigma2 */
}

/**********************************************************************
 * destructor 
 **********************************************************************/

CBmlmRM_envlp::~CBmlmRM_envlp() 
{
    delete this->eta; 
    delete this->Omega_inv; 
    delete this->Omega0_inv; 

    delete this->hyper_eta_mean;
    delete this->hyper_eta_col_inv;
    delete this->hyper_Omega_scale; 
    delete this->hyper_Omega0_scale; 
} 

/**********************************************************************
 * set parameters  
 **********************************************************************/

void CBmlmRM_envlp::set_ini_pars(int length, double *pt) 
{
    if(((this->length_pars) != length))
        error("CBmlmRM_envlp::set_ini(): incorrect dimension.\n"); 

    int offset = 0; 
    this->rho = pt[offset]; 
    offset ++; 

    this->alpha->copy(pt + offset); 
    offset += this->alpha->get_length(); 

    this->eta->copy(pt + offset); 
    offset += this->eta->get_length(); 

    this->A->copy(pt + offset);
    offset += this->A->get_length(); 

    this->Omega_inv->copy(pt + offset); 
    offset += this->Omega_inv->get_length(); 

    this->Omega0_inv->copy(pt + offset);
}

void CBmlmRM_envlp::set_hyperpars(int length, double *pt) 
{
    if((this->length_hyperpars) != length) 
    {
        std::cout << "length_hyperpars = " << this->length_hyperpars << std::endl;
        std::cout << "length = " << length << std::endl;
        error("CBmlmRM_envlp::set_hyperpars(): incorrect dimension.\n");
    }
    
    int offset = 0; 

    this->hyper_eta_mean->copy(pt + offset);
    offset += this->hyper_eta_mean->get_length(); 

    this->hyper_eta_col_inv->copy(pt + offset); 
    offset += this->hyper_eta_col_inv->get_length(); 

    this->hyper_Omega_df = pt[offset]; 
    offset ++; 

    this->hyper_Omega_scale->copy(pt + offset); 
    offset += this->hyper_Omega_scale->get_length(); 

    this->hyper_Omega0_df = pt[offset]; 
    offset ++;

    this->hyper_Omega0_scale->copy(pt + offset); 
    offset += this->hyper_Omega0_scale->get_length(); 

    this->hyper_Amat_Mmat->copy(pt + offset); 
}

void CBmlmRM_envlp::set_tuning(int length, double *pt)
{
    if(length != 2)
        error("CBmlmRM_envlp::set_propars(): incorrect dimension.\n");

    this->pro_rho_delta = pt[0];
    this->pro_Amat_sigma2 = pt[1];
} 


/* write information to a file */

void CBmlmRM_envlp::write2stream(std::ostream &stream)
{
    Creg::write2stream(stream); 

    stream << "\nnumber of subject = " << this->m_sub << std::endl;

    stream << "correlation type = ";  
    if(this->ctype == Corr_Type::iid) stream << "IID\n";
    else if(this->ctype == Corr_Type::cs) stream << "CS\n";
    else if (this->ctype == Corr_Type::ar1) stream << "AR1\n";
    else stream << "unsupported corelation type.\n"; 
    
    stream << "rho = " << this->rho << std::endl;
    stream << "Jvec = (" << this->Jvec->get_entry_vec(0) << ", ..., " 
           << this->Jvec->get_entry_vec(this->m_sub - 1) << ")\n";

    stream << "\nalpha =\n";
    this->alpha->write2stream(stream, false);

    stream << "\neta =\n"; 
    this->eta->write2stream(stream, false); 

    stream << "\nA =\n"; 
    this->A->write2stream(stream, false); 

    stream << "\nOmega_inv =\n"; 
    this->Omega_inv->write2stream(stream, false); 

    stream << "\nOmega0_inv =\n"; 
    this->Omega0_inv->write2stream(stream, false); 

    stream << "\nhyper_eta_mean =\n";
    this->hyper_eta_mean->write2stream(stream, false);

    stream << "\nhyper_eta_col_inv =\n";
    this->hyper_eta_col_inv->write2stream(stream, false);

    stream << "\nhyper_Omega_df = " << this->hyper_Omega_df << std::endl;

    stream << "\nhyper_Omega_scale =\n";
    this->hyper_Omega_scale->write2stream(stream, false);

    stream << "\nhyper_Omega0_df = " << this->hyper_Omega0_df << std::endl;

    stream << "\nhyper_Omega0_scale =\n";
    this->hyper_Omega0_scale->write2stream(stream, false);

    stream << "\nhyper_Amat_Mmat =\n";
    this->hyper_Amat_Mmat->write2stream(stream, false);

    stream << "\npro_rho_delta = " << this->pro_rho_delta << std::endl;
    stream << "\npro_Amat_sigma2 = " << this->pro_Amat_sigma2 << std::endl;    
}  

/**********************************************************************
 * sample from posterior distributions 
 **********************************************************************/

/**********************************************************************
 * Hmat.new = hyper.pars$Hmat; 
 * xi.new = hyper.pars$xi %*% hyper.pars$Hmat; 
 * res.beta = sweep(y, 2, drop(iSample$alpha), "-"); 
 * for(i in 1:n_subject)
 * {
 *     index = which(subject == i); 
 *     Rinv = cor.inv(length(index), iSample$rho, cor.type);
 *     Hmat.new = Hmat.new + t(x[index, ]) %*% Rinv %*% x[index, ];
 *     xi.new = xi.new + t(res.beta[index, ]) %*% Rinv %*% x[index, ];
 * }
 * xi.new = xi.new %*% solve(Hmat.new); 
 *
 * iSample$beta = t(iSample$Gamma) %*% xi.new + 
 *             t(chol(iSample$Omega)) %*%
 *             matrix(rnorm(r*p), nrow = r, ncol = p) %*%
 *             chol(solve(Hmat.new)); 
 **********************************************************************/

void CBmlmRM_envlp::sample_eta()
{
    /* res = y - alpha * 1^T */
    this->res->copy(*(this->y)); 
    this->res->axpy_col(-1.0, *(this->alpha)); 

    /* Hmat_new = hyper.pars$Hmat */
    Cmat Hmat_new(this->p_var, this->p_var); 
    Hmat_new.copy(*(this->hyper_eta_col_inv));

    /* xi_new = hyper.pars$xi %*% hyper.pars$Hmat */
    Cmat xi_new(this->r_resp, this->p_var); 
    xi_new.gemm("N", "N", 1.0, *(this->hyper_eta_mean), *(this->hyper_eta_col_inv), 0.0); 

    for(int i = 0, pos_res = 0, pos_x = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        /* Rinvxi = Rinv %*% x[index, ]; */
        Cmat xi(this->p_var, Ji, this->x->get_value_pt() + pos_x); 
        Cmat Rinvxi(Ji, this->p_var); 
        Rinvxi.gemm("N", "T", 1.0, Rinv, xi, 0.0); 

        /* Hmat.new = Hmat.new + t(x[index, ]) %*% Rinv %*% x[index, ] */
        Hmat_new.gemm("N", "N", 1.0, xi, Rinvxi, 1.0);
                 
        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos_res); 
        /* xi_new = xi.new + t(res.beta[index, ]) %*% Rinv %*% x[index, ]; */
        xi_new.gemm("N", "N", 1.0, res_i, Rinvxi, 1.0);  

        /* update position for res_i */
        pos_x += Ji * (this->p_var); 
        pos_res += Ji * (this->r_resp); 
    }

    Hmat_new.chol();
    xi_new.solve_chol_right(Hmat_new, 1.0);

    /* mu_beta = t(iSample$Gamma) %*% xi.new */
    Cmat mu_beta(this->u_dim, this->p_var);
    mu_beta.gemm("T", "N", 1.0, *(this->Gamma), xi_new, 0.0); 

    this->Omega_inv->chol(); 
    rnorm_mat_inv_chol(*(this->eta), mu_beta, *(this->Omega_inv), Hmat_new);
}

/**********************************************************************
 * bHb = (iSample$eta - t(iSample$Gamma) %*% hyper.pars$xi) %*% 
 *        hyper.pars$Hmat %*% t(iSample$eta - t(iSample$Gamma) %*% hyper.pars$xi)
 *
 * res = sweep(y, 2, iSample$alpha, "-") - x %*% t(iSample$beta); 
 * res2 = matrix(0, nrow = r, ncol = r); 
 * for(i in 1:n_subject)
 * {
 *      index = which(subject == i); 
 *      Rinv = cor.inv(length(index), iSample$rho, cor.type);
 *      res2 = res2 + t(res[index, ]) %*% Rinv %*% res[index, ];  
 * }
 *
 * Psi.new = hyper.pars$Psi + bHb + t(iSample$Gamma) %*% res2 %*% iSample$Gamma; 
 * Omega.inv = drop(rWishart(1,  
 *                  df = hyper.pars$df + p + sumJ, 
 *                  Sigma = solve(Psi.new)));
 * iSample$Omega = solve(Omega.inv); 
 *
 * Psi0.new = hyper.pars$Psi0 + t(iSample$Gamma0) %*% res2 %*% iSample$Gamma0; 
 * Omega0.inv = drop(rWishart(1,  
 *                  df = hyper.pars$df0 + sumJ, 
 *                  Sigma = solve(Psi0.new)));
 * iSample$Omega0 = solve(Omega0.inv); 
 **********************************************************************/

void CBmlmRM_envlp::sample_Omegas()
{
    Cmat res2(this->r_resp, this->r_resp);
    res2.set_zero();

    for(int i = 0, pos = 0; i < (this->m_sub); i++)
    {
        int Ji = this->Jvec->get_entry_vec(i); 

        /* inverse of the correlation matrix */
        Ccormat cor(Ji, this->ctype, this->rho); 
        Cmat Rinv(Ji, Ji); 
        cor.set_mat_inv(Rinv); 

        /* Psi.new = Psi.new + t(res[index, ]) %*% Rinv %*% res[index, ]; */
        Cmat res_i(this->r_resp, Ji, this->res->get_value_pt() + pos); 
        res2.ABAt(1.0, res_i, Rinv, 1.0); 

        /* update position for res_i */
        pos += Ji * (this->r_resp); 
    }

    /* bxi = iSample$eta - t(iSample$Gamma) %*% hyper.pars$xi */
    Cmat bxi(this->u_dim, this->p_var); 
    bxi.copy(*(this->eta));
    bxi.gemm("T", "N", -1.0, *(this->Gamma), *(this->hyper_eta_mean), 1.0);  

    /* Psi.new = hyper.pars$Psi + bHb + t(iSample$Gamma) %*% res2 %*% iSample$Gamma; */
    Cmat Psi_new(this->u_dim, this->u_dim);
    Psi_new.copy(*(this->hyper_Omega_scale));
    Psi_new.ABAt(1.0, bxi, *(this->hyper_eta_col_inv), 1.0); 
    Psi_new.AtBA(1.0, *(this->Gamma), res2, 1.0); 

    double df = this->hyper_Omega_df + (double)(this->n_obs) + (double)(this->p_var);
    rwishart_inv(*(this->Omega_inv), df, Psi_new);  

    /* Psi0.new = hyper.pars$Psi0 + t(iSample$Gamma0) %*% res2 %*% iSample$Gamma0; */
    Cmat Psi0_new((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim));
    Psi0_new.copy(*(this->hyper_Omega0_scale));
    Psi0_new.AtBA(1.0, *(this->Gamma0), res2, 1.0); 

    double df0 = this->hyper_Omega_df + (double)(this->n_obs);
    rwishart_inv(*(this->Omega0_inv), df0, Psi0_new);  
}

/**********************************************************************
 * # compute log-likelihood
 * Amat.loglik.old = BmlmR.envlp.Amat.loglik(iSample, hyper.pars); 
 *
 * # propose a new Amat
 * Amat.new = propose.Amat(iSample$Gamma, pro.pars$Pmat.sigma2, Umat); 
 * iSample.new = iSample; 
 * iSample.new$Amat = Amat.new; 

 * # update quantities depending on Amat 
 * iSample.new$Gamma = A2Gamma(iSample.new$Amat, Umat); 
 * iSample.new$Gamma0 = A2Gamma0(iSample.new$Amat, Umat); 
 * iSample.new$Sigma = Gamma2Sigma(iSample.new$Gamma, iSample.new$Gamma0, 
 *                                 iSample.new$Omega, iSample.new$Omega0); 
 * iSample.new$beta = iSample.new$Gamma %*% iSample.new$eta; 
 * iSample.new$res = sweep(y, 2, iSample.new$alpha, "-") - x %*% t(iSample.new$beta); 
 * 
 * # compute log-likelihood
 * Amat.loglik.new = BmlmR.envlp.Amat.loglik(iSample.new, hyper.pars); 
 * 
 * Amat.logratio = Amat.loglik.new - Amat.loglik.old;
 * if(log(runif(1)) < Amat.logratio)
 * {
 *     iSample = iSample.new; 
 *     iSample$Amat.accept = iSample$Amat.accept + 1; 
 * }
**********************************************************************/

void CBmlmRM_envlp::sample_Amat()
{
    /* compute loglik based on the current values */
    double old_loglik = this->compute_loglik_Amat(); 

    /* save current values */
    Cmat current_Amat((this->r_resp) - (this->u_dim), (this->u_dim)); 
    Cmat current_Gamma(this->r_resp, this->u_dim); 
    Cmat current_Gamma0(this->r_resp, (this->r_resp) - (this->u_dim));
    Cmat current_Sigma_inv(this->r_resp, this->r_resp); 
    Cmat current_beta(this->r_resp, this->p_var); 
    Cmat current_res(this->r_resp, this->n_obs); 
    Cmat current_deltaRM(this->m_sub, 1); 

    current_Amat.copy(*(this->A)); 
    current_Gamma.copy(*(this->Gamma)); 
    current_Gamma0.copy(*(this->Gamma0)); 
    current_Sigma_inv.copy(*(this->Sigma_inv));
    current_beta.copy(*(this->beta)); 
    current_res.copy(*(this->res)); 
    current_deltaRM.copy(*(this->deltaRM)); 

    /* propose a new Amat */
    this->propose_Amat();

    /* update affected parameters */
    this->compute_Gammas(); 
    this->Sigma_restore(*(this->Sigma_inv), *(this->Omega_inv), *(this->Omega0_inv)); 
    this->beta_restore(*(this->beta), *(this->eta)); 
    this->compute_residual(); 
    this->compute_deltaRM(); 

    /* compute loglik based on the proposed values */
    double new_loglik = this->compute_loglik_Amat(); 

    if(log(unif_rand()) < (new_loglik - old_loglik))
    {
        /* accept the proposed Amat */
        (this->A_count)++; 
    }
    else 
    {
        /* keep the current values */
        this->A->copy(current_Amat); 
        this->Gamma->copy(current_Gamma);
        this->Gamma0->copy(current_Gamma0); 
        this->Sigma_inv->copy(current_Sigma_inv);
        this->beta->copy(current_beta); 
        this->res->copy(current_res); 
        this->deltaRM->copy(current_deltaRM); 
    }
}

/**********************************************************************
 *   loglik = sum(diag(t(iSample$Gamma) %*% hyper.pars$P.Mmat %*% iSample$Gamma));
 *
 *   vec = iSample$eta - t(iSample$Gamma) %*% hyper.pars$eta.mean; 
 *   eHe = vec %*% hyper.pars$eta.cov.inv %*% t(vec); 
 *   loglik = loglik - 0.5 * sum(solve(iSample$Omega) * eHe); 
 *   loglik = loglik - 0.5 * sum(deltaR)
 **********************************************************************/

double CBmlmRM_envlp::compute_loglik_Amat()
{
    double loglik = this->deltaRM->sum(); 

    /* bxi = iSample$eta - t(iSample$Gamma) %*% hyper.pars$eta.mean; */
    Cmat bxi(this->u_dim, this->p_var); 
    bxi.copy(*(this->eta));
    bxi.gemm("T", "N", -1.0, *(this->Gamma), *(this->hyper_eta_mean), 1.0);  

    /* eHe = vec %*% hyper.pars$eta.cov.inv %*% t(vec); */
    Cmat eHe(this->u_dim, this->u_dim);
    eHe.ABAt(1.0, bxi, *(this->hyper_eta_col_inv), 0.0); 

    loglik += eHe.dot(*(this->Omega_inv)); 
    loglik *= (-0.5); 

    /* eHe = t(iSample$Gamma) %*% hyper.pars$P.Mmat %*% iSample$Gamma) */
    eHe.AtBA(1.0, *(this->Gamma), *(this->hyper_Amat_Mmat), 0.0); 
    loglik += eHe.trace(); 

    return(loglik); 
} 

/**********************************************************************
 * compute posterior means  
 **********************************************************************/

void CBmlmRM_envlp::compute_posterior_mean(int length, double *pt)
{
    if((this->length_saved_pars) != length)
        error("CBmlmRM_envlp::compute_posterior_mean(): wrong size of pt.\n"); 
 
    const int length_abrA = this->alpha->get_length() + this->eta->get_length() + 1 + this->A->get_length();
    Cmat alpha_beta_r_A(length_abrA, 1, pt);
    Cmat alpha_beta_r_A_samples(length_abrA, this->count_output_mcmc, this->samples, this->length_saved_pars); 
    alpha_beta_r_A.rowMeans(alpha_beta_r_A_samples);
     
    Cmat Omega_mean(this->u_dim, this->u_dim, pt + length_abrA); 
    Omega_mean.set_zero(); 

    const int length_abrAOmega = length_abrA + this->Omega_inv->get_length(); 
    Cmat Omega0_mean((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim), pt + length_abrAOmega); 
    Omega0_mean.set_zero(); 
    
    double sc = 1.0 / (double)(this->count_output_mcmc); 
    Cmat iOmega(this->u_dim, this->u_dim);
    Cmat iOmega0((this->r_resp) - (this->u_dim), (this->r_resp) - (this->u_dim));
    
    for(int i = 0; i < (this->count_output_mcmc); i++)
    {
        iOmega.copy((this->samples) + i * (this->length_saved_pars) + length_abrA); 
        iOmega.inv(); 
        Omega_mean.axpy(sc, iOmega); 

        iOmega0.copy((this->samples) + i * (this->length_saved_pars) + length_abrAOmega); 
        iOmega0.inv(); 
        Omega0_mean.axpy(sc, iOmega0); 
    }
}
 
/**********************************************************************
 * Markov Chain Monte Carlo 
 **********************************************************************/

void CBmlmRM_envlp::mcmc_initialize()
{
    this->compute_Gammas(); 
    this->Sigma_restore(*(this->Sigma_inv), *(this->Omega_inv), *(this->Omega0_inv)); 
    this->beta_restore(*(this->beta), *(this->eta)); 
   
    if(this->ctype == Corr_Type::iid)
    {
        this->rho = 0.0; 
    }

    this->count_mcmc = 0;
    this->count_output_mcmc = 0; 
    this->rho_count = 0; 
    this->A_count = 0; 
} 

void CBmlmRM_envlp::mcmc_one_pass()
{
    /* reset values after burn-in period */
    if((this->count_mcmc) == (this->burn_in_mcmc))
    {
        this->rho_count = 0; 
        this->A_count = 0; 
    }

    this->sample_alpha(); 

    this->sample_eta();
    this->beta_restore(*(this->beta), *(this->eta)); 
    this->compute_residual(); 

    this->sample_Omegas();
    this->Sigma_restore(*(this->Sigma_inv), *(this->Omega_inv), *(this->Omega0_inv)); 

    this->compute_deltaRM(); 
    
    if(this->ctype != Corr_Type::iid) 
        this->sample_rho(); 

    this->sample_Amat();   

    this->pars[0] = this->rho;
} 

/* count_mcmc, count_output_mcmc, rho_count, A_count */

void CBmlmRM_envlp::get_all_count(int count_length, int *count_pt)
{
    if(count_length < 4)
        error("CBmlmRM_envlp::get_all_count(): incorrect length.\n"); 

    count_pt[0] = this->count_mcmc;
    count_pt[1] = this->count_output_mcmc; 
    count_pt[2] = this->rho_count; 
    count_pt[3] = this->A_count; 
} 

/**********************************************************************
 * compute log-likelihood corresponding to each draw from posterior distribution
 * logf has count_output_mcmc rows and m_sub columns
 **********************************************************************/

void CBmlmRM_envlp::compute_loglik_draws(Cmat &logf) 
{
    if(logf.get_ncol() != (this->m_sub))
        error("CBmlmRM_envlp::compute_loglik_draws(): logf has incompatible number of columns.\n");

    /* compute log-density for each subject at each posterior draw */
    for(int s = 0; s < logf.get_nrow(); s++)
    {
        /* set parameters, avoid the first one */
        this->set_ini_pars(this->length_pars, 
                            this->samples + (this->length_saved_pars) * s); 

        /* compute beta, Sigma_inv, res, and deltaRM*/
        this->compute_Gammas(); 
        this->Sigma_restore(*(this->Sigma_inv), *(this->Omega_inv), *(this->Omega0_inv)); 
        this->beta_restore(*(this->beta), *(this->eta)); 
        this->compute_residual(); 
        this->compute_deltaRM(); 

        double logdetS = - (this->Omega_inv->logdet_chol()) - (this->Omega0_inv->logdet_chol());
        
        for(int i = 0; i < (this->m_sub); i++)
        {
            int Ji = this->Jvec->get_entry_vec(i); 

            Ccormat cor(Ji, this->ctype, this->rho); 
            double logdetR = cor.logdet(); 

            double logden = log_dMnorm0(this->r_resp, Ji, 
                            this->deltaRM->get_entry_vec(i), logdetS, logdetR); 

            logf.set_entry(s, i, logden); 
        }
    }
}

/**********************************************************************
 * THE END
 **********************************************************************/
