/**********************************************************************
 * Class for regression  
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 * updated: 2025-10-22 
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CREG__HPP__ 
#define __ZP__CREG__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "Cmat.hpp"

class Creg {
    protected: 
        Cmat *x;               /* predictor - p-by-n matrix */
        Cmat *y;               /* response - r-by-n matrix */
        int n_obs;             /* number of observations */
        int p_var;             /* number of predictors */
        int r_resp;            /* number of responses */

    public: 
        Creg(); 
        Creg(Cmat *x_pt, Cmat *y_pt); 
        ~Creg(); 

        /**************************************************************
         * get or set values   
         **************************************************************/

        void write2stream(std::ostream &stream);  
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
