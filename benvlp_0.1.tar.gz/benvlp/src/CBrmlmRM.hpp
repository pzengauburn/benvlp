/**********************************************************************
 * Class for Bayesian inference for multivariate linear regression 
 * with repeated measures, t-distribution   
 * Peng Zeng @ Auburn University  
 * updated: 2025-10-27 
 **********************************************************************/

#ifndef  USE_FC_LEN_T
# define USE_FC_LEN_T
#endif
#include <Rconfig.h>
#include <R_ext/BLAS.h>
#ifndef FCONE
# define FCONE
#endif

#ifndef __ZP__CBRMLMRM__HPP__ 
#define __ZP__CBRMLMRM__HPP__ 

#include <R.h> 
#include <R_ext/BLAS.h> 
#include <R_ext/Lapack.h> 

#include <string.h>
#include "Cmat.hpp"
#include "ClinregRMt.hpp"
#include "Cmcmc.hpp"
#include "CBtGamma.hpp"
#include "distribution.hpp"

class CBrmlmRM : public ClinregRMt, public Cmcmc {
    protected:         
        bool assume_normal;          /* 1 = normal, 0 = t-distribution */

        /* hyper-parameters in prior distributions */
        Cmat *hyper_beta_mean;       /* r-by-p matrix */
        Cmat *hyper_beta_col_inv;    /* p-by-p matrix */
        double hyper_Sigma_df;       /* scalar */
        Cmat *hyper_Sigma_scale;     /* r-by-r matrix */

    public: 
        CBrmlmRM(); 
        CBrmlmRM(Cmat *x_pt, Cmat *y_pt, Cimat *Jvec_pt, Corr_Type cp,
                bool normal,
                int burn_in, int size, int thinning, int info, int length); 
        ~CBrmlmRM(); 

        /* set initial values */
        void set_ini_pars(int length, double *pt); 

        /* set hyper-parameters in prior distributions */
        void set_hyperpars(int length, double *pt); 

        /* set hyper-parameters in proposal distributions */
        void set_tuning(int length, double *pt); 

        /* write information to a file */
        void write2stream(std::ostream &stream);         

        /* sample from posterior distributions */
        void sample_beta(); 
        void sample_Sigma_inv(); 

        /* compute posterior mean */
        void compute_posterior_mean(int length, double *pt); 

        /* compute log-likelihood corresponding to each draw from posterior distribution */
        /* logf has count_output_mcmc rows and m_sub columns */
        void compute_loglik_draws(Cmat &logf);  
        
        /* Markov Chain Monte Carlo */
        void mcmc_initialize(); 
        void mcmc_one_pass(); 

        /* count_mcmc, count_output_mcmc, rho_count, nu_count */
        void get_all_count(int length, int *count); 
};

#endif

/**********************************************************************
 * THE END
 **********************************************************************/
