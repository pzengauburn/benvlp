/**********************************************************************
 * Class for linear regression  
 * Peng Zeng @ Auburn University  
 * updated: 2024-11-28 
 * updated: 2025-03-13  
 * updated: 2025-10-22 
 **********************************************************************/

#include <R.h> 

#include "Clinreg.hpp" 

/********************************************************************** 
 * variables defined in Creg: (5)
 *     Cmat *x;                     predictor - p-by-n matrix 
 *     Cmat *y;                     response - r-by-n matrix 
 *     int n_obs;                   number of observations 
 *     int p_var;                   number of predictors 
 *     int r_resp;                  number of responses 
 *
 * variables defined in Clinreg: (4) 
 *     bool has_intercept;          true = with intercept, false = no intercept 
 *     Cmat *alpha;                 intercept - r-by-1 matrix 
 *     Cmat *beta;                  slope - r-by-p matrix 
 *     Cmat *res;                   residual - r-by-n matrix 
 **********************************************************************/

Clinreg::Clinreg() : Creg()
{
    this->has_intercept = true; 
    this->alpha = nullptr; 
    this->beta = nullptr;
    this->res = nullptr; 
} 

Clinreg::Clinreg(Cmat *x_pt, Cmat *y_pt, bool intercept) : Creg(x_pt, y_pt)
{
    this->has_intercept = intercept; 

    if(this->has_intercept)
    {
        this->alpha = new Cmat(this->r_resp, 1, nullptr); 
    }
    else 
    {
        this->alpha = nullptr; 
    }

    this->beta = new Cmat(this->r_resp, this->p_var, nullptr);
    this->res = new Cmat(this->r_resp, this->n_obs);
} 

/**********************************************************************
 * destructor 
 **********************************************************************/

Clinreg::~Clinreg() 
{
    if(this->alpha != nullptr) delete this->alpha; 
    if(this->beta != nullptr)  delete this->beta; 
    if(this->res != nullptr)   delete this->res; 
} 

/**********************************************************************
 * get or set class members  
 **********************************************************************/

void Clinreg::set_alpha(Cmat *a)
{
    if(!(a->is_vector()))
        error("Clinreg::set_alpha(): alpha should a vector.\n"); 
    if((a->get_vec_length()) != (this->r_resp))
        error("Clinreg::set_alpha(): length(alpha) != r_resp.\n");

    this->alpha = a; 
}

void Clinreg::set_beta(Cmat *b) 
{
    if((b->get_nrow()) != (this->r_resp))
        error("Clinreg::set_beta(): nrow(beta) != r_resp.\n");  
    if((b->get_ncol()) != (this->p_var))
        error("Clinreg::set_beta(): ncol(beta) != p_var.\n"); 

    this->beta = b; 
}

void Clinreg::write2stream(std::ostream &stream)  
{
    Creg::write2stream(stream); 

    if(this->has_intercept)
    {
        stream << "\nalpha =\n";
        this->alpha->write2stream(stream, false);
    }
    else 
    {
        stream << "\nNo intercept.\n";
    }

    stream << "\nbeta =\n"; 
    this->beta->write2stream(stream, false); 
}

/**********************************************************************
 * compute least squares estimate by Cholesky factorization 
 **********************************************************************/

/* compute least squares estimate by Cholesky factorization */

void Clinreg::fit_lse_chol()
{
    Cmat *x_ctr = nullptr,  *y_ctr = nullptr;
    Cmat *x_mean = nullptr, *y_mean = nullptr; 

    if(this->has_intercept)
    {
        x_ctr  = new Cmat(this->p_var, this->n_obs); 
        x_ctr->copy(*(this->x)); 
        x_mean = new Cmat(this->p_var, 1); 
        x_mean->rowMeans(*x_ctr);
        x_ctr->rowCenter(*x_mean); 

        y_ctr  = new Cmat(this->r_resp, this->n_obs); 
        y_ctr->copy(*(this->y)); 
        y_mean = this->alpha;       /* use alpha for y_mean */
        y_mean->rowMeans(*y_ctr); 
        y_ctr->rowCenter(*y_mean);
    }
    else 
    {
        x_ctr = this->x; 
        y_ctr = this->y; 
    }

    const double sc = 1.0 / (double)(this->n_obs); 

    /* beta := y %*% t(x) / n */
    this->beta->gemm("N", "T", sc, *y_ctr, *x_ctr, 0.0); 

    Cmat xTx(this->p_var, this->p_var); 
    /* xTx := x %*% t(x) / n */
    xTx.syrk("L", "N", sc, *x_ctr, 0.0); 
    /* xTx := chol(xTx) */
    xTx.chol(); 
    /* beta := beta %*% solve(xTx) */
    this->beta->solve_chol_right(xTx); 
    
    if(this->has_intercept)
    {
        /* alpha := ymean when calculating the mean */
        /* alpha := ymean - beta * xmean */
        this->alpha->gemv("N", -1.0, *(this->beta), *x_mean, 1.0); 
        delete x_ctr;  delete x_mean; 
        delete y_ctr;  /* y_mean use the space of alpha */ 
    } 
    else if(this->alpha != nullptr)
        this->alpha->set_zero(); 
}

/* compute residuals: r = y - alpha 1^T - b * x */

void Clinreg::compute_residual()
{
    this->res->copy(*(this->y));   /* res = y */

    if((this->r_resp) == 1) /* one reponse */
    {
        if(this->has_intercept)
        {
            const double a = this->alpha->get_entry_vec(0);
            this->res->add(-a);         /* res = y - a */
        }
        /* res -= b * x */
        this->res->gemv("T", -1.0, *(this->x), *(this->beta), 1.0); 
    }
    else /* multiple responses */
    {
        /* res -= alpha * 1^T, if intercept = true */       
        if(this->has_intercept) this->res->axpy_col(-1.0, *(this->alpha)); 
        /* res -= b * x */
        this->res->gemm("N", "N", -1.0, *(this->beta), *(this->x), 1.0); 
    }
}

/**********************************************************************
 * THE END
 **********************************************************************/
